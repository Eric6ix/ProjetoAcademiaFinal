﻿namespace AcademiaDEV
{
    partial class Aulas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Aulas));
            buttonCadastarAula = new Button();
            buttonAtualizarAula = new Button();
            buttonExcluirAula = new Button();
            buttonEditarAula = new Button();
            dataGridViewAulas = new DataGridView();
            textBoxPesquisarNomeAula = new TextBox();
            buttonBuscarAulas = new Button();
            buttonVoltarAulas = new Button();
            panel1 = new Panel();
            buttonAulasPDF = new Button();
            label7 = new Label();
            pictureBox2 = new PictureBox();
            label6 = new Label();
            pictureBox1 = new PictureBox();
            panel4 = new Panel();
            label4 = new Label();
            label2 = new Label();
            panel2 = new Panel();
            pictureBox3 = new PictureBox();
            label3 = new Label();
            panel3 = new Panel();
            label9 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridViewAulas).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel4.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // buttonCadastarAula
            // 
            buttonCadastarAula.BackColor = Color.FromArgb(192, 255, 192);
            buttonCadastarAula.Cursor = Cursors.Hand;
            buttonCadastarAula.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonCadastarAula.Image = (Image)resources.GetObject("buttonCadastarAula.Image");
            buttonCadastarAula.ImageAlign = ContentAlignment.MiddleLeft;
            buttonCadastarAula.Location = new Point(34, 17);
            buttonCadastarAula.Name = "buttonCadastarAula";
            buttonCadastarAula.Size = new Size(232, 85);
            buttonCadastarAula.TabIndex = 13;
            buttonCadastarAula.Text = "Cadastrar";
            buttonCadastarAula.UseVisualStyleBackColor = false;
            buttonCadastarAula.Click += buttonCadastarAula_Click;
            // 
            // buttonAtualizarAula
            // 
            buttonAtualizarAula.BackColor = Color.FromArgb(255, 224, 192);
            buttonAtualizarAula.Cursor = Cursors.Hand;
            buttonAtualizarAula.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonAtualizarAula.Image = Properties.Resources.icons8_synchronize_52;
            buttonAtualizarAula.ImageAlign = ContentAlignment.MiddleLeft;
            buttonAtualizarAula.Location = new Point(272, 19);
            buttonAtualizarAula.Name = "buttonAtualizarAula";
            buttonAtualizarAula.Size = new Size(232, 85);
            buttonAtualizarAula.TabIndex = 14;
            buttonAtualizarAula.Text = "Atualizar";
            buttonAtualizarAula.UseVisualStyleBackColor = false;
            buttonAtualizarAula.Click += buttonAtualizarAula_Click;
            // 
            // buttonExcluirAula
            // 
            buttonExcluirAula.BackColor = Color.FromArgb(255, 192, 192);
            buttonExcluirAula.Cursor = Cursors.Hand;
            buttonExcluirAula.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonExcluirAula.Image = Properties.Resources.icons8_trash_can_48;
            buttonExcluirAula.ImageAlign = ContentAlignment.MiddleLeft;
            buttonExcluirAula.Location = new Point(510, 19);
            buttonExcluirAula.Name = "buttonExcluirAula";
            buttonExcluirAula.Size = new Size(232, 85);
            buttonExcluirAula.TabIndex = 15;
            buttonExcluirAula.Text = "Excluir";
            buttonExcluirAula.UseVisualStyleBackColor = false;
            buttonExcluirAula.Click += buttonExcluirAula_Click;
            // 
            // buttonEditarAula
            // 
            buttonEditarAula.BackColor = Color.FromArgb(192, 192, 255);
            buttonEditarAula.Cursor = Cursors.Hand;
            buttonEditarAula.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonEditarAula.Image = Properties.Resources.icons8_editar_48;
            buttonEditarAula.ImageAlign = ContentAlignment.MiddleLeft;
            buttonEditarAula.Location = new Point(748, 18);
            buttonEditarAula.Name = "buttonEditarAula";
            buttonEditarAula.Size = new Size(232, 86);
            buttonEditarAula.TabIndex = 29;
            buttonEditarAula.Text = "Editar";
            buttonEditarAula.UseVisualStyleBackColor = false;
            buttonEditarAula.Click += buttonEditarAula_Click;
            // 
            // dataGridViewAulas
            // 
            dataGridViewAulas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewAulas.Location = new Point(24, 181);
            dataGridViewAulas.Name = "dataGridViewAulas";
            dataGridViewAulas.RowHeadersWidth = 51;
            dataGridViewAulas.Size = new Size(974, 309);
            dataGridViewAulas.TabIndex = 30;
            // 
            // textBoxPesquisarNomeAula
            // 
            textBoxPesquisarNomeAula.BackColor = Color.Gainsboro;
            textBoxPesquisarNomeAula.BorderStyle = BorderStyle.None;
            textBoxPesquisarNomeAula.Location = new Point(184, 16);
            textBoxPesquisarNomeAula.Multiline = true;
            textBoxPesquisarNomeAula.Name = "textBoxPesquisarNomeAula";
            textBoxPesquisarNomeAula.Size = new Size(467, 27);
            textBoxPesquisarNomeAula.TabIndex = 31;
            // 
            // buttonBuscarAulas
            // 
            buttonBuscarAulas.BackColor = Color.FromArgb(224, 224, 224);
            buttonBuscarAulas.Cursor = Cursors.Hand;
            buttonBuscarAulas.Image = Properties.Resources.icons8_pesquisar_48;
            buttonBuscarAulas.Location = new Point(1226, 137);
            buttonBuscarAulas.Name = "buttonBuscarAulas";
            buttonBuscarAulas.Size = new Size(112, 60);
            buttonBuscarAulas.TabIndex = 32;
            buttonBuscarAulas.UseVisualStyleBackColor = false;
            buttonBuscarAulas.Click += buttonBuscarAulas_Click;
            // 
            // buttonVoltarAulas
            // 
            buttonVoltarAulas.BackColor = Color.Gainsboro;
            buttonVoltarAulas.Cursor = Cursors.Hand;
            buttonVoltarAulas.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonVoltarAulas.Image = Properties.Resources.icons8_voltar_48;
            buttonVoltarAulas.ImageAlign = ContentAlignment.MiddleLeft;
            buttonVoltarAulas.Location = new Point(34, 663);
            buttonVoltarAulas.Name = "buttonVoltarAulas";
            buttonVoltarAulas.Size = new Size(301, 50);
            buttonVoltarAulas.TabIndex = 33;
            buttonVoltarAulas.Text = "Voltar";
            buttonVoltarAulas.UseVisualStyleBackColor = false;
            buttonVoltarAulas.Click += buttonVoltarAulas_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(buttonAulasPDF);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(buttonVoltarAulas);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(410, 761);
            panel1.TabIndex = 34;
            // 
            // buttonAulasPDF
            // 
            buttonAulasPDF.BackColor = Color.FromArgb(255, 192, 128);
            buttonAulasPDF.Cursor = Cursors.Hand;
            buttonAulasPDF.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonAulasPDF.Image = Properties.Resources.icons8_pdf_2_482;
            buttonAulasPDF.ImageAlign = ContentAlignment.MiddleLeft;
            buttonAulasPDF.Location = new Point(34, 597);
            buttonAulasPDF.Name = "buttonAulasPDF";
            buttonAulasPDF.Size = new Size(301, 60);
            buttonAulasPDF.TabIndex = 37;
            buttonAulasPDF.Text = "PDF Aulas";
            buttonAulasPDF.UseVisualStyleBackColor = false;
            buttonAulasPDF.Click += buttonAulasPDF_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(68, 415);
            label7.Name = "label7";
            label7.Size = new Size(267, 100);
            label7.TabIndex = 24;
            label7.Text = "  Faça o registro de alunos\r\n informando suas informações\r\n    no sistema para cadastrar\r\n                    aula.";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(148, 31);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(105, 39);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 25;
            pictureBox2.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Black", 18F);
            label6.ForeColor = Color.White;
            label6.Location = new Point(144, 363);
            label6.Name = "label6";
            label6.Size = new Size(109, 42);
            label6.TabIndex = 24;
            label6.Text = "Aulas";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.icons8_aula_50_branco;
            pictureBox1.Location = new Point(148, 252);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(105, 108);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Black;
            panel4.Controls.Add(label4);
            panel4.Controls.Add(label2);
            panel4.Location = new Point(432, 12);
            panel4.Name = "panel4";
            panel4.Size = new Size(1036, 109);
            panel4.TabIndex = 35;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Black", 11F);
            label4.ForeColor = Color.White;
            label4.Location = new Point(879, 38);
            label4.Name = "label4";
            label4.Size = new Size(134, 27);
            label4.TabIndex = 36;
            label4.Text = "Bem vindo !";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Black", 18F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(24, 38);
            label2.Name = "label2";
            label2.Size = new Size(280, 42);
            label2.TabIndex = 26;
            label2.Text = "Cadastrar Aulas";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(textBoxPesquisarNomeAula);
            panel2.Location = new Point(550, 137);
            panel2.Name = "panel2";
            panel2.Size = new Size(670, 60);
            panel2.TabIndex = 30;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(7, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(46, 54);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 26;
            pictureBox3.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 10F);
            label3.ForeColor = Color.FromArgb(64, 64, 64);
            label3.Location = new Point(59, 16);
            label3.Name = "label3";
            label3.Size = new Size(100, 23);
            label3.TabIndex = 15;
            label3.Text = "Nome Aula:";
            // 
            // panel3
            // 
            panel3.BackColor = Color.Black;
            panel3.Controls.Add(label9);
            panel3.Controls.Add(buttonCadastarAula);
            panel3.Controls.Add(dataGridViewAulas);
            panel3.Controls.Add(buttonAtualizarAula);
            panel3.Controls.Add(buttonExcluirAula);
            panel3.Controls.Add(buttonEditarAula);
            panel3.Location = new Point(432, 236);
            panel3.Name = "panel3";
            panel3.Size = new Size(1023, 513);
            panel3.TabIndex = 36;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(24, 137);
            label9.Name = "label9";
            label9.Size = new Size(205, 23);
            label9.TabIndex = 26;
            label9.Text = "Dados salvo do alunos.";
            // 
            // Aulas
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1480, 761);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel4);
            Controls.Add(panel1);
            Controls.Add(buttonBuscarAulas);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Aulas";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Aulas";
            Load += Aulas_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewAulas).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button buttonCadastarAula;
        private Button buttonAtualizarAula;
        private Button buttonExcluirAula;
        private Button buttonEditarAula;
        private DataGridView dataGridViewAulas;
        private TextBox textBoxPesquisarNomeAula;
        private Button buttonBuscarAulas;
        private Button buttonVoltarAulas;
        private Panel panel1;
        private Label label7;
        private PictureBox pictureBox2;
        private Label label6;
        private PictureBox pictureBox1;
        private Panel panel4;
        private Label label2;
        private Panel panel2;
        private PictureBox pictureBox3;
        private Label label3;
        private Label label4;
        private Panel panel3;
        private Label label9;
        private Button buttonAulasPDF;
    }
}