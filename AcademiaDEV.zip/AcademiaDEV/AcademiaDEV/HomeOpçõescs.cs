﻿using System;
using System.Windows.Forms;

namespace AcademiaDEV
{
    public partial class HomeOpçõescs : Form
    {
        private string usuarioLogado;
        private string senhaLogada;

        public HomeOpçõescs(string usuario, string senha)
        {
            InitializeComponent();
            usuarioLogado = usuario;
            senhaLogada = senha;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void HomeOpçõescs_Load(object sender, EventArgs e)
        {
            AtualizarLabels();
        }

        private void AtualizarLabels()
        {
            // Atualiza as labels com os valores atuais
            labelNomeUsuario.Text = !string.IsNullOrEmpty(usuarioLogado) ? usuarioLogado : "Usuário não encontrado";
        }

        private void buttonProdutos_Click(object sender, EventArgs e)
        {
            string conection_restrita = @"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None;";
            Produtos produto = new Produtos(conection_restrita, usuarioLogado);
            produto.ShowDialog();
        }

        private void buttonPlanos_Click(object sender, EventArgs e)
        {
            Planos planos = new Planos(usuarioLogado);
            planos.ShowDialog();
        }

        private void buttonPagamentos_Click(object sender, EventArgs e)
        {
            Pagamentos pagamentos = new Pagamentos(usuarioLogado);
            pagamentos.ShowDialog();
        }

        private void buttonFuncionarios_Click(object sender, EventArgs e)
        {
            Funcionario funcionarios = new Funcionario(usuarioLogado);
            funcionarios.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Aulas aulas = new Aulas(usuarioLogado);
            aulas.ShowDialog();
        }

        private void buttonAlunos_Click(object sender, EventArgs e)
        {
            // Abre a tela de Alunos
            Alunos alunos = new Alunos(usuarioLogado);
            alunos.ShowDialog(); // Exibe a tela como um diálogo
        }

        private void buttonAlterarSenha_Click(object sender, EventArgs e)
        {
            EditarUsuario editarUsuario = new EditarUsuario(usuarioLogado, senhaLogada);
            if (editarUsuario.ShowDialog() == DialogResult.OK) // Verifica se as credenciais foram alteradas
            {
                usuarioLogado = editarUsuario.NovoUsuario; // Atualiza usuário logado
                senhaLogada = editarUsuario.NovaSenha; // Atualiza senha logada
                AtualizarLabels(); // Atualiza as labels com as novas credenciais
            }
        }

        private void buttonSair_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Você tem certeza que deseja sair?", "Confirmar Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        private void buttonSobreNos_Click(object sender, EventArgs e) {
            MessageBox.Show("Sou Ezequiel desenvolvedor de software!");


        }

        // Se houver lógica a ser implementada, coloque aqui
        private void label6_Click(object sender, EventArgs e) { }
        private void labelNomeUsuario_Click(object sender, EventArgs e) { }
        private void panel7_Paint(object sender, PaintEventArgs e) { }
    }
}
