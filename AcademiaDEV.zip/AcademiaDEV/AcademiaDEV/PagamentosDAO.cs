﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

public class PagamentosDAO
{
    private readonly string connectionString;

    public PagamentosDAO(string connectionString)
    {
        this.connectionString = connectionString;
    }

    // Classe interna Pagamento
    public class Pagamento
    {
        public int PagamentoId { get; set; }
        public string NomeAluno { get; set; }
        public string AlunoCpf { get; set; }  // Alterado para seguir a convenção camelCase
        public string TipoPlano { get; set; }
        public DateTime DataPagamento { get; set; }
        public string FormaPagamento { get; set; }    // Valores permitidos: 'Cartao', 'Pix', 'Dinheiro'
        public string StatusPagamento { get; set; }   // Valores permitidos: 'Pago', 'Pendente'
    }

    // Método para adicionar um novo pagamento
    public void AddPagamento(Pagamento pagamento)
    {
        using (var connection = new MySqlConnection(connectionString))
        {
            string query = "INSERT INTO Pagamentos (nome_aluno, aluno_CPF, tipo_plano, data_pagamento, forma_pagamento, status_pagamento) " +
                           "VALUES (@NomeAluno, @AlunoCpf, @TipoPlano, @DataPagamento, @FormaPagamento, @StatusPagamento)";  // Alterado para usar AlunoCpf

            using (var command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@NomeAluno", pagamento.NomeAluno);
                command.Parameters.AddWithValue("@AlunoCpf", pagamento.AlunoCpf);  // Alterado para usar AlunoCpf
                command.Parameters.AddWithValue("@TipoPlano", pagamento.TipoPlano);
                command.Parameters.AddWithValue("@DataPagamento", pagamento.DataPagamento);
                command.Parameters.AddWithValue("@FormaPagamento", pagamento.FormaPagamento);
                command.Parameters.AddWithValue("@StatusPagamento", pagamento.StatusPagamento);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    // Método para verificar se existe um pagamento para o CPF fornecido
    public bool PagamentoExiste(string alunoCpf)  // Alterado para usar alunoCpf
    {
        using (var connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT COUNT(1) FROM Pagamentos WHERE aluno_CPF = @AlunoCpf";  // Alterado para usar AlunoCpf
            using (var command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@AlunoCpf", alunoCpf);  // Alterado para usar AlunoCpf
                connection.Open();
                int count = Convert.ToInt32(command.ExecuteScalar());
                return count > 0; // Retorna true se o CPF foi encontrado
            }
        }
    }

    // Método para obter um pagamento por CPF do aluno
    public Pagamento GetPagamentoByCpfAluno(string cpfAluno)  // Alterado para usar cpfAluno
    {
        using (var connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT pagamento_id, nome_aluno, aluno_CPF, tipo_plano, data_pagamento, forma_pagamento, status_pagamento " +
                           "FROM Pagamentos WHERE aluno_CPF = @AlunoCpf";  // Alterado para usar AlunoCpf

            using (var command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@AlunoCpf", cpfAluno);  // Alterado para usar AlunoCpf

                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Pagamento
                        {
                            PagamentoId = reader.GetInt32(0),
                            NomeAluno = reader.GetString(1),
                            AlunoCpf = reader.GetString(2),  // Alterado para usar AlunoCpf
                            TipoPlano = reader.GetString(3),
                            DataPagamento = reader.GetDateTime(4),
                            FormaPagamento = reader.GetString(5),
                            StatusPagamento = reader.GetString(6)
                        };
                    }
                }
            }
        }
        return null;
    }

    // Método para atualizar um pagamento
    public void UpdatePagamento(Pagamento pagamento)
    {
        using (var connection = new MySqlConnection(connectionString))
        {
            string query = "UPDATE Pagamentos SET nome_aluno = @NomeAluno, aluno_CPF = @AlunoCpf, tipo_plano = @TipoPlano, " +
                           "data_pagamento = @DataPagamento, forma_pagamento = @FormaPagamento, status_pagamento = @StatusPagamento " +
                           "WHERE pagamento_id = @PagamentoId";

            using (var command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@PagamentoId", pagamento.PagamentoId);
                command.Parameters.AddWithValue("@NomeAluno", pagamento.NomeAluno);
                command.Parameters.AddWithValue("@AlunoCpf", pagamento.AlunoCpf);  // Alterado para usar AlunoCpf
                command.Parameters.AddWithValue("@TipoPlano", pagamento.TipoPlano);
                command.Parameters.AddWithValue("@DataPagamento", pagamento.DataPagamento);
                command.Parameters.AddWithValue("@FormaPagamento", pagamento.FormaPagamento);
                command.Parameters.AddWithValue("@StatusPagamento", pagamento.StatusPagamento);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    // Método para excluir um pagamento
    public void DeletePagamento(string alunoCpf)  // Alterado para usar alunoCpf
    {
        using (var connection = new MySqlConnection(connectionString))
        {
            string query = "DELETE FROM Pagamentos WHERE aluno_CPF = @AlunoCpf";  // Alterado para usar AlunoCpf

            using (var command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@AlunoCpf", alunoCpf);  // Alterado para usar AlunoCpf

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    // Método para listar todos os pagamentos
    public List<Pagamento> GetAllPagamentos()
    {
        var pagamentos = new List<Pagamento>();

        using (var connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT pagamento_id, nome_aluno, aluno_CPF, tipo_plano, data_pagamento, forma_pagamento, status_pagamento FROM Pagamentos";

            using (var command = new MySqlCommand(query, connection))
            {
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        pagamentos.Add(new Pagamento
                        {
                            PagamentoId = reader.GetInt32(0),
                            NomeAluno = reader.GetString(1),
                            AlunoCpf = reader.GetString(2),  // Alterado para usar AlunoCpf
                            TipoPlano = reader.GetString(3),
                            DataPagamento = reader.GetDateTime(4),
                            FormaPagamento = reader.GetString(5),
                            StatusPagamento = reader.GetString(6)
                        });
                    }
                }
            }
        }

        return pagamentos;
    }
}
