﻿namespace AcademiaDEV
{
    partial class Alunos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Alunos));
            buttonExcluir = new Button();
            dataGridViewAlunos = new DataGridView();
            buttonAtualizarAluno = new Button();
            buttonCadastarAluno = new Button();
            buttonBuscarAlunos = new Button();
            textBoxPesquisarAluno = new TextBox();
            panel1 = new Panel();
            buttonAlunoPDF = new Button();
            label7 = new Label();
            pictureBox2 = new PictureBox();
            label6 = new Label();
            buttonVoltarAlunos = new Button();
            pictureBox1 = new PictureBox();
            panel4 = new Panel();
            label4 = new Label();
            label5 = new Label();
            panel2 = new Panel();
            pictureBox3 = new PictureBox();
            label3 = new Label();
            panel3 = new Panel();
            buttonEditar = new Button();
            label9 = new Label();
            sqlCommandBuilder1 = new Microsoft.Data.SqlClient.SqlCommandBuilder();
            ((System.ComponentModel.ISupportInitialize)dataGridViewAlunos).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel4.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // buttonExcluir
            // 
            buttonExcluir.BackColor = Color.FromArgb(255, 192, 192);
            buttonExcluir.Cursor = Cursors.Hand;
            buttonExcluir.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonExcluir.Image = Properties.Resources.icons8_trash_can_48;
            buttonExcluir.ImageAlign = ContentAlignment.MiddleLeft;
            buttonExcluir.Location = new Point(510, 18);
            buttonExcluir.Name = "buttonExcluir";
            buttonExcluir.Size = new Size(232, 85);
            buttonExcluir.TabIndex = 9;
            buttonExcluir.Text = "Excluir";
            buttonExcluir.UseVisualStyleBackColor = false;
            buttonExcluir.Click += buttonExcluir_Click;
            // 
            // dataGridViewAlunos
            // 
            dataGridViewAlunos.BackgroundColor = SystemColors.AppWorkspace;
            dataGridViewAlunos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewAlunos.Location = new Point(19, 179);
            dataGridViewAlunos.Name = "dataGridViewAlunos";
            dataGridViewAlunos.RowHeadersWidth = 51;
            dataGridViewAlunos.Size = new Size(982, 333);
            dataGridViewAlunos.TabIndex = 10;
            // 
            // buttonAtualizarAluno
            // 
            buttonAtualizarAluno.BackColor = Color.FromArgb(255, 224, 192);
            buttonAtualizarAluno.Cursor = Cursors.Hand;
            buttonAtualizarAluno.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonAtualizarAluno.Image = Properties.Resources.icons8_synchronize_52;
            buttonAtualizarAluno.ImageAlign = ContentAlignment.MiddleLeft;
            buttonAtualizarAluno.Location = new Point(272, 17);
            buttonAtualizarAluno.Name = "buttonAtualizarAluno";
            buttonAtualizarAluno.Size = new Size(232, 85);
            buttonAtualizarAluno.TabIndex = 11;
            buttonAtualizarAluno.Text = "Atualizar";
            buttonAtualizarAluno.UseVisualStyleBackColor = false;
            buttonAtualizarAluno.Click += buttonAtualizarAluno_Click;
            // 
            // buttonCadastarAluno
            // 
            buttonCadastarAluno.BackColor = Color.FromArgb(192, 255, 192);
            buttonCadastarAluno.Cursor = Cursors.Hand;
            buttonCadastarAluno.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonCadastarAluno.Image = Properties.Resources.icons8_adicionar_usuário_masculino_grande2;
            buttonCadastarAluno.ImageAlign = ContentAlignment.MiddleLeft;
            buttonCadastarAluno.Location = new Point(34, 17);
            buttonCadastarAluno.Name = "buttonCadastarAluno";
            buttonCadastarAluno.Size = new Size(232, 85);
            buttonCadastarAluno.TabIndex = 12;
            buttonCadastarAluno.Text = "Cadastrar";
            buttonCadastarAluno.UseVisualStyleBackColor = false;
            buttonCadastarAluno.Click += buttonCadastarAluno_Click;
            // 
            // buttonBuscarAlunos
            // 
            buttonBuscarAlunos.BackColor = Color.FromArgb(224, 224, 224);
            buttonBuscarAlunos.Cursor = Cursors.Hand;
            buttonBuscarAlunos.Image = Properties.Resources.icons8_pesquisar_48;
            buttonBuscarAlunos.Location = new Point(1215, 121);
            buttonBuscarAlunos.Name = "buttonBuscarAlunos";
            buttonBuscarAlunos.Size = new Size(112, 60);
            buttonBuscarAlunos.TabIndex = 13;
            buttonBuscarAlunos.UseVisualStyleBackColor = false;
            buttonBuscarAlunos.Click += buttonBuscarAlunos_Click;
            // 
            // textBoxPesquisarAluno
            // 
            textBoxPesquisarAluno.BackColor = Color.Gainsboro;
            textBoxPesquisarAluno.BorderStyle = BorderStyle.None;
            textBoxPesquisarAluno.Location = new Point(184, 16);
            textBoxPesquisarAluno.Multiline = true;
            textBoxPesquisarAluno.Name = "textBoxPesquisarAluno";
            textBoxPesquisarAluno.Size = new Size(467, 27);
            textBoxPesquisarAluno.TabIndex = 14;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(buttonAlunoPDF);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(buttonVoltarAlunos);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(410, 761);
            panel1.TabIndex = 24;
            // 
            // buttonAlunoPDF
            // 
            buttonAlunoPDF.BackColor = Color.FromArgb(255, 192, 128);
            buttonAlunoPDF.Cursor = Cursors.Hand;
            buttonAlunoPDF.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonAlunoPDF.Image = Properties.Resources.icons8_pdf_2_48;
            buttonAlunoPDF.ImageAlign = ContentAlignment.MiddleLeft;
            buttonAlunoPDF.Location = new Point(48, 582);
            buttonAlunoPDF.Name = "buttonAlunoPDF";
            buttonAlunoPDF.Size = new Size(301, 60);
            buttonAlunoPDF.TabIndex = 31;
            buttonAlunoPDF.Text = "PDF Alunos";
            buttonAlunoPDF.UseVisualStyleBackColor = false;
            buttonAlunoPDF.Click += buttonAlunoPDF_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(63, 421);
            label7.Name = "label7";
            label7.Size = new Size(273, 75);
            label7.TabIndex = 24;
            label7.Text = "  Faça o cadastro de alunos\r\n informando suas informações\r\npessoais e cadastre no sistema.";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(148, 31);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(105, 39);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 25;
            pictureBox2.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Black", 18F);
            label6.ForeColor = Color.White;
            label6.Location = new Point(134, 359);
            label6.Name = "label6";
            label6.Size = new Size(129, 42);
            label6.TabIndex = 24;
            label6.Text = "Alunos";
            // 
            // buttonVoltarAlunos
            // 
            buttonVoltarAlunos.BackColor = Color.Gainsboro;
            buttonVoltarAlunos.Cursor = Cursors.Hand;
            buttonVoltarAlunos.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonVoltarAlunos.Image = Properties.Resources.icons8_voltar_48;
            buttonVoltarAlunos.ImageAlign = ContentAlignment.MiddleLeft;
            buttonVoltarAlunos.Location = new Point(48, 648);
            buttonVoltarAlunos.Name = "buttonVoltarAlunos";
            buttonVoltarAlunos.Size = new Size(301, 50);
            buttonVoltarAlunos.TabIndex = 13;
            buttonVoltarAlunos.Text = "Voltar";
            buttonVoltarAlunos.UseVisualStyleBackColor = false;
            buttonVoltarAlunos.Click += buttonVoltarAlunos_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(148, 252);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(105, 108);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Black;
            panel4.Controls.Add(label4);
            panel4.Controls.Add(label5);
            panel4.Location = new Point(445, 12);
            panel4.Name = "panel4";
            panel4.Size = new Size(1023, 87);
            panel4.TabIndex = 28;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Black", 11F);
            label4.ForeColor = Color.White;
            label4.Location = new Point(872, 31);
            label4.Name = "label4";
            label4.Size = new Size(134, 27);
            label4.TabIndex = 26;
            label4.Text = "Bem vindo !";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI Black", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(40, 23);
            label5.Name = "label5";
            label5.Size = new Size(258, 35);
            label5.TabIndex = 6;
            label5.Text = "Cadastro de alunos.";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(textBoxPesquisarAluno);
            panel2.Location = new Point(539, 121);
            panel2.Name = "panel2";
            panel2.Size = new Size(670, 60);
            panel2.TabIndex = 29;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(7, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(46, 54);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 26;
            pictureBox3.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 10F);
            label3.ForeColor = Color.FromArgb(64, 64, 64);
            label3.Location = new Point(59, 16);
            label3.Name = "label3";
            label3.Size = new Size(119, 23);
            label3.TabIndex = 15;
            label3.Text = "Pesquisar CPF:";
            // 
            // panel3
            // 
            panel3.BackColor = Color.Black;
            panel3.Controls.Add(buttonEditar);
            panel3.Controls.Add(label9);
            panel3.Controls.Add(dataGridViewAlunos);
            panel3.Controls.Add(buttonCadastarAluno);
            panel3.Controls.Add(buttonAtualizarAluno);
            panel3.Controls.Add(buttonExcluir);
            panel3.Location = new Point(445, 213);
            panel3.Name = "panel3";
            panel3.Size = new Size(1023, 536);
            panel3.TabIndex = 30;
            // 
            // buttonEditar
            // 
            buttonEditar.BackColor = Color.FromArgb(192, 192, 255);
            buttonEditar.Cursor = Cursors.Hand;
            buttonEditar.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonEditar.Image = Properties.Resources.icons8_editar_48;
            buttonEditar.ImageAlign = ContentAlignment.MiddleLeft;
            buttonEditar.Location = new Point(748, 18);
            buttonEditar.Name = "buttonEditar";
            buttonEditar.Size = new Size(232, 86);
            buttonEditar.TabIndex = 28;
            buttonEditar.Text = "Editar";
            buttonEditar.UseVisualStyleBackColor = false;
            buttonEditar.Click += buttonEditar_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(24, 137);
            label9.Name = "label9";
            label9.Size = new Size(205, 23);
            label9.TabIndex = 26;
            label9.Text = "Dados salvo do alunos.";
            // 
            // Alunos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1480, 761);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel4);
            Controls.Add(panel1);
            Controls.Add(buttonBuscarAlunos);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Alunos";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Alunos";
            Load += Alunos_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewAlunos).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Button buttonExcluir;
        private DataGridView dataGridViewAlunos;
        private Button buttonAtualizarAluno;
        private Button buttonCadastarAluno;
        private Button buttonBuscarAlunos;
        private TextBox textBoxPesquisarAluno;
        private Panel panel1;
        private Label label7;
        private PictureBox pictureBox2;
        private Label label6;
        private Button buttonVoltarAlunos;
        private PictureBox pictureBox1;
        private Panel panel4;
        private Label label4;
        private Label label5;
        private Panel panel2;
        private PictureBox pictureBox3;
        private Label label3;
        private Panel panel3;
        private Label label9;
        private Button buttonEditar;
        private Button buttonAlunoPDF;
        private Microsoft.Data.SqlClient.SqlCommandBuilder sqlCommandBuilder1;
    }
}