﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using GenCode128;

namespace AcademiaDEV
{
    public partial class CadastroProdutos : Form
    {
        private string connectionString = @"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None;";
        private string pastaImagens = @"D:\\Apresentação Seminario\\sistema\\AcademiaDEV\\COD";

        public CadastroProdutos()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void buttonCadastrar_Click(object sender, EventArgs e)
        {
            // Gera um código de barras de 12 dígitos
            string codigoDeBarras = GerarCodigoBarras();

            // Gera o código de barras
            GerarCodigoDeBarras(codigoDeBarras);

            // Coleta os dados dos TextBox
            AdicionarProduto(codigoDeBarras);
        }

        private string GerarCodigoBarras()
        {
            Random random = new Random();
            string codigo = string.Empty;

            for (int i = 0; i < 12; i++)
            {
                codigo += random.Next(0, 10).ToString(); // Gera um número entre 0 e 9
            }

            return codigo;
        }

        private void GerarCodigoDeBarras(string codigoDeBarras)
        {
            Image barcodeImage = Code128Rendering.MakeBarcodeImage(codigoDeBarras, 300, true);

            if (barcodeImage != null)
            {
                Bitmap bitmap = new Bitmap(barcodeImage);

                if (bitmap.GetPixel(0, 0).A != 0)
                {
                    string caminhoImagem = Path.Combine(pastaImagens, codigoDeBarras + ".png");
                    bitmap.Save(caminhoImagem, System.Drawing.Imaging.ImageFormat.Png);

                    pictureBoxCodigoBarras.Image = bitmap;
                    pictureBoxCodigoBarras.SizeMode = PictureBoxSizeMode.StretchImage;
                }
                else
                {
                    MessageBox.Show("A imagem gerada está em branco.");
                }
            }
            else
            {
                MessageBox.Show("Erro ao gerar o código de barras.");
            }
        }

        private void AdicionarProduto(string codigoDeBarras)
        {
            string nomeProduto = textBoxNomeProduto.Text.Trim();
            string descricao = textBoxDescricao.Text.Trim();
            decimal preco;
            int quantidade;
            string unidade = textBoxUnidade.Text.Trim();

            if (!decimal.TryParse(textBoxPreco.Text.Trim(), out preco) || !int.TryParse(textBoxQuantidade.Text.Trim(), out quantidade))
            {
                MessageBox.Show("Preço ou quantidade inválidos. Por favor, insira valores válidos.");
                return;
            }

            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Produtos (codigo_do_produto, nome_produto, descricao, preco, quantidade, unidade) " +
                               "VALUES (@codigo, @nome, @descricao, @preco, @quantidade, @unidade)";

                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@codigo", codigoDeBarras);
                command.Parameters.AddWithValue("@nome", nomeProduto);
                command.Parameters.AddWithValue("@descricao", descricao);
                command.Parameters.AddWithValue("@preco", preco);
                command.Parameters.AddWithValue("@quantidade", quantidade);
                command.Parameters.AddWithValue("@unidade", unidade);

                try
                {
                    command.ExecuteNonQuery();
                    MessageBox.Show("Produto adicionado ao banco de dados com sucesso!");
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro ao adicionar produto: " + ex.Message);
                }
            }
        }

        private void buttonCancelarPagamento_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Deseja realmente cancelar?", "Confirmar", MessageBoxButtons.YesNo);
            if (resultado == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void CadastroProdutos_Load(object sender, EventArgs e)
        {

        }
    }
}
