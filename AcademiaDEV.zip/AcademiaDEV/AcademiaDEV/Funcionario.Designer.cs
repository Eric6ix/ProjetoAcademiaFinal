﻿namespace AcademiaDEV
{
    partial class Funcionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Funcionario));
            buttonDelete = new Button();
            dataGridView = new DataGridView();
            buttonAtualizar = new Button();
            buttonVoltar = new Button();
            textPesquisa = new TextBox();
            buttonCadastrarFuncionarios = new Button();
            label2 = new Label();
            panel1 = new Panel();
            buttonFuncionarioPDF = new Button();
            label7 = new Label();
            pictureBox2 = new PictureBox();
            label6 = new Label();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            panel2 = new Panel();
            pictureBox3 = new PictureBox();
            label3 = new Label();
            buttonEditarFuncionario = new Button();
            panel3 = new Panel();
            label9 = new Label();
            panel4 = new Panel();
            pictureBox4 = new PictureBox();
            label4 = new Label();
            buttonBuscar = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // buttonDelete
            // 
            buttonDelete.BackColor = Color.FromArgb(255, 192, 192);
            buttonDelete.Cursor = Cursors.Hand;
            buttonDelete.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonDelete.Image = Properties.Resources.icons8_trash_can_48;
            buttonDelete.ImageAlign = ContentAlignment.MiddleLeft;
            buttonDelete.Location = new Point(519, 14);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(232, 85);
            buttonDelete.TabIndex = 8;
            buttonDelete.Text = "Excluir";
            buttonDelete.UseVisualStyleBackColor = false;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // dataGridView
            // 
            dataGridView.BackgroundColor = SystemColors.AppWorkspace;
            dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView.Cursor = Cursors.IBeam;
            dataGridView.Location = new Point(24, 179);
            dataGridView.Name = "dataGridView";
            dataGridView.RowHeadersWidth = 51;
            dataGridView.Size = new Size(982, 326);
            dataGridView.TabIndex = 9;
            // 
            // buttonAtualizar
            // 
            buttonAtualizar.BackColor = Color.FromArgb(255, 224, 192);
            buttonAtualizar.Cursor = Cursors.Hand;
            buttonAtualizar.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonAtualizar.Image = Properties.Resources.icons8_synchronize_52;
            buttonAtualizar.ImageAlign = ContentAlignment.MiddleLeft;
            buttonAtualizar.Location = new Point(281, 14);
            buttonAtualizar.Name = "buttonAtualizar";
            buttonAtualizar.Size = new Size(232, 85);
            buttonAtualizar.TabIndex = 11;
            buttonAtualizar.Text = "Atualizar";
            buttonAtualizar.UseVisualStyleBackColor = false;
            buttonAtualizar.Click += buttonAtualizar_Click;
            // 
            // buttonVoltar
            // 
            buttonVoltar.BackColor = Color.Gainsboro;
            buttonVoltar.Cursor = Cursors.Hand;
            buttonVoltar.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonVoltar.Image = Properties.Resources.icons8_voltar_48;
            buttonVoltar.ImageAlign = ContentAlignment.MiddleLeft;
            buttonVoltar.Location = new Point(48, 648);
            buttonVoltar.Name = "buttonVoltar";
            buttonVoltar.Size = new Size(301, 50);
            buttonVoltar.TabIndex = 13;
            buttonVoltar.Text = "Voltar";
            buttonVoltar.UseVisualStyleBackColor = false;
            buttonVoltar.Click += buttonVoltar_Click;
            // 
            // textPesquisa
            // 
            textPesquisa.BackColor = Color.Gainsboro;
            textPesquisa.BorderStyle = BorderStyle.None;
            textPesquisa.Location = new Point(184, 16);
            textPesquisa.Multiline = true;
            textPesquisa.Name = "textPesquisa";
            textPesquisa.Size = new Size(467, 27);
            textPesquisa.TabIndex = 14;
            // 
            // buttonCadastrarFuncionarios
            // 
            buttonCadastrarFuncionarios.BackColor = Color.FromArgb(192, 255, 192);
            buttonCadastrarFuncionarios.Cursor = Cursors.Hand;
            buttonCadastrarFuncionarios.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonCadastrarFuncionarios.Image = Properties.Resources.icons8_adicionar_usuário_masculino_60;
            buttonCadastrarFuncionarios.ImageAlign = ContentAlignment.MiddleLeft;
            buttonCadastrarFuncionarios.Location = new Point(40, 15);
            buttonCadastrarFuncionarios.Name = "buttonCadastrarFuncionarios";
            buttonCadastrarFuncionarios.Size = new Size(235, 84);
            buttonCadastrarFuncionarios.TabIndex = 15;
            buttonCadastrarFuncionarios.Text = "Cadastrar";
            buttonCadastrarFuncionarios.UseVisualStyleBackColor = false;
            buttonCadastrarFuncionarios.Click += buttonCadastrarFuncionarios_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(599, 340);
            label2.Name = "label2";
            label2.Size = new Size(137, 20);
            label2.TabIndex = 19;
            label2.Text = "Dados funcionarios";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(buttonFuncionarioPDF);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(buttonVoltar);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(410, 761);
            panel1.TabIndex = 23;
            // 
            // buttonFuncionarioPDF
            // 
            buttonFuncionarioPDF.BackColor = Color.FromArgb(255, 192, 128);
            buttonFuncionarioPDF.Cursor = Cursors.Hand;
            buttonFuncionarioPDF.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonFuncionarioPDF.Image = Properties.Resources.icons8_pdf_50;
            buttonFuncionarioPDF.ImageAlign = ContentAlignment.MiddleLeft;
            buttonFuncionarioPDF.Location = new Point(48, 570);
            buttonFuncionarioPDF.Name = "buttonFuncionarioPDF";
            buttonFuncionarioPDF.Size = new Size(301, 60);
            buttonFuncionarioPDF.TabIndex = 32;
            buttonFuncionarioPDF.Text = "PDF Funcionário";
            buttonFuncionarioPDF.UseVisualStyleBackColor = false;
            buttonFuncionarioPDF.Click += buttonFuncionarioPDF_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(84, 404);
            label7.Name = "label7";
            label7.Size = new Size(247, 125);
            label7.TabIndex = 24;
            label7.Text = "Faça o cadastro de um novo\r\nfuncionario colocando suas\r\n          informações\r\n   pessoais e de trabalho\r\n   e cadastre no sistema.";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(148, 31);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(105, 39);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 25;
            pictureBox2.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Black", 18F);
            label6.ForeColor = Color.White;
            label6.Location = new Point(102, 362);
            label6.Name = "label6";
            label6.Size = new Size(229, 42);
            label6.TabIndex = 24;
            label6.Text = "Funcionários";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.icons8_contrato_de_trabalho_100;
            pictureBox1.Location = new Point(148, 252);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(125, 108);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Black", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(88, 23);
            label1.Name = "label1";
            label1.Size = new Size(324, 35);
            label1.TabIndex = 6;
            label1.Text = "Cadastro de funcionários";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(textPesquisa);
            panel2.Location = new Point(545, 122);
            panel2.Name = "panel2";
            panel2.Size = new Size(670, 60);
            panel2.TabIndex = 24;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(7, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(46, 54);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 26;
            pictureBox3.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 10F);
            label3.ForeColor = Color.FromArgb(64, 64, 64);
            label3.Location = new Point(59, 16);
            label3.Name = "label3";
            label3.Size = new Size(119, 23);
            label3.TabIndex = 15;
            label3.Text = "Pesquisar CPF:";
            // 
            // buttonEditarFuncionario
            // 
            buttonEditarFuncionario.BackColor = Color.FromArgb(192, 192, 255);
            buttonEditarFuncionario.Cursor = Cursors.Hand;
            buttonEditarFuncionario.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonEditarFuncionario.Image = Properties.Resources.icons8_editar_48;
            buttonEditarFuncionario.ImageAlign = ContentAlignment.MiddleLeft;
            buttonEditarFuncionario.Location = new Point(757, 14);
            buttonEditarFuncionario.Name = "buttonEditarFuncionario";
            buttonEditarFuncionario.Size = new Size(232, 85);
            buttonEditarFuncionario.TabIndex = 25;
            buttonEditarFuncionario.Text = "Editar";
            buttonEditarFuncionario.UseVisualStyleBackColor = false;
            buttonEditarFuncionario.Click += buttonEditarFuncionario_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Black;
            panel3.Controls.Add(label9);
            panel3.Controls.Add(buttonCadastrarFuncionarios);
            panel3.Controls.Add(buttonEditarFuncionario);
            panel3.Controls.Add(buttonAtualizar);
            panel3.Controls.Add(buttonDelete);
            panel3.Controls.Add(dataGridView);
            panel3.Location = new Point(445, 213);
            panel3.Name = "panel3";
            panel3.Size = new Size(1023, 536);
            panel3.TabIndex = 26;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(24, 137);
            label9.Name = "label9";
            label9.Size = new Size(246, 23);
            label9.TabIndex = 26;
            label9.Text = "Dados salvo do funcionário.";
            // 
            // panel4
            // 
            panel4.BackColor = Color.Black;
            panel4.Controls.Add(pictureBox4);
            panel4.Controls.Add(label4);
            panel4.Controls.Add(label1);
            panel4.Location = new Point(445, 12);
            panel4.Name = "panel4";
            panel4.Size = new Size(1023, 87);
            panel4.TabIndex = 27;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.icons8_contrato_de_trabalho_100;
            pictureBox4.Location = new Point(24, 19);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(58, 39);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 26;
            pictureBox4.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Black", 11F);
            label4.ForeColor = Color.White;
            label4.Location = new Point(872, 31);
            label4.Name = "label4";
            label4.Size = new Size(134, 27);
            label4.TabIndex = 26;
            label4.Text = "Bem vindo !";
            // 
            // buttonBuscar
            // 
            buttonBuscar.BackColor = Color.White;
            buttonBuscar.Cursor = Cursors.Hand;
            buttonBuscar.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonBuscar.Image = Properties.Resources.icons8_pesquisar_48;
            buttonBuscar.Location = new Point(1221, 122);
            buttonBuscar.Name = "buttonBuscar";
            buttonBuscar.Size = new Size(112, 60);
            buttonBuscar.TabIndex = 12;
            buttonBuscar.UseVisualStyleBackColor = false;
            buttonBuscar.Click += buttonBuscar_Click;
            // 
            // Funcionario
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1480, 761);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(label2);
            Controls.Add(buttonBuscar);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Funcionario";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Funcionario";
            Load += Funcionario_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button buttonDelete;
        private DataGridView dataGridView;
        private Button buttonAtualizar;
        private Button buttonVoltar;
        private TextBox textPesquisa;
        private Button buttonCadastrarFuncionarios;
        private Label label2;
        private Panel panel1;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label6;
        private PictureBox pictureBox2;
        private Label label7;
        private Panel panel2;
        private Label label3;
        private Button buttonEditarFuncionario;
        private PictureBox pictureBox3;
        private Panel panel3;
        private Label label9;
        private Panel panel4;
        private Label label4;
        private Button buttonBuscar;
        private PictureBox pictureBox4;
        private Button buttonFuncionarioPDF;
    }
}