﻿using System;
using System.Windows.Forms;

namespace AcademiaDEV
{
    public partial class CadastrarAula : Form
    {
        public static string ConnectionString = @"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None";
        private AulasDAO aulasDAO;
        private AulasDAO.Aula aulaAtual;

        public CadastrarAula()
        {
            InitializeComponent();
            aulasDAO = new AulasDAO(ConnectionString);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        public CadastrarAula(AulasDAO.Aula aula) : this()
        {
            aulaAtual = aula;
            PreencherCamposAulas(aula);
        }

        private void PreencherCamposAulas(AulasDAO.Aula aula)
        {
            textBoxNomeAula.Text = aula.NomeAula;
            textBoxDescricaoAula.Text = aula.Descricao;
            monthCalendarAula.SetDate(aula.DataAula);
            textBoxInstrutorAula.Text = aula.NomeInstrutor;
            textBoxHorarioInicio.Text = aula.HorarioInicio; // Mudei para string
            textBoxHorarioFim.Text = aula.HorarioFim;       // Mudei para string
            textBoxTreinosAula.Text = aula.Treinos;
        }

        private void buttonAddAula_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxNomeAula.Text) ||
                string.IsNullOrWhiteSpace(textBoxDescricaoAula.Text) ||
                string.IsNullOrWhiteSpace(textBoxInstrutorAula.Text) ||
                string.IsNullOrWhiteSpace(textBoxHorarioInicio.Text) ||
                string.IsNullOrWhiteSpace(textBoxHorarioFim.Text) ||
                string.IsNullOrWhiteSpace(textBoxTreinosAula.Text))
            {
                MessageBox.Show("Todos os campos devem ser preenchidos!");
                return;
            }

            try
            {
                // Validar os horários como strings
                string horarioInicioFormatado = textBoxHorarioInicio.Text;
                string horarioFimFormatado = textBoxHorarioFim.Text;

                // Verifica se os horários estão no formato correto
                if (!TimeSpan.TryParse(horarioInicioFormatado, out _) ||
                    !TimeSpan.TryParse(horarioFimFormatado, out _))
                {
                    MessageBox.Show("Por favor, insira horários válidos no formato HH:mm (ex: 07:00 ou 19:00).");
                    return;
                }

                if (aulaAtual == null) // Criando uma nova aula
                {
                    AulasDAO.Aula novaAula = new AulasDAO.Aula
                    {
                        NomeAula = textBoxNomeAula.Text,
                        Descricao = textBoxDescricaoAula.Text,
                        NomeInstrutor = textBoxInstrutorAula.Text,
                        HorarioInicio = horarioInicioFormatado, // Mudei para string
                        HorarioFim = horarioFimFormatado,       // Mudei para string
                        DataAula = monthCalendarAula.SelectionStart,
                        Treinos = textBoxTreinosAula.Text
                    };

                    aulasDAO.AddAula(novaAula);
                    MessageBox.Show("Aula adicionada com sucesso!");
                }
                else // Editando uma aula existente
                {
                    aulaAtual.NomeAula = textBoxNomeAula.Text;
                    aulaAtual.Descricao = textBoxDescricaoAula.Text;
                    aulaAtual.NomeInstrutor = textBoxInstrutorAula.Text;
                    aulaAtual.HorarioInicio = horarioInicioFormatado; // Mudei para string
                    aulaAtual.HorarioFim = horarioFimFormatado;       // Mudei para string
                    aulaAtual.DataAula = monthCalendarAula.SelectionStart;
                    aulaAtual.Treinos = textBoxTreinosAula.Text;

                    aulasDAO.UpdateAula(aulaAtual);
                    MessageBox.Show("Aula atualizada com sucesso!");
                }

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro: {ex.Message}");
            }
        }

        private void CadastrarAula_Load(object sender, EventArgs e)
        {
            // Implementar lógica se necessário
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            // Implementar lógica se necessário
        }

        private void buttonCancelarAulas_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Deseja realmente cancelar?", "Confirmar", MessageBoxButtons.YesNo);
            if (resultado == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
