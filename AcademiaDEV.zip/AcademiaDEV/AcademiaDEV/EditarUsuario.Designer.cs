﻿namespace AcademiaDEV
{
    partial class EditarUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditarUsuario));
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            textBoxUsuarioEditar = new TextBox();
            label1 = new Label();
            panel2 = new Panel();
            pictureBox3 = new PictureBox();
            textBoxSenhaEditar = new TextBox();
            label2 = new Label();
            buttonSalvarEdicao = new Button();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkGray;
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(textBoxUsuarioEditar);
            panel1.Location = new Point(62, 209);
            panel1.Name = "panel1";
            panel1.Size = new Size(449, 52);
            panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(3, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(73, 43);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 17;
            pictureBox2.TabStop = false;
            // 
            // textBoxUsuarioEditar
            // 
            textBoxUsuarioEditar.AccessibleName = "";
            textBoxUsuarioEditar.BackColor = Color.Gainsboro;
            textBoxUsuarioEditar.BorderStyle = BorderStyle.None;
            textBoxUsuarioEditar.Font = new Font("Segoe UI", 9F);
            textBoxUsuarioEditar.Location = new Point(89, 20);
            textBoxUsuarioEditar.Multiline = true;
            textBoxUsuarioEditar.Name = "textBoxUsuarioEditar";
            textBoxUsuarioEditar.Size = new Size(335, 20);
            textBoxUsuarioEditar.TabIndex = 16;
            textBoxUsuarioEditar.TextAlign = HorizontalAlignment.Center;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 10F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(62, 183);
            label1.Name = "label1";
            label1.Size = new Size(188, 23);
            label1.TabIndex = 18;
            label1.Text = "Seu usuario cadastrado";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Silver;
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(textBoxSenhaEditar);
            panel2.Location = new Point(65, 327);
            panel2.Name = "panel2";
            panel2.Size = new Size(449, 49);
            panel2.TabIndex = 1;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(10, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(73, 43);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 18;
            pictureBox3.TabStop = false;
            // 
            // textBoxSenhaEditar
            // 
            textBoxSenhaEditar.AccessibleName = "";
            textBoxSenhaEditar.BackColor = Color.Gainsboro;
            textBoxSenhaEditar.BorderStyle = BorderStyle.None;
            textBoxSenhaEditar.Font = new Font("Segoe UI", 9F);
            textBoxSenhaEditar.Location = new Point(89, 15);
            textBoxSenhaEditar.Multiline = true;
            textBoxSenhaEditar.Name = "textBoxSenhaEditar";
            textBoxSenhaEditar.Size = new Size(335, 18);
            textBoxSenhaEditar.TabIndex = 17;
            textBoxSenhaEditar.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 10F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(65, 301);
            label2.Name = "label2";
            label2.Size = new Size(177, 23);
            label2.TabIndex = 19;
            label2.Text = "Sua senha cadastrado";
            // 
            // buttonSalvarEdicao
            // 
            buttonSalvarEdicao.BackColor = Color.FromArgb(192, 255, 192);
            buttonSalvarEdicao.Cursor = Cursors.Hand;
            buttonSalvarEdicao.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonSalvarEdicao.Image = Properties.Resources.icons8_voltar_481;
            buttonSalvarEdicao.ImageAlign = ContentAlignment.MiddleLeft;
            buttonSalvarEdicao.Location = new Point(108, 443);
            buttonSalvarEdicao.Name = "buttonSalvarEdicao";
            buttonSalvarEdicao.Size = new Size(335, 42);
            buttonSalvarEdicao.TabIndex = 3;
            buttonSalvarEdicao.Text = "Salvar";
            buttonSalvarEdicao.UseVisualStyleBackColor = false;
            buttonSalvarEdicao.Click += buttonSalvarEdicao_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(211, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(128, 106);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 15;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI Black", 12.2F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(108, 118);
            label3.Name = "label3";
            label3.Size = new Size(335, 30);
            label3.TabIndex = 16;
            label3.Text = "Edite sua informações de login!";
            // 
            // EditarUsuario
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(561, 583);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(label3);
            Controls.Add(pictureBox1);
            Controls.Add(buttonSalvarEdicao);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "EditarUsuario";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EditarUsuario";
            Load += EditarUsuario_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Button buttonSalvarEdicao;
        private PictureBox pictureBox1;
        private TextBox textBoxUsuarioEditar;
        private TextBox textBoxSenhaEditar;
        private Label label3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private Label label1;
        private Label label2;
    }
}