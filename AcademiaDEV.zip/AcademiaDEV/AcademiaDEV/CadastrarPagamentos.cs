﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static PagamentosDAO;

namespace AcademiaDEV
{
    public partial class CadastrarPagamentos : Form
    {
        string connectionString = @"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None";
        private readonly PagamentosDAO pagamentosDAO;
        private PagamentosDAO.Pagamento pagamentoAtual;
        public CadastrarPagamentos()
        {

            pagamentosDAO = new PagamentosDAO(connectionString);
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }
        public CadastrarPagamentos(PagamentosDAO.Pagamento pagamento) : this()
        {
            pagamentoAtual = pagamento;
            PreencherCamposPagamentos(pagamento);
        }

        private void PreencherCamposPagamentos(PagamentosDAO.Pagamento pagamento)
        {


            textBoxNomeAluno.Text = pagamento.NomeAluno;
            textBoxAlunoCPF.Text = pagamento.AlunoCpf;
            textBoxTipoPlano.Text = pagamento.TipoPlano;
            monthCalendarPg.SetDate(pagamento.DataPagamento);

            textBoxFormaDePagamento.Text = pagamento.FormaPagamento; // Mudei para string
            textBoxStatusPagamento.Text = pagamento.StatusPagamento;
        }

        private void CadastrarPagamentos_Load(object sender, EventArgs e)
        {

        }

        private void buttonAddPagamento_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBoxNomeAluno.Text) || string.IsNullOrWhiteSpace(textBoxAlunoCPF.Text))
                {
                    MessageBox.Show("Os campos Nome e CPF são obrigatórios!");
                    return;
                }

                var pagamentoNovo = new PagamentosDAO.Pagamento
                {
                    NomeAluno = textBoxNomeAluno.Text,
                    AlunoCpf = textBoxAlunoCPF.Text,
                    TipoPlano = textBoxTipoPlano.Text,
                    DataPagamento = monthCalendarPg.SelectionStart,
                    FormaPagamento = textBoxFormaDePagamento.Text,
                    StatusPagamento = textBoxStatusPagamento.Text
                };

                if (pagamentoAtual == null) // Se estamos adicionando
                {
                    pagamentosDAO.AddPagamento(pagamentoNovo); // Adiciona o novo pagamento
                    MessageBox.Show("Pagamento adicionado com sucesso!");
                }
                else // Se estamos editando
                {
                    // Atualize as propriedades do pagamento atual com os valores dos campos de texto
                    pagamentoAtual.NomeAluno = textBoxNomeAluno.Text;
                    pagamentoAtual.AlunoCpf = textBoxAlunoCPF.Text;
                    pagamentoAtual.TipoPlano = textBoxTipoPlano.Text;
                    pagamentoAtual.DataPagamento = monthCalendarPg.SelectionStart;
                    pagamentoAtual.FormaPagamento = textBoxFormaDePagamento.Text;
                    pagamentoAtual.StatusPagamento = textBoxStatusPagamento.Text;

                    pagamentosDAO.UpdatePagamento(pagamentoAtual); // Atualiza o pagamento existente
                    MessageBox.Show("Pagamento atualizado com sucesso!");
                }

                this.Close(); // Fecha o formulário após adicionar ou atualizar
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro: {ex.Message}");
            }
        }

        private void buttonCancelarPagamentos_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Deseja realmente cancelar?", "Confirmar", MessageBoxButtons.YesNo);
            if (resultado == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
