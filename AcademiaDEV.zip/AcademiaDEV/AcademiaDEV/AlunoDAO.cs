﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

public class AlunoDAO
{
    private readonly string connectionString;

    public AlunoDAO(string connectionString)
    {
        this.connectionString = connectionString;
    }

    // Classe Aluno definida internamente
    public class Aluno
    {
        public int AlunoId { get; set; }
        public string Nome { get; set; }
        public string CPF { get; set; }
        public DateTime DataNascimento { get; set; }
        public string Endereco { get; set; }
        public string Telefone { get; set; }
        public string InformacoesMedicas { get; set; }
        public DateTime DataMatricula { get; set; }
    }

    public void AddAluno(Aluno aluno)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "INSERT INTO Alunos (nome, CPF, data_nascimento, endereco, telefone, informacoes_medicas, data_matricula) " +
                           "VALUES (@Nome, @CPF, @DataNascimento, @Endereco, @Telefone, @InformacoesMedicas, @DataMatricula)";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Nome", aluno.Nome);
                command.Parameters.AddWithValue("@CPF", aluno.CPF);
                command.Parameters.AddWithValue("@DataNascimento", aluno.DataNascimento);
                command.Parameters.AddWithValue("@Endereco", aluno.Endereco ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Telefone", aluno.Telefone ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@InformacoesMedicas", aluno.InformacoesMedicas ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@DataMatricula", aluno.DataMatricula);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    public Aluno GetAlunoByCPF(string cpf_aluno)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT aluno_id, nome, CPF, data_nascimento, endereco, telefone, informacoes_medicas, data_matricula " +
                           "FROM Alunos WHERE CPF = @CPF";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CPF", cpf_aluno);

                connection.Open();
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Aluno
                        {
                            AlunoId = reader.GetInt32(0),
                            Nome = reader.GetString(1),
                            CPF = reader.GetString(2),
                            DataNascimento = reader.GetDateTime(3),
                            Endereco = reader.IsDBNull(4) ? null : reader.GetString(4),
                            Telefone = reader.IsDBNull(5) ? null : reader.GetString(5),
                            InformacoesMedicas = reader.IsDBNull(6) ? null : reader.GetString(6),
                            DataMatricula = reader.GetDateTime(7)
                        };
                    }
                }
            }
        }
        return null;
    }

    public void UpdateAluno(Aluno aluno)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "UPDATE Alunos SET nome = @Nome, CPF = @CPF, data_nascimento = @DataNascimento, " +
                           "endereco = @Endereco, telefone = @Telefone, informacoes_medicas = @InformacoesMedicas, " +
                           "data_matricula = @DataMatricula WHERE aluno_id = @AlunoId";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@AlunoId", aluno.AlunoId);
                command.Parameters.AddWithValue("@Nome", aluno.Nome);
                command.Parameters.AddWithValue("@CPF", aluno.CPF);
                command.Parameters.AddWithValue("@DataNascimento", aluno.DataNascimento);
                command.Parameters.AddWithValue("@Endereco", aluno.Endereco ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Telefone", aluno.Telefone ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@InformacoesMedicas", aluno.InformacoesMedicas ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@DataMatricula", aluno.DataMatricula);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    public void DeleteAluno(string cpf)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "DELETE FROM Alunos WHERE CPF = @CPF";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CPF", cpf);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    public List<Aluno> GetAllAlunos()
    {
        List<Aluno> alunos = new List<Aluno>();

        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT aluno_id, nome, CPF, data_nascimento, endereco, telefone, informacoes_medicas, data_matricula FROM Alunos";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                connection.Open();
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        alunos.Add(new Aluno
                        {
                            AlunoId = reader.GetInt32(0),
                            Nome = reader.GetString(1),
                            CPF = reader.GetString(2),
                            DataNascimento = reader.GetDateTime(3),
                            Endereco = reader.IsDBNull(4) ? null : reader.GetString(4),
                            Telefone = reader.IsDBNull(5) ? null : reader.GetString(5),
                            InformacoesMedicas = reader.IsDBNull(6) ? null : reader.GetString(6),
                            DataMatricula = reader.GetDateTime(7)
                        });
                    }
                }
            }
        }

        return alunos;
    }
}
