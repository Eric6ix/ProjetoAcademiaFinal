﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using System.Data;

public class ProdutoDAO
{
    private readonly string connectionString;

    public ProdutoDAO(string connectionString)
    {
        this.connectionString = connectionString;
    }

    // Método para carregar dados da tabela Produtos em um DataTable
    public DataTable GetData()
    {
        DataTable dataTable = new DataTable();

        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT produto_id, codigo_do_produto, nome_produto, descricao, preco, quantidade, unidade, aluno_id FROM Produtos";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                connection.Open();
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                {
                    adapter.Fill(dataTable);
                }
            }
        }

        return dataTable;
    }

    // Classe Produto definida internamente
    public class Produto
    {
        public int ProdutoId { get; set; }
        public string CodigoDoProduto { get; set; }
        public string NomeProduto { get; set; }
        public string Descricao { get; set; }
        public decimal Preco { get; set; }
        public int Quantidade { get; set; }
        public string Unidade { get; set; }
        public int? AlunoId { get; set; }
    }

    public void AddProduto(Produto produto)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "INSERT INTO Produtos (codigo_do_produto, nome_produto, descricao, preco, quantidade, unidade, aluno_id) " +
                           "VALUES (@CodigoDoProduto, @NomeProduto, @Descricao, @Preco, @Quantidade, @Unidade, @AlunoId)";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CodigoDoProduto", produto.CodigoDoProduto);
                command.Parameters.AddWithValue("@NomeProduto", produto.NomeProduto);
                command.Parameters.AddWithValue("@Descricao", produto.Descricao ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Preco", produto.Preco);
                command.Parameters.AddWithValue("@Quantidade", produto.Quantidade);
                command.Parameters.AddWithValue("@Unidade", produto.Unidade ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@AlunoId", (object)produto.AlunoId ?? DBNull.Value);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    public Produto GetProdutoByCodigo(string codigo_produto)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT produto_id, codigo_do_produto, nome_produto, descricao, preco, quantidade, unidade, aluno_id " +
                           "FROM Produtos WHERE codigo_do_produto = @CodigoDoProduto";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CodigoDoProduto", codigo_produto);

                connection.Open();
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Produto
                        {
                            ProdutoId = reader.GetInt32(0),
                            CodigoDoProduto = reader.GetString(1),
                            NomeProduto = reader.GetString(2),
                            Descricao = reader.IsDBNull(3) ? null : reader.GetString(3),
                            Preco = reader.GetDecimal(4),
                            Quantidade = reader.GetInt32(5),
                            Unidade = reader.IsDBNull(6) ? null : reader.GetString(6),
                            AlunoId = reader.IsDBNull(7) ? (int?)null : reader.GetInt32(7)
                        };
                    }
                }
            }
        }
        return null;
    }

    public void UpdateProduto(Produto produto)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "UPDATE Produtos SET codigo_do_produto = @CodigoDoProduto, nome_produto = @NomeProduto, descricao = @Descricao, " +
                           "preco = @Preco, quantidade = @Quantidade, unidade = @Unidade, aluno_id = @AlunoId WHERE produto_id = @ProdutoId";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@ProdutoId", produto.ProdutoId);
                command.Parameters.AddWithValue("@CodigoDoProduto", produto.CodigoDoProduto);
                command.Parameters.AddWithValue("@NomeProduto", produto.NomeProduto);
                command.Parameters.AddWithValue("@Descricao", produto.Descricao ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Preco", produto.Preco);
                command.Parameters.AddWithValue("@Quantidade", produto.Quantidade);
                command.Parameters.AddWithValue("@Unidade", produto.Unidade ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@AlunoId", (object)produto.AlunoId ?? DBNull.Value);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    public void DeleteProduto(string codigo_produto)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "DELETE FROM Produtos WHERE codigo_do_produto = @CodigoDoProduto";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                // Corrigido: o parâmetro estava sendo adicionado incorretamente
                command.Parameters.AddWithValue("@CodigoDoProduto", codigo_produto);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    public void ReduceQuantity(int produtoId, int quantidade)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "UPDATE Produtos SET quantidade = quantidade - @Quantidade WHERE produto_id = @ProdutoId";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Quantidade", quantidade);
                command.Parameters.AddWithValue("@ProdutoId", produtoId);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    public bool CanReduceQuantity(int produtoId, int quantidade)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT quantidade FROM Produtos WHERE produto_id = @ProdutoId";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@ProdutoId", produtoId);

                connection.Open();
                object result = command.ExecuteScalar();
                if (result != null)
                {
                    int quantidadeAtual = Convert.ToInt32(result);
                    return quantidadeAtual >= quantidade;
                }
            }
        }
        return false;
    }

    public void IncreaseQuantity(string codigoProduto, int quantidadeParaAdicionar)
    {
        using (var connection = new MySqlConnection(connectionString))
        {
            connection.Open();

            // Corrigido: alterado para 'codigo_do_produto' para garantir a consistência
            string query = "UPDATE Produtos SET quantidade = quantidade + @quantidadeParaAdicionar WHERE codigo_do_produto = @codigoProduto";

            using (var command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@quantidadeParaAdicionar", quantidadeParaAdicionar);
                command.Parameters.AddWithValue("@codigoProduto", codigoProduto);

                command.ExecuteNonQuery();
            }
        }
    }


    public List<Produto> GetAllProdutos()
    {
        List<Produto> produtos = new List<Produto>();

        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT produto_id, codigo_do_produto, nome_produto, descricao, preco, quantidade, unidade, aluno_id FROM Produtos";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                connection.Open();
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        produtos.Add(new Produto
                        {
                            ProdutoId = reader.GetInt32(0),
                            CodigoDoProduto = reader.GetString(1),
                            NomeProduto = reader.GetString(2),
                            Descricao = reader.IsDBNull(3) ? null : reader.GetString(3),
                            Preco = reader.GetDecimal(4),
                            Quantidade = reader.GetInt32(5),
                            Unidade = reader.IsDBNull(6) ? null : reader.GetString(6),
                            AlunoId = reader.IsDBNull(7) ? (int?)null : reader.GetInt32(7)
                        });
                    }
                }
            }
        }

        return produtos;
    }
}
