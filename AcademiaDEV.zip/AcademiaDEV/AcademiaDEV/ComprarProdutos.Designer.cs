﻿namespace AcademiaDEV
{
    partial class ComprarProdutos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ComprarProdutos));
            buttonCompraCreatina = new Button();
            numericUpDownQuantidade = new NumericUpDown();
            textBoxCodigoProduto = new TextBox();
            label1 = new Label();
            label6 = new Label();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            buttonAdcionar = new Button();
            panel2 = new Panel();
            pictureBox3 = new PictureBox();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)numericUpDownQuantidade).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // buttonCompraCreatina
            // 
            buttonCompraCreatina.BackColor = Color.FromArgb(255, 192, 192);
            buttonCompraCreatina.Cursor = Cursors.Hand;
            buttonCompraCreatina.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonCompraCreatina.Image = (Image)resources.GetObject("buttonCompraCreatina.Image");
            buttonCompraCreatina.ImageAlign = ContentAlignment.MiddleLeft;
            buttonCompraCreatina.Location = new Point(66, 292);
            buttonCompraCreatina.Name = "buttonCompraCreatina";
            buttonCompraCreatina.Size = new Size(219, 54);
            buttonCompraCreatina.TabIndex = 0;
            buttonCompraCreatina.Text = "Retirar";
            buttonCompraCreatina.UseVisualStyleBackColor = false;
            buttonCompraCreatina.Click += buttonCompraCreatina_Click;
            // 
            // numericUpDownQuantidade
            // 
            numericUpDownQuantidade.Location = new Point(197, 231);
            numericUpDownQuantidade.Name = "numericUpDownQuantidade";
            numericUpDownQuantidade.Size = new Size(223, 27);
            numericUpDownQuantidade.TabIndex = 1;
            // 
            // textBoxCodigoProduto
            // 
            textBoxCodigoProduto.BorderStyle = BorderStyle.FixedSingle;
            textBoxCodigoProduto.Location = new Point(55, 11);
            textBoxCodigoProduto.Multiline = true;
            textBoxCodigoProduto.Name = "textBoxCodigoProduto";
            textBoxCodigoProduto.Size = new Size(308, 27);
            textBoxCodigoProduto.TabIndex = 2;
            textBoxCodigoProduto.TextAlign = HorizontalAlignment.Center;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(124, 231);
            label1.Name = "label1";
            label1.Size = new Size(58, 25);
            label1.TabIndex = 3;
            label1.Text = "Qntd:";
            label1.Click += label1_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Black", 18F);
            label6.ForeColor = Color.White;
            label6.Location = new Point(87, 24);
            label6.Name = "label6";
            label6.Size = new Size(278, 42);
            label6.TabIndex = 25;
            label6.Text = "Retirar Produto ";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(371, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(105, 98);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 26;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gray;
            panel1.Controls.Add(buttonAdcionar);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(numericUpDownQuantidade);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(buttonCompraCreatina);
            panel1.ForeColor = Color.Black;
            panel1.Location = new Point(36, 41);
            panel1.Name = "panel1";
            panel1.Size = new Size(551, 412);
            panel1.TabIndex = 27;
            // 
            // buttonAdcionar
            // 
            buttonAdcionar.BackColor = Color.FromArgb(192, 255, 192);
            buttonAdcionar.Cursor = Cursors.Hand;
            buttonAdcionar.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonAdcionar.Image = Properties.Resources.icons8_add_32;
            buttonAdcionar.ImageAlign = ContentAlignment.MiddleLeft;
            buttonAdcionar.Location = new Point(291, 292);
            buttonAdcionar.Name = "buttonAdcionar";
            buttonAdcionar.Size = new Size(199, 54);
            buttonAdcionar.TabIndex = 29;
            buttonAdcionar.Text = "Adicionar";
            buttonAdcionar.UseVisualStyleBackColor = false;
            buttonAdcionar.Click += buttonAdcionar_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(textBoxCodigoProduto);
            panel2.Location = new Point(66, 142);
            panel2.Name = "panel2";
            panel2.Size = new Size(410, 57);
            panel2.TabIndex = 28;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(3, 0);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(46, 54);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 27;
            pictureBox3.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(96, 85);
            label2.Name = "label2";
            label2.Size = new Size(239, 25);
            label2.TabIndex = 27;
            label2.Text = "Faça a retirada do estoque!";
            // 
            // ComprarProdutos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(628, 497);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "ComprarProdutos";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ComprarProdutos";
            Load += ComprarProdutos_Load;
            ((System.ComponentModel.ISupportInitialize)numericUpDownQuantidade).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button buttonCompraCreatina;
        private NumericUpDown numericUpDownQuantidade;
        private TextBox textBoxCodigoProduto;
        private Label label1;
        private Label label6;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Label label2;
        private Panel panel2;
        private PictureBox pictureBox3;
        private Button buttonAdcionar;
    }
}