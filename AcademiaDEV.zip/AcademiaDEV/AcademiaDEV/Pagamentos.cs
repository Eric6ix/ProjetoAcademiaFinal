﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Windows.Forms;
using System.Diagnostics;

namespace AcademiaDEV
{
    public partial class Pagamentos : Form
    {
        private string usuarioLogado;
        public static string ConnectionString = @"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None";
        private PagamentosDAO pagamentosDAO;
        private PlanosDAO planosDAO;

        public Pagamentos(string usuario)
        {
            InitializeComponent();
            usuarioLogado = usuario;
            pagamentosDAO = new PagamentosDAO(ConnectionString);
            planosDAO = new PlanosDAO(ConnectionString);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void Pagamentos_Load(object sender, EventArgs e)
        {
            LoadPagamentos();
            LoadPlanos();

            // Define as DataGridViews como somente leitura
            dataGridViewPagamentos.ReadOnly = true;
            dataGridViewPlanos.ReadOnly = true;

            // Desabilita a adição de novas linhas
            dataGridViewPagamentos.AllowUserToAddRows = false;
            dataGridViewPlanos.AllowUserToAddRows = false;

            // Define o modo de seleção para linha inteira
            dataGridViewPagamentos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewPlanos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Desabilita a edição ao clicar duas vezes
            dataGridViewPagamentos.CellDoubleClick += (s, e) =>
            {
                // Cancela a edição de célula
                dataGridViewPagamentos.CurrentCell = null; // Desmarca a célula atual
                dataGridViewPagamentos.BeginEdit(false); // Impede que a célula entre em modo de edição
            };

            dataGridViewPlanos.CellDoubleClick += (s, e) =>
            {
                // Cancela a edição de célula
                dataGridViewPlanos.CurrentCell = null; // Desmarca a célula atual
                dataGridViewPlanos.BeginEdit(false); // Impede que a célula entre em modo de edição
            };
        }

        private void buttonCadastarPagamentos_Click(object sender, EventArgs e)
        {
            CadastrarPagamentos cadastrarPagamentosObj = new CadastrarPagamentos();
            cadastrarPagamentosObj.ShowDialog();
            LoadPagamentos();
            LoadPlanos();
        }

        private void buttonAtualizarPagamentos_Click(object sender, EventArgs e)
        {
            LoadPagamentos(); // Carrega os pagamentos ao clicar em atualizar
        }

        private void buttonExcluirPagamentos_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxPesquisarAlunoPg.Text))
            {
                MessageBox.Show("Digite o CPF do Aluno em Pesquisar acima!");
                return;
            }

            string cpfAluno = textBoxPesquisarAlunoPg.Text;
            bool planoExcluido = false;
            bool pagamentoExcluido = false;

            // Tentativa de exclusão de pagamento
            try
            {
                if (pagamentosDAO.PagamentoExiste(cpfAluno)) // Verifica se existe o pagamento para o CPF
                {
                    pagamentosDAO.DeletePagamento(cpfAluno);
                    MessageBox.Show("Pagamento excluído com sucesso!");
                    LoadPagamentos();
                    pagamentoExcluido = true;
                }
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 0)
                {
                    MessageBox.Show("Nenhum aluno cadastrado com esse CPF para pagamentos.");
                }
                else
                {
                    MessageBox.Show($"Erro ao excluir pagamento: {ex.Message}");
                }
            }

            // Tentativa de exclusão de plano
            try
            {
                if (planosDAO.PlanoExiste(cpfAluno)) // Verifica se existe o plano para o CPF
                {
                    planosDAO.DeletePlano(cpfAluno);
                    MessageBox.Show("Plano excluído com sucesso!");
                    LoadPlanos();
                    planoExcluido = true;
                }
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 0)
                {
                    MessageBox.Show("Nenhum aluno cadastrado com esse CPF para planos.");
                }
                else
                {
                    MessageBox.Show($"Erro ao excluir plano: {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao excluir plano: {ex.Message}");
            }

            // Mensagens de aviso se nenhum dado foi excluído
            if (!pagamentoExcluido && !planoExcluido)
            {
                MessageBox.Show("Nenhum pagamento ou plano cadastrado com esse CPF.");
            }

            // Limpa o campo de busca após exclusão
            textBoxPesquisarAlunoPg.Clear();
        }

        private void buttonEditarPagamentos_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxPesquisarAlunoPg.Text))
            {
                MessageBox.Show("Digite o CPF do funcionário para editar.");
                return;
            }

            try
            {
                string cpf_alunopg = textBoxPesquisarAlunoPg.Text;
                var cpf_alunoclass = pagamentosDAO.GetPagamentoByCpfAluno(cpf_alunopg); // Aqui você pega o pagamento do CPF

                if (cpf_alunoclass != null)
                {
                    // Se encontrar o pagamento, abre a tela de cadastro de funcionários
                    CadastrarPagamentos cadastrarPagamentos = new CadastrarPagamentos(cpf_alunoclass);
                    cadastrarPagamentos.ShowDialog();
                    LoadPagamentos(); // Atualiza os pagamentos após editar
                }
                else
                {
                    MessageBox.Show("Nenhum funcionário cadastrado com esse CPF.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar funcionário: {ex.Message}");
            }
        }

        private void buttonVoltarPagamentos_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<HomeOpçõescs>().Any())
            {
                Application.OpenForms.OfType<HomeOpçõescs>().First().Show();
            }
            else
            {
                HomeOpçõescs voltarHomeTelaPg = new HomeOpçõescs(usuarioLogado, "");
                voltarHomeTelaPg.ShowDialog();
            }

            this.Hide();
        }

        private void LoadPagamentos()
        {
            try
            {
                var pagamentos = pagamentosDAO.GetAllPagamentos();
                dataGridViewPagamentos.DataSource = pagamentos;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar pagamentos: {ex.Message}");
            }
        }

        private void LoadPlanos()
        {
            try
            {
                var planos = planosDAO.GetAllPlanos();
                dataGridViewPlanos.DataSource = planos;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar planos: {ex.Message}");
            }
        }

        private void buttonPlanosGerarPDF_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Você tem certeza que deseja gerar PDF Planos?", "Confirmar Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                try
                {
                    // Obtendo o caminho da Área de Trabalho (Desktop) do usuário
                    string desktopFolder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                    // Definindo o caminho completo do arquivo PDF na Área de Trabalho
                    string filePath = Path.Combine(desktopFolder, "PlanosExport.pdf");

                    // Criando o documento PDF e o escritor
                    Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
                    PdfWriter writer = PdfWriter.GetInstance(pdfDoc, new FileStream(filePath, FileMode.Create));

                    pdfDoc.Open();

                    // Fonte para o texto
                    BaseFont bf = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                    iTextSharp.text.Font font = new iTextSharp.text.Font(bf, 10, iTextSharp.text.Font.NORMAL);

                    // Criando a tabela PDF com o número de colunas do DataGridView de planos
                    PdfPTable pdfTable = new PdfPTable(dataGridViewPlanos.Columns.Count);
                    pdfTable.WidthPercentage = 100;

                    // Adicionando cabeçalhos do DataGridView ao PDF
                    foreach (DataGridViewColumn column in dataGridViewPlanos.Columns)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText, font));
                        cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                        pdfTable.AddCell(cell);
                    }

                    // Adicionando as linhas da DataGridView ao PDF
                    foreach (DataGridViewRow row in dataGridViewPlanos.Rows)
                    {
                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            pdfTable.AddCell(new Phrase(cell.Value?.ToString() ?? string.Empty, font));
                        }
                    }

                    // Adicionando a tabela ao documento PDF
                    pdfDoc.Add(pdfTable);
                    pdfDoc.Close();

                    // Verificando se o arquivo foi criado com sucesso antes de tentar abrir
                    if (File.Exists(filePath))
                    {
                        // Abrir o arquivo PDF gerado
                        Process.Start(new ProcessStartInfo(filePath) { UseShellExecute = true });

                        // Exibe uma mensagem de sucesso
                        MessageBox.Show("PDF de Planos gerado com sucesso na área de trabalho e aberto!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Erro: O arquivo PDF não foi gerado corretamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    // Exibe uma mensagem de erro se algo falhar
                    MessageBox.Show("Erro ao gerar ou abrir PDF: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void buttoPagamentosGeraPDF_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Você tem certeza que deseja gerar PDF Pagamentos?", "Confirmar Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                try
                {
                    // Obtendo o caminho da Área de Trabalho (Desktop) do usuário
                    string desktopFolder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                    // Definindo o caminho completo do arquivo PDF na Área de Trabalho
                    string filePath = Path.Combine(desktopFolder, "PlanosExport.pdf");

                    // Criando o documento PDF e o escritor
                    Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
                    PdfWriter writer = PdfWriter.GetInstance(pdfDoc, new FileStream(filePath, FileMode.Create));

                    pdfDoc.Open();

                    // Fonte para o texto
                    BaseFont bf = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                    iTextSharp.text.Font font = new iTextSharp.text.Font(bf, 10, iTextSharp.text.Font.NORMAL);

                    // Criando a tabela PDF com o número de colunas do DataGridView de planos
                    PdfPTable pdfTable = new PdfPTable(dataGridViewPagamentos.Columns.Count);
                    pdfTable.WidthPercentage = 100;

                    // Adicionando cabeçalhos do DataGridView ao PDF
                    foreach (DataGridViewColumn column in dataGridViewPagamentos.Columns)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText, font));
                        cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                        pdfTable.AddCell(cell);
                    }

                    // Adicionando as linhas da DataGridView ao PDF
                    foreach (DataGridViewRow row in dataGridViewPagamentos.Rows)
                    {
                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            pdfTable.AddCell(new Phrase(cell.Value?.ToString() ?? string.Empty, font));
                        }
                    }

                    // Adicionando a tabela ao documento PDF
                    pdfDoc.Add(pdfTable);
                    pdfDoc.Close();

                    // Verificando se o arquivo foi criado com sucesso antes de tentar abrir
                    if (File.Exists(filePath))
                    {
                        // Abrir o arquivo PDF gerado
                        Process.Start(new ProcessStartInfo(filePath) { UseShellExecute = true });

                        // Exibe uma mensagem de sucesso
                        MessageBox.Show("PDF de Pagametos gerado com sucesso na área de trabalho e aberto!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Erro: O arquivo PDF não foi gerado corretamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    // Exibe uma mensagem de erro se algo falhar
                    MessageBox.Show("Erro ao gerar ou abrir PDF: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void buttonBuscarPagamentos_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxPesquisarAlunoPg.Text))
            {
                MessageBox.Show("Digite o CPF do aluno para buscar.");
                return;
            }

            try
            {
                string cpfAluno = textBoxPesquisarAlunoPg.Text; // Corrigido para CPF
                var pagamento = pagamentosDAO.GetPagamentoByCpfAluno(cpfAluno); // Usando a instância pagamentosDAO

                if (pagamento != null)
                {
                    MessageBox.Show("Pagamento encontrado com sucesso!");
                    // Preenche os campos com os dados do pagamento encontrado, se necessário
                }
                else
                {
                    MessageBox.Show("Nenhum pagamento cadastrado com esse CPF.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar pagamento: {ex.Message}");
            }
        }
    }
}
