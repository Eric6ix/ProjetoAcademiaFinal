﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace AcademiaDEV
{
    public partial class CadastrarFuncionarios : Form
    {
        private readonly FuncionarioDAO funcionarioDAO;
        private FuncionarioDAO.Funcionario funcionarioAtual; // Para armazenar o funcionário atual

        public CadastrarFuncionarios()
        {
            InitializeComponent();
            string connectionString = @"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None";
            funcionarioDAO = new FuncionarioDAO(connectionString);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        // Construtor que aceita um objeto Funcionario
        public CadastrarFuncionarios(FuncionarioDAO.Funcionario funcionario) : this()
        {
            funcionarioAtual = funcionario; // Armazena o funcionário atual
            if (funcionario != null)
            {
                txtNome.Text = funcionario.Nome;
                txtCPF.Text = funcionario.CPF;
                txtCargo.Text = funcionario.Cargo;
                txtEspecializacao.Text = funcionario.Especializacao;
                txtHorarioTrabalho.Text = funcionario.HorarioTrabalho; // Verifique se esta coluna existe no banco
                txtSalario.Text = funcionario.Salario.ToString(); // Converter decimal para string
                txtEmail.Text = funcionario.Email;
            }
        }

        private void buttonAddFuncionario_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtNome.Text) || string.IsNullOrWhiteSpace(txtCPF.Text))
                {
                    MessageBox.Show("Os campos Nome e CPF são obrigatórios!");
                    return;
                }

                var funcionario = new FuncionarioDAO.Funcionario
                {
                    FuncionarioId = funcionarioAtual?.FuncionarioId ?? 0, // Usa o ID do funcionário atual se existir
                    Nome = txtNome.Text,
                    CPF = txtCPF.Text,
                    Cargo = txtCargo.Text,
                    Especializacao = txtEspecializacao.Text,
                    HorarioTrabalho = txtHorarioTrabalho.Text, // Use o nome correto da coluna
                    Salario = decimal.Parse(txtSalario.Text),
                    Email = txtEmail.Text
                };

                if (funcionarioAtual != null) // Se estamos editando
                {
                    funcionarioDAO.UpdateFuncionario(funcionario); // Método para atualizar
                    MessageBox.Show("Funcionário atualizado com sucesso!");
                }
                else // Se estamos adicionando
                {
                    funcionarioDAO.AddFuncionario(funcionario);
                    MessageBox.Show("Funcionário adicionado com sucesso!");
                }

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro: {ex.Message}");
            }
        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Deseja realmente cancelar?", "Confirmar", MessageBoxButtons.YesNo);
            if (resultado == DialogResult.Yes)
            {
                txtNome.Clear();
                txtCPF.Clear();
                txtCargo.Clear();
                txtSalario.Clear();
                txtHorarioTrabalho.Clear();
                txtEspecializacao.Clear();
                txtEmail.Clear();
                this.Close();
            }
        }

        private void txtHorarioTrabalho_TextChanged(object sender, EventArgs e)
        {
            // Implementar lógica se necessário
        }

        private void CadastrarFuncionarios_Load(object sender, EventArgs e)
        {

        }
    }
}
