﻿namespace AcademiaDEV
{
    partial class CadastrarPagamentos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastrarPagamentos));
            textBoxNomeAluno = new TextBox();
            textBoxAlunoCPF = new TextBox();
            textBoxTipoPlano = new TextBox();
            monthCalendarPg = new MonthCalendar();
            textBoxFormaDePagamento = new TextBox();
            textBoxStatusPagamento = new TextBox();
            buttonAddPagamento = new Button();
            sqlCommandBuilder1 = new Microsoft.Data.SqlClient.SqlCommandBuilder();
            panel1 = new Panel();
            label11 = new Label();
            label10 = new Label();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            label4 = new Label();
            panel3 = new Panel();
            label2 = new Label();
            label1 = new Label();
            panel4 = new Panel();
            label5 = new Label();
            label3 = new Label();
            panel5 = new Panel();
            buttonCancelarPagamentos = new Button();
            panel7 = new Panel();
            label9 = new Label();
            pictureBox2 = new PictureBox();
            label7 = new Label();
            label13 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // textBoxNomeAluno
            // 
            textBoxNomeAluno.Location = new Point(147, 24);
            textBoxNomeAluno.Name = "textBoxNomeAluno";
            textBoxNomeAluno.Size = new Size(678, 27);
            textBoxNomeAluno.TabIndex = 0;
            textBoxNomeAluno.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxAlunoCPF
            // 
            textBoxAlunoCPF.Location = new Point(114, 21);
            textBoxAlunoCPF.Name = "textBoxAlunoCPF";
            textBoxAlunoCPF.Size = new Size(383, 27);
            textBoxAlunoCPF.TabIndex = 1;
            textBoxAlunoCPF.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxTipoPlano
            // 
            textBoxTipoPlano.Location = new Point(613, 21);
            textBoxTipoPlano.Name = "textBoxTipoPlano";
            textBoxTipoPlano.Size = new Size(231, 27);
            textBoxTipoPlano.TabIndex = 2;
            textBoxTipoPlano.TextAlign = HorizontalAlignment.Center;
            // 
            // monthCalendarPg
            // 
            monthCalendarPg.Location = new Point(955, 271);
            monthCalendarPg.Name = "monthCalendarPg";
            monthCalendarPg.TabIndex = 3;
            // 
            // textBoxFormaDePagamento
            // 
            textBoxFormaDePagamento.Location = new Point(200, 20);
            textBoxFormaDePagamento.Name = "textBoxFormaDePagamento";
            textBoxFormaDePagamento.Size = new Size(265, 27);
            textBoxFormaDePagamento.TabIndex = 4;
            textBoxFormaDePagamento.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxStatusPagamento
            // 
            textBoxStatusPagamento.Location = new Point(200, 20);
            textBoxStatusPagamento.Name = "textBoxStatusPagamento";
            textBoxStatusPagamento.Size = new Size(297, 27);
            textBoxStatusPagamento.TabIndex = 5;
            textBoxStatusPagamento.TextAlign = HorizontalAlignment.Center;
            // 
            // buttonAddPagamento
            // 
            buttonAddPagamento.BackColor = Color.Black;
            buttonAddPagamento.Cursor = Cursors.Hand;
            buttonAddPagamento.FlatAppearance.BorderSize = 3;
            buttonAddPagamento.FlatStyle = FlatStyle.Flat;
            buttonAddPagamento.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonAddPagamento.ForeColor = Color.White;
            buttonAddPagamento.Location = new Point(877, 632);
            buttonAddPagamento.Name = "buttonAddPagamento";
            buttonAddPagamento.Size = new Size(255, 44);
            buttonAddPagamento.TabIndex = 13;
            buttonAddPagamento.Text = "Adicionar";
            buttonAddPagamento.UseVisualStyleBackColor = false;
            buttonAddPagamento.Click += buttonAddPagamento_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(317, 732);
            panel1.TabIndex = 25;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Arial Black", 18F);
            label11.ForeColor = Color.White;
            label11.Location = new Point(32, 345);
            label11.Name = "label11";
            label11.Size = new Size(251, 42);
            label11.TabIndex = 33;
            label11.Text = "Area Cadastro";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Segoe UI", 11F);
            label10.ForeColor = Color.White;
            label10.Location = new Point(53, 402);
            label10.Name = "label10";
            label10.Size = new Size(209, 100);
            label10.TabIndex = 31;
            label10.Text = "  Area de cadastro de \r\n        informações\r\n  de pagamento da sua \r\n          academia!";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.BrancoPagamentos;
            pictureBox1.Location = new Point(105, 234);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(105, 108);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(label4);
            panel2.Controls.Add(textBoxNomeAluno);
            panel2.Location = new Point(363, 195);
            panel2.Name = "panel2";
            panel2.Size = new Size(861, 64);
            panel2.TabIndex = 27;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label4.Location = new Point(10, 20);
            label4.Name = "label4";
            label4.Size = new Size(131, 28);
            label4.TabIndex = 18;
            label4.Text = "Nome Aluno";
            // 
            // panel3
            // 
            panel3.BackColor = Color.Gainsboro;
            panel3.Controls.Add(label2);
            panel3.Controls.Add(label1);
            panel3.Controls.Add(textBoxTipoPlano);
            panel3.Controls.Add(textBoxFormaDePagamento);
            panel3.Location = new Point(363, 490);
            panel3.Name = "panel3";
            panel3.Size = new Size(861, 64);
            panel3.TabIndex = 28;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label2.Location = new Point(497, 20);
            label2.Name = "label2";
            label2.Size = new Size(113, 28);
            label2.TabIndex = 19;
            label2.Text = "Tipo plano";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label1.Location = new Point(10, 20);
            label1.Name = "label1";
            label1.Size = new Size(184, 28);
            label1.TabIndex = 18;
            label1.Text = "Forma Pagamento";
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gainsboro;
            panel4.Controls.Add(label5);
            panel4.Controls.Add(textBoxStatusPagamento);
            panel4.Location = new Point(363, 387);
            panel4.Name = "panel4";
            panel4.Size = new Size(512, 64);
            panel4.TabIndex = 29;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label5.Location = new Point(10, 20);
            label5.Name = "label5";
            label5.Size = new Size(184, 28);
            label5.TabIndex = 18;
            label5.Text = "Status Pagamento";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label3.Location = new Point(3, 20);
            label3.Name = "label3";
            label3.Size = new Size(108, 28);
            label3.TabIndex = 19;
            label3.Text = "CPF Aluno";
            // 
            // panel5
            // 
            panel5.BackColor = Color.Gainsboro;
            panel5.Controls.Add(label3);
            panel5.Controls.Add(textBoxAlunoCPF);
            panel5.Location = new Point(363, 296);
            panel5.Name = "panel5";
            panel5.Size = new Size(512, 64);
            panel5.TabIndex = 28;
            // 
            // buttonCancelarPagamentos
            // 
            buttonCancelarPagamentos.BackColor = Color.FromArgb(64, 64, 64);
            buttonCancelarPagamentos.Cursor = Cursors.Hand;
            buttonCancelarPagamentos.FlatAppearance.BorderSize = 3;
            buttonCancelarPagamentos.FlatStyle = FlatStyle.Flat;
            buttonCancelarPagamentos.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonCancelarPagamentos.ForeColor = Color.White;
            buttonCancelarPagamentos.Location = new Point(452, 632);
            buttonCancelarPagamentos.Name = "buttonCancelarPagamentos";
            buttonCancelarPagamentos.Size = new Size(255, 44);
            buttonCancelarPagamentos.TabIndex = 30;
            buttonCancelarPagamentos.Text = "Cancelar";
            buttonCancelarPagamentos.UseVisualStyleBackColor = false;
            buttonCancelarPagamentos.Click += buttonCancelarPagamentos_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.DarkGray;
            panel7.Location = new Point(336, 161);
            panel7.Name = "panel7";
            panel7.Size = new Size(922, 5);
            panel7.TabIndex = 31;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(336, 135);
            label9.Name = "label9";
            label9.Size = new Size(342, 23);
            label9.TabIndex = 32;
            label9.Text = "Informe os dados de pagamentos aqui!";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.BrancoPagamentos1;
            pictureBox2.Location = new Point(1138, 70);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(105, 58);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 38;
            pictureBox2.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial Black", 11F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(1124, 131);
            label7.Name = "label7";
            label7.Size = new Size(134, 27);
            label7.TabIndex = 39;
            label7.Text = "Bem vindo !";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Arial Black", 18F);
            label13.ForeColor = Color.White;
            label13.Location = new Point(336, 58);
            label13.Name = "label13";
            label13.Size = new Size(427, 42);
            label13.TabIndex = 40;
            label13.Text = "Cadastro de Pagamentos";
            // 
            // CadastrarPagamentos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1270, 732);
            Controls.Add(label13);
            Controls.Add(label7);
            Controls.Add(pictureBox2);
            Controls.Add(label9);
            Controls.Add(panel7);
            Controls.Add(buttonCancelarPagamentos);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(buttonAddPagamento);
            Controls.Add(monthCalendarPg);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "CadastrarPagamentos";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CadastrarPagamentos";
            Load += CadastrarPagamentos_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxNomeAluno;
        private TextBox textBoxAlunoCPF;
        private TextBox textBoxTipoPlano;
        private MonthCalendar monthCalendarPg;
        private TextBox textBoxFormaDePagamento;
        private TextBox textBoxStatusPagamento;
        private Button buttonAddPagamento;
        private Microsoft.Data.SqlClient.SqlCommandBuilder sqlCommandBuilder1;
        private Panel panel1;
        private Label label11;
        private Label label10;
        private PictureBox pictureBox1;
        private Panel panel2;
        private Label label4;
        private Panel panel3;
        private Label label2;
        private Label label1;
        private Label label3;
        private Panel panel4;
        private Label label5;
        private Panel panel5;
        private Button buttonCancelarPagamentos;
        private Panel panel7;
        private Label label9;
        private PictureBox pictureBox2;
        private Label label7;
        private Label label13;
    }
}