﻿using System;
using System.Windows.Forms;

namespace AcademiaDEV
{
    public partial class ConfirmarCPFForm : Form
    {
        // Propriedade pública para armazenar o CPF inserido
        public string CPFAluno { get; private set; }

        public ConfirmarCPFForm()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }
        // Método para lidar com o clique do botão de confirmação
        private void buttonConfirmar_Click(object sender, EventArgs e)
        {
            // Validação básica do CPF (opcionalmente, adicione validações mais rigorosas)
            if (string.IsNullOrWhiteSpace(textBoxCPF.Text) || textBoxCPF.Text.Length != 11)
            {
                MessageBox.Show("Por favor, insira um CPF válido (11 dígitos).", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Armazena o CPF inserido na propriedade
            CPFAluno = textBoxCPF.Text;
            DialogResult = DialogResult.OK;  // Define o resultado do diálogo como OK
            Close();  // Fecha o formulário
        }
        private void ConfirmarCPFForm_Load(object sender, EventArgs e)
        {

        }
    }
}
