﻿namespace AcademiaDEV
{
    partial class CadastroProdutos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastroProdutos));
            buttonCadastrar = new Button();
            textBoxNomeProduto = new TextBox();
            textBoxUnidade = new TextBox();
            textBoxPreco = new TextBox();
            textBoxDescricao = new TextBox();
            textBoxQuantidade = new TextBox();
            sqlCommandBuilder1 = new Microsoft.Data.SqlClient.SqlCommandBuilder();
            panel4 = new Panel();
            label1 = new Label();
            label3 = new Label();
            label8 = new Label();
            panel1 = new Panel();
            label5 = new Label();
            panel3 = new Panel();
            label6 = new Label();
            panel5 = new Panel();
            label11 = new Label();
            label10 = new Label();
            pictureBox1 = new PictureBox();
            pictureBoxCodigoBarras = new PictureBox();
            panel2 = new Panel();
            label7 = new Label();
            label4 = new Label();
            panel7 = new Panel();
            label9 = new Label();
            label13 = new Label();
            label2 = new Label();
            pictureBox2 = new PictureBox();
            buttonCancelarPagamento = new Button();
            panel4.SuspendLayout();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCodigoBarras).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // buttonCadastrar
            // 
            buttonCadastrar.BackColor = Color.Black;
            buttonCadastrar.Cursor = Cursors.Hand;
            buttonCadastrar.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonCadastrar.ForeColor = Color.White;
            buttonCadastrar.Location = new Point(891, 618);
            buttonCadastrar.Name = "buttonCadastrar";
            buttonCadastrar.Size = new Size(255, 44);
            buttonCadastrar.TabIndex = 6;
            buttonCadastrar.Text = "Adicionar";
            buttonCadastrar.UseVisualStyleBackColor = false;
            buttonCadastrar.Click += buttonCadastrar_Click;
            // 
            // textBoxNomeProduto
            // 
            textBoxNomeProduto.Location = new Point(157, 22);
            textBoxNomeProduto.Name = "textBoxNomeProduto";
            textBoxNomeProduto.Size = new Size(450, 27);
            textBoxNomeProduto.TabIndex = 7;
            textBoxNomeProduto.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxUnidade
            // 
            textBoxUnidade.Location = new Point(113, 24);
            textBoxUnidade.Name = "textBoxUnidade";
            textBoxUnidade.Size = new Size(327, 27);
            textBoxUnidade.TabIndex = 8;
            textBoxUnidade.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxPreco
            // 
            textBoxPreco.Location = new Point(696, 23);
            textBoxPreco.Name = "textBoxPreco";
            textBoxPreco.Size = new Size(169, 27);
            textBoxPreco.TabIndex = 9;
            textBoxPreco.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxDescricao
            // 
            textBoxDescricao.Location = new Point(120, 24);
            textBoxDescricao.Name = "textBoxDescricao";
            textBoxDescricao.Size = new Size(391, 27);
            textBoxDescricao.TabIndex = 10;
            textBoxDescricao.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxQuantidade
            // 
            textBoxQuantidade.Location = new Point(657, 24);
            textBoxQuantidade.Name = "textBoxQuantidade";
            textBoxQuantidade.Size = new Size(208, 27);
            textBoxQuantidade.TabIndex = 15;
            textBoxQuantidade.TextAlign = HorizontalAlignment.Center;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gainsboro;
            panel4.Controls.Add(textBoxPreco);
            panel4.Controls.Add(label1);
            panel4.Controls.Add(label3);
            panel4.Controls.Add(textBoxNomeProduto);
            panel4.Location = new Point(350, 196);
            panel4.Name = "panel4";
            panel4.Size = new Size(881, 64);
            panel4.TabIndex = 25;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label1.Location = new Point(0, 19);
            label1.Name = "label1";
            label1.Size = new Size(151, 28);
            label1.TabIndex = 16;
            label1.Text = "Nome produto";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label3.Location = new Point(625, 19);
            label3.Name = "label3";
            label3.Size = new Size(65, 28);
            label3.TabIndex = 18;
            label3.Text = "Preço";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label8.Location = new Point(17, 20);
            label8.Name = "label8";
            label8.Size = new Size(90, 28);
            label8.TabIndex = 20;
            label8.Text = "Unidade";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gainsboro;
            panel1.Controls.Add(textBoxUnidade);
            panel1.Controls.Add(label8);
            panel1.Location = new Point(523, 278);
            panel1.Name = "panel1";
            panel1.Size = new Size(490, 64);
            panel1.TabIndex = 27;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label5.Location = new Point(529, 20);
            label5.Name = "label5";
            label5.Size = new Size(122, 28);
            label5.TabIndex = 18;
            label5.Text = "Quantidade";
            // 
            // panel3
            // 
            panel3.BackColor = Color.Gainsboro;
            panel3.Controls.Add(textBoxQuantidade);
            panel3.Controls.Add(label5);
            panel3.Controls.Add(label6);
            panel3.Controls.Add(textBoxDescricao);
            panel3.Location = new Point(350, 357);
            panel3.Name = "panel3";
            panel3.Size = new Size(881, 64);
            panel3.TabIndex = 28;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label6.Location = new Point(10, 20);
            label6.Name = "label6";
            label6.Size = new Size(104, 28);
            label6.TabIndex = 18;
            label6.Text = "Descrição";
            // 
            // panel5
            // 
            panel5.BackColor = Color.Black;
            panel5.Controls.Add(label11);
            panel5.Controls.Add(label10);
            panel5.Controls.Add(pictureBox1);
            panel5.Dock = DockStyle.Left;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(317, 732);
            panel5.TabIndex = 29;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Arial Black", 18F);
            label11.ForeColor = Color.White;
            label11.Location = new Point(32, 345);
            label11.Name = "label11";
            label11.Size = new Size(251, 42);
            label11.TabIndex = 33;
            label11.Text = "Area Cadastro";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Segoe UI", 11F);
            label10.ForeColor = Color.White;
            label10.Location = new Point(53, 402);
            label10.Name = "label10";
            label10.Size = new Size(195, 100);
            label10.TabIndex = 31;
            label10.Text = "  Area de cadastro de \r\n        informações\r\n    de produto da sua \r\n          academia!";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.icons8_produtos_100__1_;
            pictureBox1.Location = new Point(105, 234);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(105, 108);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // pictureBoxCodigoBarras
            // 
            pictureBoxCodigoBarras.BackColor = Color.White;
            pictureBoxCodigoBarras.Location = new Point(365, 20);
            pictureBoxCodigoBarras.Name = "pictureBoxCodigoBarras";
            pictureBoxCodigoBarras.Size = new Size(530, 97);
            pictureBoxCodigoBarras.TabIndex = 5;
            pictureBoxCodigoBarras.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Black;
            panel2.Controls.Add(label7);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(pictureBoxCodigoBarras);
            panel2.Location = new Point(336, 440);
            panel2.Name = "panel2";
            panel2.Size = new Size(905, 131);
            panel2.TabIndex = 29;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI", 11F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(3, 80);
            label7.Name = "label7";
            label7.Size = new Size(346, 25);
            label7.TabIndex = 34;
            label7.Text = "Este e codigo de barras de seu produto!";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Black", 18F);
            label4.ForeColor = Color.White;
            label4.Location = new Point(14, 20);
            label4.Name = "label4";
            label4.Size = new Size(319, 42);
            label4.TabIndex = 34;
            label4.Text = "Codigo do Produto";
            // 
            // panel7
            // 
            panel7.BackColor = Color.DarkGray;
            panel7.Location = new Point(336, 160);
            panel7.Name = "panel7";
            panel7.Size = new Size(922, 5);
            panel7.TabIndex = 30;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(336, 134);
            label9.Name = "label9";
            label9.Size = new Size(340, 23);
            label9.TabIndex = 31;
            label9.Text = "Informe os dados de seu produto aqui!";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Arial Black", 18F);
            label13.ForeColor = Color.White;
            label13.Location = new Point(336, 55);
            label13.Name = "label13";
            label13.Size = new Size(371, 42);
            label13.TabIndex = 35;
            label13.Text = "Cadastro de Produtos\r\n";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Black", 11F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(1124, 130);
            label2.Name = "label2";
            label2.Size = new Size(134, 27);
            label2.TabIndex = 36;
            label2.Text = "Bem vindo !";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.icons8_produtos_100__1_1;
            pictureBox2.Location = new Point(1136, 69);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(105, 58);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 37;
            pictureBox2.TabStop = false;
            // 
            // buttonCancelarPagamento
            // 
            buttonCancelarPagamento.BackColor = Color.FromArgb(64, 64, 64);
            buttonCancelarPagamento.Cursor = Cursors.Hand;
            buttonCancelarPagamento.FlatAppearance.BorderSize = 3;
            buttonCancelarPagamento.FlatStyle = FlatStyle.Flat;
            buttonCancelarPagamento.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonCancelarPagamento.ForeColor = Color.White;
            buttonCancelarPagamento.Location = new Point(452, 618);
            buttonCancelarPagamento.Name = "buttonCancelarPagamento";
            buttonCancelarPagamento.Size = new Size(255, 44);
            buttonCancelarPagamento.TabIndex = 38;
            buttonCancelarPagamento.Text = "Cancelar";
            buttonCancelarPagamento.UseVisualStyleBackColor = false;
            buttonCancelarPagamento.Click += buttonCancelarPagamento_Click;
            // 
            // CadastroProdutos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1270, 732);
            Controls.Add(buttonCancelarPagamento);
            Controls.Add(pictureBox2);
            Controls.Add(buttonCadastrar);
            Controls.Add(label2);
            Controls.Add(label13);
            Controls.Add(label9);
            Controls.Add(panel7);
            Controls.Add(panel2);
            Controls.Add(panel5);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Controls.Add(panel4);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "CadastroProdutos";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CadastroProdutos";
            Load += CadastroProdutos_Load;
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCodigoBarras).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button buttonCadastrar;
        private TextBox textBoxNomeProduto;
        private TextBox textBoxUnidade;
        private TextBox textBoxPreco;
        private TextBox textBoxDescricao;
        private TextBox textBoxQuantidade;
        private Microsoft.Data.SqlClient.SqlCommandBuilder sqlCommandBuilder1;
        private Panel panel4;
        private Label label1;
        private Label label8;
        private Label label3;
        private Panel panel1;
        private Label label5;
        private Panel panel3;
        private Label label6;
        private Panel panel5;
        private Label label11;
        private Label label10;
        private PictureBox pictureBox1;
        private PictureBox pictureBoxCodigoBarras;
        private Panel panel2;
        private Panel panel7;
        private Label label9;
        private Label label13;
        private Label label2;
        private PictureBox pictureBox2;
        private Label label4;
        private Label label7;
        private Button buttonCancelarPagamento;
    }
}