﻿using iTextSharp.text.pdf;
using iTextSharp.text;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace AcademiaDEV
{
    public partial class Produtos : Form
    {
        private readonly string connectionString;
        private string pastaImagens = @"D:\\Apresentação Seminario\\sistema\\AcademiaDEV\\COD";
        private ProdutoDAO produtoDAO;
        private string usuarioLogado;

        public Produtos(string connectionString, string usuario)
        {
            InitializeComponent();
            this.connectionString = connectionString;
            this.produtoDAO = new ProdutoDAO(connectionString);
            usuarioLogado = usuario;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void Produtos_Load(object sender, EventArgs e)
        {
            LoadProdutos();

            dataGridViewProdutos.ReadOnly = true;

            // Desabilita a adição de novas linhas
            dataGridViewProdutos.AllowUserToAddRows = false;

            // Define o modo de seleção para linha inteira
            dataGridViewProdutos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Desabilita a edição ao clicar duas vezes
            dataGridViewProdutos.CellDoubleClick += (s, e) =>
            {
                // Cancela a edição de célula
                dataGridViewProdutos.CurrentCell = null; // Desmarca a célula atual
                dataGridViewProdutos.BeginEdit(false); // Impede que a célula entre em modo de edição
            };
        }

        private void buttonLoja_Click(object sender, EventArgs e)
        {
            var comprar = new ComprarProdutos();
            comprar.ShowDialog();
        }

        private void buttonCadastrar_Click(object sender, EventArgs e)
        {
            var cadastroProdutoOjt = new CadastroProdutos();
            cadastroProdutoOjt.ShowDialog();
        }

        private void buttonBuscarProduto_Click(object sender, EventArgs e)
        {
            string codigoDeBarras = textBoxPesquisarProduto.Text.Trim();
            string imagemPath = Path.Combine(pastaImagens, codigoDeBarras + ".png");

            if (string.IsNullOrWhiteSpace(codigoDeBarras))
            {
                MessageBox.Show("Digite o código de barras para buscar!");
                return;
            }

            try
            {
                var produto = produtoDAO.GetProdutoByCodigo(codigoDeBarras);

                if (produto != null)
                {
                    if (File.Exists(imagemPath))
                    {
                        pictureBoxCodigoBarrasObj.Image = System.Drawing.Image.FromFile(imagemPath); // Especificando o namespace completo
                        pictureBoxCodigoBarrasObj.SizeMode = PictureBoxSizeMode.StretchImage; // Ajusta o modo de exibição
                        MessageBox.Show("Produto encontrado");
                    }
                    else
                    {
                        MessageBox.Show("Código de barra não encontrado: " + imagemPath);
                        pictureBoxCodigoBarrasObj.Image = null; // Limpa a imagem anterior
                    }
                }
                else
                {
                    MessageBox.Show("Nenhum produto cadastrado com esse código.");
                    dataGridViewProdutos.Rows.Clear(); // Limpa o DataGridView
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar produto: {ex.Message}");
            }
        }

        private void buttonAtualizar_Click(object sender, EventArgs e)
        {
            LoadProdutos();
        }

        private void LoadProdutos() // Carrega todos os produtos
        {
            try
            {
                var produtos = produtoDAO.GetAllProdutos(); // Método para buscar todos os produtos
                dataGridViewProdutos.DataSource = produtos; // Define o DataSource como a lista de produtos
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar produtos: {ex.Message}");
            }
        }

        private void buttonExcluir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxPesquisarProduto.Text))
            {
                MessageBox.Show("Digite o código do produto acima para excluir!");
                return;
            }

            string deleteproduto_codigo = textBoxPesquisarProduto.Text.Trim();
            string imagemPath = Path.Combine(pastaImagens, deleteproduto_codigo + ".png");

            try
            {
                // Libera a imagem do PictureBox, se estiver carregada
                if (pictureBoxCodigoBarrasObj.Image != null)
                {
                    pictureBoxCodigoBarrasObj.Image.Dispose(); // Libera a imagem
                    pictureBoxCodigoBarrasObj.Image = null; // Limpa o PictureBox
                }

                // Exclui o produto do banco de dados
                produtoDAO.DeleteProduto(deleteproduto_codigo);

                // Verifica se a imagem existe e a exclui
                if (File.Exists(imagemPath))
                {
                    File.Delete(imagemPath);

                }
                else
                {
                    MessageBox.Show("Imagem do código de barras não encontrada.");
                }

                MessageBox.Show("Produto excluído com sucesso!");
                LoadProdutos();
                textBoxPesquisarProduto.Clear();
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 0)
                {
                    MessageBox.Show("Nenhum produto cadastrado com esse código.");
                }
                else
                {
                    MessageBox.Show($"Erro ao excluir produto: {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao excluir produto: {ex.Message}");
            }
        }

        private void buttonVoltarTela_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<HomeOpçõescs>().Any())
            {
                Application.OpenForms.OfType<HomeOpçõescs>().First().Show();
            }
            else
            {
                HomeOpçõescs voltarHomeObjProduto = new HomeOpçõescs(usuarioLogado, ""); // Se necessário, você pode passar a senha aqui
                voltarHomeObjProduto.ShowDialog();
            }
            this.Hide();
        }

        private void buttonProdutoPDF_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Você tem certeza que deseja gerar PDF Produtos?", "Confirmar Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                try
                {
                    // Obtendo o caminho da Área de Trabalho (Desktop) do usuário
                    string desktopFolder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                    // Definindo o caminho completo do arquivo PDF na Área de Trabalho
                    string filePath = Path.Combine(desktopFolder, "ListaProdutos.pdf");

                    // Criando o documento PDF e o escritor
                    Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
                    PdfWriter writer = PdfWriter.GetInstance(pdfDoc, new FileStream(filePath, FileMode.Create));

                    pdfDoc.Open();

                    // Fonte para o texto
                    BaseFont bf = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                    iTextSharp.text.Font font = new iTextSharp.text.Font(bf, 10, iTextSharp.text.Font.NORMAL);

                    // Criando a tabela PDF com o número de colunas do DataGridView de planos
                    PdfPTable pdfTable = new PdfPTable(dataGridViewProdutos.Columns.Count);
                    pdfTable.WidthPercentage = 100;

                    // Adicionando cabeçalhos do DataGridView ao PDF
                    foreach (DataGridViewColumn column in dataGridViewProdutos.Columns)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText, font));
                        cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                        pdfTable.AddCell(cell);
                    }

                    // Adicionando as linhas da DataGridView ao PDF
                    foreach (DataGridViewRow row in dataGridViewProdutos.Rows)
                    {
                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            pdfTable.AddCell(new Phrase(cell.Value?.ToString() ?? string.Empty, font));
                        }
                    }

                    // Adicionando a tabela ao documento PDF
                    pdfDoc.Add(pdfTable);
                    pdfDoc.Close();

                    // Verificando se o arquivo foi criado com sucesso antes de tentar abrir
                    if (File.Exists(filePath))
                    {
                        // Abrir o arquivo PDF gerado
                        Process.Start(new ProcessStartInfo(filePath) { UseShellExecute = true });

                        // Exibe uma mensagem de sucesso
                        MessageBox.Show("PDF de Produtos gerado com sucesso na área de trabalho e aberto!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Erro: O arquivo PDF não foi gerado corretamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    // Exibe uma mensagem de erro se algo falhar
                    MessageBox.Show("Erro ao gerar ou abrir PDF: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
