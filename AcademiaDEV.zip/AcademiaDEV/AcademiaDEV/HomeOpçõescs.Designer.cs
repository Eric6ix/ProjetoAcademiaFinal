﻿namespace AcademiaDEV
{
    partial class HomeOpçõescs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomeOpçõescs));
            button1 = new Button();
            buttonProdutos = new Button();
            buttonPagamentos = new Button();
            buttonPlanos = new Button();
            buttonFuncionarios = new Button();
            buttonAlunos = new Button();
            panel1 = new Panel();
            pictureBox3 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            labelNomeUsuario = new Label();
            buttonSair = new Button();
            label1 = new Label();
            buttonSobreNos = new Button();
            pictureBox1 = new PictureBox();
            buttonAlterarSenha = new Button();
            label5 = new Label();
            pictureBox2 = new PictureBox();
            panel3 = new Panel();
            label7 = new Label();
            panel4 = new Panel();
            label2 = new Label();
            pictureBox6 = new PictureBox();
            label3 = new Label();
            panel2 = new Panel();
            pictureBox7 = new PictureBox();
            label4 = new Label();
            panel5 = new Panel();
            label8 = new Label();
            pictureBox8 = new PictureBox();
            panel6 = new Panel();
            label6 = new Label();
            pictureBox9 = new PictureBox();
            panel7 = new Panel();
            label10 = new Label();
            label9 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            panel7.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.Silver;
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            button1.Image = Properties.Resources.icons8_aula_50_preto;
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(500, 42);
            button1.Name = "button1";
            button1.Size = new Size(355, 86);
            button1.TabIndex = 9;
            button1.Text = "Aulas";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // buttonProdutos
            // 
            buttonProdutos.BackColor = Color.Silver;
            buttonProdutos.Cursor = Cursors.Hand;
            buttonProdutos.FlatAppearance.BorderColor = Color.White;
            buttonProdutos.FlatAppearance.BorderSize = 2;
            buttonProdutos.FlatStyle = FlatStyle.Flat;
            buttonProdutos.Font = new Font("Arial", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonProdutos.ForeColor = Color.Black;
            buttonProdutos.Image = Properties.Resources.icons8_produtos_50;
            buttonProdutos.ImageAlign = ContentAlignment.MiddleLeft;
            buttonProdutos.Location = new Point(151, 23);
            buttonProdutos.Name = "buttonProdutos";
            buttonProdutos.Size = new Size(335, 86);
            buttonProdutos.TabIndex = 8;
            buttonProdutos.Text = "Produtos\r\n";
            buttonProdutos.UseVisualStyleBackColor = false;
            buttonProdutos.Click += buttonProdutos_Click;
            // 
            // buttonPagamentos
            // 
            buttonPagamentos.BackColor = Color.Silver;
            buttonPagamentos.Cursor = Cursors.Hand;
            buttonPagamentos.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonPagamentos.Image = Properties.Resources.icons8_pagamento_50;
            buttonPagamentos.ImageAlign = ContentAlignment.MiddleLeft;
            buttonPagamentos.Location = new Point(158, 23);
            buttonPagamentos.Name = "buttonPagamentos";
            buttonPagamentos.Size = new Size(355, 86);
            buttonPagamentos.TabIndex = 6;
            buttonPagamentos.Text = "Pagamentos";
            buttonPagamentos.UseVisualStyleBackColor = false;
            buttonPagamentos.Click += buttonPagamentos_Click;
            // 
            // buttonPlanos
            // 
            buttonPlanos.BackColor = Color.Silver;
            buttonPlanos.Cursor = Cursors.Hand;
            buttonPlanos.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonPlanos.Image = Properties.Resources.icons8_produtos_48;
            buttonPlanos.ImageAlign = ContentAlignment.MiddleLeft;
            buttonPlanos.Location = new Point(62, 42);
            buttonPlanos.Name = "buttonPlanos";
            buttonPlanos.Size = new Size(355, 86);
            buttonPlanos.TabIndex = 5;
            buttonPlanos.Text = "Planos";
            buttonPlanos.UseVisualStyleBackColor = false;
            buttonPlanos.Click += buttonPlanos_Click;
            // 
            // buttonFuncionarios
            // 
            buttonFuncionarios.BackColor = Color.Silver;
            buttonFuncionarios.Cursor = Cursors.Hand;
            buttonFuncionarios.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonFuncionarios.ForeColor = Color.Black;
            buttonFuncionarios.Image = (Image)resources.GetObject("buttonFuncionarios.Image");
            buttonFuncionarios.ImageAlign = ContentAlignment.MiddleLeft;
            buttonFuncionarios.Location = new Point(158, 16);
            buttonFuncionarios.Name = "buttonFuncionarios";
            buttonFuncionarios.Size = new Size(355, 90);
            buttonFuncionarios.TabIndex = 4;
            buttonFuncionarios.Text = "Funcionarios";
            buttonFuncionarios.UseVisualStyleBackColor = false;
            buttonFuncionarios.Click += buttonFuncionarios_Click;
            // 
            // buttonAlunos
            // 
            buttonAlunos.BackColor = Color.Silver;
            buttonAlunos.Cursor = Cursors.Hand;
            buttonAlunos.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonAlunos.ForeColor = Color.Black;
            buttonAlunos.Image = Properties.Resources.icons8_adicionar_usuário_masculino_grande1;
            buttonAlunos.ImageAlign = ContentAlignment.MiddleLeft;
            buttonAlunos.Location = new Point(151, 20);
            buttonAlunos.Name = "buttonAlunos";
            buttonAlunos.Size = new Size(335, 83);
            buttonAlunos.TabIndex = 1;
            buttonAlunos.Text = "Alunos";
            buttonAlunos.UseVisualStyleBackColor = false;
            buttonAlunos.Click += buttonAlunos_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(pictureBox5);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(labelNomeUsuario);
            panel1.Controls.Add(buttonSair);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(buttonSobreNos);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(buttonAlterarSenha);
            panel1.Dock = DockStyle.Left;
            panel1.ForeColor = Color.White;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(393, 829);
            panel1.TabIndex = 12;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(42, 331);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(73, 36);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 19;
            pictureBox3.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(42, 404);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(73, 36);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 22;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(42, 477);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(73, 36);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 21;
            pictureBox4.TabStop = false;
            // 
            // labelNomeUsuario
            // 
            labelNomeUsuario.AutoSize = true;
            labelNomeUsuario.Font = new Font("Segoe UI", 10F);
            labelNomeUsuario.ForeColor = Color.White;
            labelNomeUsuario.Location = new Point(138, 172);
            labelNomeUsuario.Name = "labelNomeUsuario";
            labelNomeUsuario.Size = new Size(118, 23);
            labelNomeUsuario.TabIndex = 13;
            labelNomeUsuario.Text = "Nome usuario";
            labelNomeUsuario.Click += labelNomeUsuario_Click;
            // 
            // buttonSair
            // 
            buttonSair.Cursor = Cursors.Hand;
            buttonSair.FlatAppearance.BorderSize = 0;
            buttonSair.FlatStyle = FlatStyle.Flat;
            buttonSair.Font = new Font("Arial Black", 11F);
            buttonSair.ForeColor = Color.White;
            buttonSair.Location = new Point(121, 477);
            buttonSair.Name = "buttonSair";
            buttonSair.Size = new Size(170, 36);
            buttonSair.TabIndex = 20;
            buttonSair.Text = "Sair";
            buttonSair.UseVisualStyleBackColor = true;
            buttonSair.Click += buttonSair_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Black", 11F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(121, 129);
            label1.Name = "label1";
            label1.Size = new Size(154, 27);
            label1.TabIndex = 25;
            label1.Text = "Bem vindo ao";
            // 
            // buttonSobreNos
            // 
            buttonSobreNos.Cursor = Cursors.Hand;
            buttonSobreNos.FlatAppearance.BorderSize = 0;
            buttonSobreNos.FlatStyle = FlatStyle.Flat;
            buttonSobreNos.Font = new Font("Arial Black", 11F);
            buttonSobreNos.ForeColor = Color.White;
            buttonSobreNos.Location = new Point(121, 404);
            buttonSobreNos.Name = "buttonSobreNos";
            buttonSobreNos.Size = new Size(170, 36);
            buttonSobreNos.TabIndex = 23;
            buttonSobreNos.Text = "Sobre nós";
            buttonSobreNos.UseVisualStyleBackColor = true;
            buttonSobreNos.Click += buttonSobreNos_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(121, 53);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(154, 73);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 14;
            pictureBox1.TabStop = false;
            // 
            // buttonAlterarSenha
            // 
            buttonAlterarSenha.Cursor = Cursors.Hand;
            buttonAlterarSenha.FlatAppearance.BorderSize = 0;
            buttonAlterarSenha.FlatStyle = FlatStyle.Flat;
            buttonAlterarSenha.Font = new Font("Arial Black", 11F);
            buttonAlterarSenha.ForeColor = Color.White;
            buttonAlterarSenha.Location = new Point(121, 331);
            buttonAlterarSenha.Name = "buttonAlterarSenha";
            buttonAlterarSenha.Size = new Size(170, 36);
            buttonAlterarSenha.TabIndex = 17;
            buttonAlterarSenha.Text = "Alterar senha";
            buttonAlterarSenha.UseVisualStyleBackColor = true;
            buttonAlterarSenha.Click += buttonAlterarSenha_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Bauhaus 93", 16F);
            label5.ForeColor = Color.White;
            label5.Location = new Point(40, 23);
            label5.Name = "label5";
            label5.Size = new Size(136, 60);
            label5.TabIndex = 26;
            label5.Text = "Academia\r\n DEV";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Image__1_2;
            pictureBox2.Location = new Point(10, 26);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(125, 77);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 25;
            pictureBox2.TabStop = false;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Black;
            panel3.Controls.Add(label7);
            panel3.Controls.Add(pictureBox2);
            panel3.Controls.Add(buttonFuncionarios);
            panel3.Location = new Point(428, 190);
            panel3.Name = "panel3";
            panel3.Size = new Size(532, 177);
            panel3.TabIndex = 26;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 10F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(40, 136);
            label7.Name = "label7";
            label7.Size = new Size(405, 23);
            label7.TabIndex = 26;
            label7.Text = "Cadastre-se aqui seu funcionarios da sua academia!";
            // 
            // panel4
            // 
            panel4.BackColor = Color.Black;
            panel4.Controls.Add(label2);
            panel4.Controls.Add(pictureBox6);
            panel4.Controls.Add(buttonAlunos);
            panel4.Location = new Point(966, 190);
            panel4.Name = "panel4";
            panel4.Size = new Size(505, 177);
            panel4.TabIndex = 27;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(63, 136);
            label2.Name = "label2";
            label2.Size = new Size(362, 23);
            label2.TabIndex = 27;
            label2.Text = "Cadastre-se aqui seu alunos da sua academia!";
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(20, 26);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(125, 77);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 26;
            pictureBox6.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial Black", 11F);
            label3.ForeColor = Color.White;
            label3.Location = new Point(423, 146);
            label3.Name = "label3";
            label3.Size = new Size(192, 27);
            label3.TabIndex = 26;
            label3.Text = "Painel de opções";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Black;
            panel2.Controls.Add(pictureBox7);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label5);
            panel2.Location = new Point(423, 23);
            panel2.Name = "panel2";
            panel2.Size = new Size(1048, 103);
            panel2.TabIndex = 29;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(987, 36);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(42, 27);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 27;
            pictureBox7.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Black", 11F);
            label4.ForeColor = Color.White;
            label4.Location = new Point(842, 36);
            label4.Name = "label4";
            label4.Size = new Size(143, 27);
            label4.TabIndex = 26;
            label4.Text = "Menu Opção";
            // 
            // panel5
            // 
            panel5.BackColor = Color.Black;
            panel5.Controls.Add(label8);
            panel5.Controls.Add(pictureBox8);
            panel5.Controls.Add(buttonPagamentos);
            panel5.Location = new Point(428, 404);
            panel5.Name = "panel5";
            panel5.Size = new Size(532, 171);
            panel5.TabIndex = 30;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10F);
            label8.ForeColor = Color.White;
            label8.Location = new Point(86, 125);
            label8.Name = "label8";
            label8.Size = new Size(340, 23);
            label8.TabIndex = 29;
            label8.Text = "Veja aqui os pagamentos da sua academia!";
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(10, 23);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(125, 86);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 27;
            pictureBox8.TabStop = false;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Black;
            panel6.Controls.Add(label6);
            panel6.Controls.Add(pictureBox9);
            panel6.Controls.Add(buttonProdutos);
            panel6.Location = new Point(966, 404);
            panel6.Name = "panel6";
            panel6.Size = new Size(505, 171);
            panel6.TabIndex = 31;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10F);
            label6.ForeColor = Color.White;
            label6.Location = new Point(63, 125);
            label6.Name = "label6";
            label6.Size = new Size(372, 23);
            label6.TabIndex = 27;
            label6.Text = "Cadastre-se aqui os produtos da sua academia!";
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(20, 23);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(125, 86);
            pictureBox9.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox9.TabIndex = 28;
            pictureBox9.TabStop = false;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Black;
            panel7.Controls.Add(label10);
            panel7.Controls.Add(label9);
            panel7.Controls.Add(buttonPlanos);
            panel7.Controls.Add(button1);
            panel7.Location = new Point(514, 598);
            panel7.Name = "panel7";
            panel7.Size = new Size(907, 195);
            panel7.TabIndex = 31;
            panel7.Paint += panel7_Paint;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 10F);
            label10.ForeColor = Color.White;
            label10.Location = new Point(545, 144);
            label10.Name = "label10";
            label10.Size = new Size(284, 23);
            label10.TabIndex = 31;
            label10.Text = "Cadastre-se Aulas da sua academia!";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 10F);
            label9.ForeColor = Color.White;
            label9.Location = new Point(93, 144);
            label9.Name = "label9";
            label9.Size = new Size(295, 23);
            label9.TabIndex = 30;
            label9.Text = "Veja aqui os planos da sua academia!";
            // 
            // HomeOpçõescs
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1507, 829);
            Controls.Add(panel7);
            Controls.Add(panel6);
            Controls.Add(panel5);
            Controls.Add(panel2);
            Controls.Add(label3);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "HomeOpçõescs";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "HomeOpçõescs";
            Load += HomeOpçõescs_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button buttonPagamentos;
        private Button buttonPlanos;
        private Button buttonFuncionarios;
        private Button buttonAlunos;
        private Button button1;
        private Button buttonProdutos;
        private Panel panel1;
        private Label labelNomeUsuario;
        private PictureBox pictureBox1;
        private Button buttonAlterarSenha;
        private PictureBox pictureBox4;
        private Button buttonSair;
        private PictureBox pictureBox3;
        private Button buttonSobreNos;
        private PictureBox pictureBox5;
        private Label label1;
        private PictureBox pictureBox2;
        private Label label5;
        private Panel panel3;
        private Panel panel4;
        private PictureBox pictureBox6;
        private Label label7;
        private Label label2;
        private Label label3;
        private Panel panel2;
        private Label label4;
        private PictureBox pictureBox7;
        private Panel panel5;
        private Panel panel6;
        private Panel panel7;
        private Label label8;
        private PictureBox pictureBox8;
        private Label label6;
        private PictureBox pictureBox9;
        private Label label10;
        private Label label9;
    }
}