﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

namespace AcademiaDEV
{
    public class FuncionarioDAO
    {
        private readonly string connectionString;

        public FuncionarioDAO(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public class Funcionario
        {
            public int FuncionarioId { get; set; }
            public string Nome { get; set; }
            public string CPF { get; set; }
            public string Cargo { get; set; }
            public string Especializacao { get; set; }
            public string HorarioTrabalho { get; set; }
            public decimal Salario { get; set; }
            public string Email { get; set; }
        }

        public void AddFuncionario(Funcionario funcionario)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                var command = new MySqlCommand("INSERT INTO Funcionarios (Nome, CPF, Cargo, Especializacao, horario_trabalho, Salario, Email) VALUES (@Nome, @CPF, @Cargo, @Especializacao, @HorarioTrabalho, @Salario, @Email)", connection);

                command.Parameters.AddWithValue("@Nome", funcionario.Nome);
                command.Parameters.AddWithValue("@CPF", funcionario.CPF);
                command.Parameters.AddWithValue("@Cargo", funcionario.Cargo ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Especializacao", funcionario.Especializacao ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@HorarioTrabalho", funcionario.HorarioTrabalho ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Salario", funcionario.Salario);
                command.Parameters.AddWithValue("@Email", funcionario.Email ?? (object)DBNull.Value);

                command.ExecuteNonQuery();
            }
        }

        public Funcionario GetFuncionarioByCPF(string cpf)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                string query = "SELECT funcionario_id, nome, CPF, cargo, especializacao, horario_trabalho, salario, email FROM Funcionarios WHERE CPF = @CPF";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CPF", cpf);

                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Funcionario
                            {
                                FuncionarioId = reader.GetInt32(0),
                                Nome = reader.GetString(1),
                                CPF = reader.GetString(2),
                                Cargo = reader.IsDBNull(3) ? null : reader.GetString(3),
                                Especializacao = reader.IsDBNull(4) ? null : reader.GetString(4),
                                HorarioTrabalho = reader.IsDBNull(5) ? null : reader.GetString(5),
                                Salario = reader.GetDecimal(6),
                                Email = reader.IsDBNull(7) ? null : reader.GetString(7)
                            };
                        }
                    }
                }
            }
            return null;
        }

        public void UpdateFuncionario(Funcionario funcionario)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                var command = new MySqlCommand("UPDATE Funcionarios SET Nome = @Nome, CPF = @CPF, Cargo = @Cargo, Especializacao = @Especializacao, horario_trabalho = @HorarioTrabalho, Salario = @Salario, Email = @Email WHERE funcionario_id = @FuncionarioId", connection);

                command.Parameters.AddWithValue("@FuncionarioId", funcionario.FuncionarioId);
                command.Parameters.AddWithValue("@Nome", funcionario.Nome);
                command.Parameters.AddWithValue("@CPF", funcionario.CPF);
                command.Parameters.AddWithValue("@Cargo", funcionario.Cargo ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Especializacao", funcionario.Especializacao ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@HorarioTrabalho", funcionario.HorarioTrabalho ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Salario", funcionario.Salario);
                command.Parameters.AddWithValue("@Email", funcionario.Email ?? (object)DBNull.Value);

                command.ExecuteNonQuery();
            }
        }

        public void DeleteFuncionario(string cpfFuncionario)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                var command = new MySqlCommand("DELETE FROM Funcionarios WHERE CPF = @CPF", connection);
                command.Parameters.AddWithValue("@CPF", cpfFuncionario);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public List<Funcionario> GetAllFuncionarios()
        {
            List<Funcionario> funcionarios = new List<Funcionario>();

            using (var connection = new MySqlConnection(connectionString))
            {
                string query = "SELECT funcionario_id, nome, CPF, cargo, especializacao, horario_trabalho, salario, email FROM Funcionarios";

                using (var command = new MySqlCommand(query, connection))
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            funcionarios.Add(new Funcionario
                            {
                                FuncionarioId = reader.GetInt32(0),
                                Nome = reader.GetString(1),
                                CPF = reader.GetString(2),
                                Cargo = reader.IsDBNull(3) ? null : reader.GetString(3),
                                Especializacao = reader.IsDBNull(4) ? null : reader.GetString(4),
                                HorarioTrabalho = reader.IsDBNull(5) ? null : reader.GetString(5),
                                Salario = reader.GetDecimal(6),
                                Email = reader.IsDBNull(7) ? null : reader.GetString(7)
                            });
                        }
                    }
                }
            }

            return funcionarios;
        }
    }
}
