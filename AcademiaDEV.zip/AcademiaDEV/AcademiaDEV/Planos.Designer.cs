﻿namespace AcademiaDEV
{
    partial class Planos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Planos));
            buttonSemanal = new Button();
            panel1 = new Panel();
            pictureBox5 = new PictureBox();
            label10 = new Label();
            label2 = new Label();
            panel2 = new Panel();
            label11 = new Label();
            pictureBox4 = new PictureBox();
            label8 = new Label();
            label3 = new Label();
            buttonAnual = new Button();
            panel3 = new Panel();
            pictureBox3 = new PictureBox();
            label9 = new Label();
            label4 = new Label();
            buttonMensal = new Button();
            panel4 = new Panel();
            label5 = new Label();
            label7 = new Label();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            label6 = new Label();
            label1 = new Label();
            pictureBox6 = new PictureBox();
            buttonTabelaDeDados = new Button();
            buttonVoltarTela = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            SuspendLayout();
            // 
            // buttonSemanal
            // 
            buttonSemanal.Cursor = Cursors.Hand;
            buttonSemanal.FlatAppearance.BorderSize = 2;
            buttonSemanal.FlatStyle = FlatStyle.Flat;
            buttonSemanal.Font = new Font("Segoe UI", 12F);
            buttonSemanal.ForeColor = Color.White;
            buttonSemanal.Location = new Point(39, 166);
            buttonSemanal.Name = "buttonSemanal";
            buttonSemanal.Size = new Size(266, 61);
            buttonSemanal.TabIndex = 0;
            buttonSemanal.Text = "Escolher";
            buttonSemanal.UseVisualStyleBackColor = true;
            buttonSemanal.Click += buttonSemanal_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkGray;
            panel1.Controls.Add(pictureBox5);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(buttonSemanal);
            panel1.Location = new Point(624, 430);
            panel1.Name = "panel1";
            panel1.Size = new Size(329, 248);
            panel1.TabIndex = 3;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(245, 81);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(50, 39);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 15;
            pictureBox5.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Arial Black", 18F);
            label10.ForeColor = Color.White;
            label10.Location = new Point(68, 78);
            label10.Name = "label10";
            label10.Size = new Size(181, 42);
            label10.TabIndex = 14;
            label10.Text = "R$ 120.00";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 18F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(97, 21);
            label2.Name = "label2";
            label2.Size = new Size(130, 41);
            label2.TabIndex = 6;
            label2.Text = "Semanal";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gray;
            panel2.Controls.Add(label11);
            panel2.Controls.Add(pictureBox4);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(buttonAnual);
            panel2.Location = new Point(968, 166);
            panel2.Name = "panel2";
            panel2.Size = new Size(329, 512);
            panel2.TabIndex = 4;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 11F);
            label11.ForeColor = Color.White;
            label11.Location = new Point(43, 237);
            label11.Name = "label11";
            label11.Size = new Size(252, 75);
            label11.TabIndex = 12;
            label11.Text = "IMPORTANTE: O plano anual\r\ntem como uma escolha de \r\ncontrato de 1 ano.";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(252, 141);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(50, 39);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 14;
            pictureBox4.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial Black", 18F);
            label8.ForeColor = Color.White;
            label8.Location = new Point(65, 138);
            label8.Name = "label8";
            label8.Size = new Size(181, 42);
            label8.TabIndex = 12;
            label8.Text = "R$ 600.00";
            label8.Click += label8_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 18F);
            label3.ForeColor = Color.White;
            label3.Location = new Point(117, 56);
            label3.Name = "label3";
            label3.Size = new Size(93, 41);
            label3.TabIndex = 7;
            label3.Text = "Anual";
            // 
            // buttonAnual
            // 
            buttonAnual.Cursor = Cursors.Hand;
            buttonAnual.FlatAppearance.BorderColor = Color.White;
            buttonAnual.FlatAppearance.BorderSize = 2;
            buttonAnual.FlatStyle = FlatStyle.Flat;
            buttonAnual.Font = new Font("Segoe UI", 12F);
            buttonAnual.ForeColor = Color.White;
            buttonAnual.Location = new Point(29, 430);
            buttonAnual.Name = "buttonAnual";
            buttonAnual.Size = new Size(266, 61);
            buttonAnual.TabIndex = 0;
            buttonAnual.Text = "Escolher";
            buttonAnual.UseVisualStyleBackColor = true;
            buttonAnual.Click += buttonAnual_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.DimGray;
            panel3.Controls.Add(pictureBox3);
            panel3.Controls.Add(label9);
            panel3.Controls.Add(label4);
            panel3.Controls.Add(buttonMensal);
            panel3.Location = new Point(624, 166);
            panel3.Name = "panel3";
            panel3.Size = new Size(329, 258);
            panel3.TabIndex = 4;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(245, 105);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(50, 39);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 12;
            pictureBox3.TabStop = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial Black", 18F);
            label9.ForeColor = Color.White;
            label9.Location = new Point(68, 102);
            label9.Name = "label9";
            label9.Size = new Size(181, 42);
            label9.TabIndex = 13;
            label9.Text = "R$ 320.00";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 18F);
            label4.ForeColor = Color.White;
            label4.Location = new Point(114, 36);
            label4.Name = "label4";
            label4.Size = new Size(113, 41);
            label4.TabIndex = 8;
            label4.Text = "Mensal";
            // 
            // buttonMensal
            // 
            buttonMensal.Cursor = Cursors.Hand;
            buttonMensal.FlatAppearance.BorderSize = 2;
            buttonMensal.FlatStyle = FlatStyle.Flat;
            buttonMensal.Font = new Font("Segoe UI", 12F);
            buttonMensal.ForeColor = Color.White;
            buttonMensal.Location = new Point(39, 171);
            buttonMensal.Name = "buttonMensal";
            buttonMensal.Size = new Size(266, 61);
            buttonMensal.TabIndex = 0;
            buttonMensal.Text = "Escolher";
            buttonMensal.UseVisualStyleBackColor = true;
            buttonMensal.Click += buttonMensal_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Black;
            panel4.Controls.Add(label5);
            panel4.Controls.Add(label7);
            panel4.Controls.Add(pictureBox2);
            panel4.Controls.Add(pictureBox1);
            panel4.Controls.Add(label6);
            panel4.Dock = DockStyle.Left;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(451, 773);
            panel4.TabIndex = 5;
            panel4.Paint += panel4_Paint;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.ForeColor = Color.White;
            label5.Location = new Point(81, 596);
            label5.Name = "label5";
            label5.Size = new Size(273, 50);
            label5.TabIndex = 11;
            label5.Text = "IMPORTANTE: fique atento \r\na data de vencimento do plano";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(104, 392);
            label7.Name = "label7";
            label7.Size = new Size(211, 125);
            label7.TabIndex = 9;
            label7.Text = "O plano escolhido sera \r\ncadastrado de forma \r\nautomatica \r\na cada vencimento \r\nda tem aumento de 3%.";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(158, 24);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(105, 39);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 8;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.icons8_lista_de_tarefas_961;
            pictureBox1.Location = new Point(158, 185);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(105, 87);
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Black", 18F);
            label6.ForeColor = Color.White;
            label6.Location = new Point(146, 283);
            label6.Name = "label6";
            label6.Size = new Size(128, 42);
            label6.TabIndex = 6;
            label6.Text = "Planos";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Black", 18F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(673, 71);
            label1.Name = "label1";
            label1.Size = new Size(394, 42);
            label1.TabIndex = 7;
            label1.Text = "Escolha um dos planos";
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.icons8_lista_de_tarefas_961;
            pictureBox6.Location = new Point(624, 71);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(57, 42);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 12;
            pictureBox6.TabStop = false;
            // 
            // buttonTabelaDeDados
            // 
            buttonTabelaDeDados.BackColor = Color.FromArgb(64, 64, 64);
            buttonTabelaDeDados.Cursor = Cursors.Hand;
            buttonTabelaDeDados.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonTabelaDeDados.ForeColor = Color.White;
            buttonTabelaDeDados.ImageAlign = ContentAlignment.MiddleLeft;
            buttonTabelaDeDados.Location = new Point(968, 694);
            buttonTabelaDeDados.Name = "buttonTabelaDeDados";
            buttonTabelaDeDados.Size = new Size(329, 49);
            buttonTabelaDeDados.TabIndex = 12;
            buttonTabelaDeDados.Text = "Dados";
            buttonTabelaDeDados.UseVisualStyleBackColor = false;
            buttonTabelaDeDados.Click += buttonTabelaDeDados_Click;
            // 
            // buttonVoltarTela
            // 
            buttonVoltarTela.BackColor = Color.FromArgb(64, 64, 64);
            buttonVoltarTela.Cursor = Cursors.Hand;
            buttonVoltarTela.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonVoltarTela.ForeColor = Color.White;
            buttonVoltarTela.ImageAlign = ContentAlignment.MiddleLeft;
            buttonVoltarTela.Location = new Point(624, 694);
            buttonVoltarTela.Name = "buttonVoltarTela";
            buttonVoltarTela.Size = new Size(329, 49);
            buttonVoltarTela.TabIndex = 14;
            buttonVoltarTela.Text = "Voltar";
            buttonVoltarTela.UseVisualStyleBackColor = false;
            buttonVoltarTela.Click += buttonVoltarTela_Click;
            // 
            // Planos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1368, 773);
            Controls.Add(buttonVoltarTela);
            Controls.Add(buttonTabelaDeDados);
            Controls.Add(pictureBox6);
            Controls.Add(label1);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MdiChildrenMinimizedAnchorBottom = false;
            MinimizeBox = false;
            Name = "Planos";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Planos";
            Load += Planos_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonSemanal;
        private Panel panel1;
        private Panel panel2;
        private Button buttonAnual;
        private Panel panel3;
        private Button buttonMensal;
        private Label label2;
        private Label label3;
        private Label label4;
        private Panel panel4;
        private Label label6;
        private Label label1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Label label7;
        private Label label10;
        private Label label8;
        private Label label9;
        private Label label5;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private Label label11;
        private PictureBox pictureBox6;
        private Button buttonTabelaDeDados;
        private Button buttonVoltarTela;
    }
}