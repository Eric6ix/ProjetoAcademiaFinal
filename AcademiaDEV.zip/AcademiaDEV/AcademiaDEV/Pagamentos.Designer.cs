﻿namespace AcademiaDEV
{
    partial class Pagamentos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pagamentos));
            panel1 = new Panel();
            buttoPagamentosGeraPDF = new Button();
            buttonPlanosGerarPDF = new Button();
            label7 = new Label();
            pictureBox2 = new PictureBox();
            label6 = new Label();
            buttonVoltarPagamentos = new Button();
            pictureBox1 = new PictureBox();
            buttonCadastarPagamentos = new Button();
            buttonAtualizarPagamentos = new Button();
            buttonExcluirPagamentos = new Button();
            buttonEditarPagamentos = new Button();
            panel2 = new Panel();
            pictureBox3 = new PictureBox();
            label3 = new Label();
            textBoxPesquisarAlunoPg = new TextBox();
            dataGridViewPagamentos = new DataGridView();
            dataGridViewPlanos = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            buttonBuscarPagamentos = new Button();
            panel4 = new Panel();
            panel3 = new Panel();
            label4 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPagamentos).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPlanos).BeginInit();
            panel4.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(buttoPagamentosGeraPDF);
            panel1.Controls.Add(buttonPlanosGerarPDF);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(buttonVoltarPagamentos);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(410, 761);
            panel1.TabIndex = 25;
            // 
            // buttoPagamentosGeraPDF
            // 
            buttoPagamentosGeraPDF.BackColor = Color.FromArgb(255, 192, 128);
            buttoPagamentosGeraPDF.Cursor = Cursors.Hand;
            buttoPagamentosGeraPDF.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttoPagamentosGeraPDF.Image = Properties.Resources.icons8_pdf_2_484;
            buttoPagamentosGeraPDF.ImageAlign = ContentAlignment.MiddleLeft;
            buttoPagamentosGeraPDF.Location = new Point(48, 582);
            buttoPagamentosGeraPDF.Name = "buttoPagamentosGeraPDF";
            buttoPagamentosGeraPDF.Size = new Size(301, 60);
            buttoPagamentosGeraPDF.TabIndex = 35;
            buttoPagamentosGeraPDF.Text = "PDF Pagamento";
            buttoPagamentosGeraPDF.UseVisualStyleBackColor = false;
            buttoPagamentosGeraPDF.Click += buttoPagamentosGeraPDF_Click;
            // 
            // buttonPlanosGerarPDF
            // 
            buttonPlanosGerarPDF.BackColor = Color.LightSkyBlue;
            buttonPlanosGerarPDF.Cursor = Cursors.Hand;
            buttonPlanosGerarPDF.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonPlanosGerarPDF.Image = Properties.Resources.icons8_pdf_2_483;
            buttonPlanosGerarPDF.ImageAlign = ContentAlignment.MiddleLeft;
            buttonPlanosGerarPDF.Location = new Point(48, 516);
            buttonPlanosGerarPDF.Name = "buttonPlanosGerarPDF";
            buttonPlanosGerarPDF.Size = new Size(301, 60);
            buttonPlanosGerarPDF.TabIndex = 34;
            buttonPlanosGerarPDF.Text = "PDF Plano";
            buttonPlanosGerarPDF.UseVisualStyleBackColor = false;
            buttonPlanosGerarPDF.Click += buttonPlanosGerarPDF_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(29, 331);
            label7.Name = "label7";
            label7.Size = new Size(347, 75);
            label7.TabIndex = 24;
            label7.Text = "         Faça o registro de pagamentos\r\n   informando os registro de pagamento\r\n         pessoais e cadastre no sistema. ";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(148, 31);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(105, 39);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 25;
            pictureBox2.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Black", 18F);
            label6.ForeColor = Color.White;
            label6.Location = new Point(92, 280);
            label6.Name = "label6";
            label6.Size = new Size(220, 42);
            label6.TabIndex = 24;
            label6.Text = "Pagamentos";
            // 
            // buttonVoltarPagamentos
            // 
            buttonVoltarPagamentos.BackColor = Color.Gainsboro;
            buttonVoltarPagamentos.Cursor = Cursors.Hand;
            buttonVoltarPagamentos.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonVoltarPagamentos.Image = Properties.Resources.icons8_voltar_48;
            buttonVoltarPagamentos.ImageAlign = ContentAlignment.MiddleLeft;
            buttonVoltarPagamentos.Location = new Point(48, 648);
            buttonVoltarPagamentos.Name = "buttonVoltarPagamentos";
            buttonVoltarPagamentos.Size = new Size(301, 50);
            buttonVoltarPagamentos.TabIndex = 13;
            buttonVoltarPagamentos.Text = "Voltar";
            buttonVoltarPagamentos.UseVisualStyleBackColor = false;
            buttonVoltarPagamentos.Click += buttonVoltarPagamentos_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(148, 145);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(105, 108);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // buttonCadastarPagamentos
            // 
            buttonCadastarPagamentos.BackColor = Color.FromArgb(192, 255, 192);
            buttonCadastarPagamentos.Cursor = Cursors.Hand;
            buttonCadastarPagamentos.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonCadastarPagamentos.Image = Properties.Resources.kkkkkf;
            buttonCadastarPagamentos.ImageAlign = ContentAlignment.MiddleLeft;
            buttonCadastarPagamentos.Location = new Point(38, 23);
            buttonCadastarPagamentos.Name = "buttonCadastarPagamentos";
            buttonCadastarPagamentos.Size = new Size(232, 85);
            buttonCadastarPagamentos.TabIndex = 26;
            buttonCadastarPagamentos.Text = "Cadastrar";
            buttonCadastarPagamentos.UseVisualStyleBackColor = false;
            buttonCadastarPagamentos.Click += buttonCadastarPagamentos_Click;
            // 
            // buttonAtualizarPagamentos
            // 
            buttonAtualizarPagamentos.BackColor = Color.FromArgb(255, 224, 192);
            buttonAtualizarPagamentos.Cursor = Cursors.Hand;
            buttonAtualizarPagamentos.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonAtualizarPagamentos.Image = Properties.Resources.icons8_synchronize_52;
            buttonAtualizarPagamentos.ImageAlign = ContentAlignment.MiddleLeft;
            buttonAtualizarPagamentos.Location = new Point(276, 23);
            buttonAtualizarPagamentos.Name = "buttonAtualizarPagamentos";
            buttonAtualizarPagamentos.Size = new Size(232, 85);
            buttonAtualizarPagamentos.TabIndex = 27;
            buttonAtualizarPagamentos.Text = "Atualizar";
            buttonAtualizarPagamentos.UseVisualStyleBackColor = false;
            buttonAtualizarPagamentos.Click += buttonAtualizarPagamentos_Click;
            // 
            // buttonExcluirPagamentos
            // 
            buttonExcluirPagamentos.BackColor = Color.FromArgb(255, 192, 192);
            buttonExcluirPagamentos.Cursor = Cursors.Hand;
            buttonExcluirPagamentos.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonExcluirPagamentos.Image = Properties.Resources.icons8_trash_can_48;
            buttonExcluirPagamentos.ImageAlign = ContentAlignment.MiddleLeft;
            buttonExcluirPagamentos.Location = new Point(514, 23);
            buttonExcluirPagamentos.Name = "buttonExcluirPagamentos";
            buttonExcluirPagamentos.Size = new Size(232, 85);
            buttonExcluirPagamentos.TabIndex = 28;
            buttonExcluirPagamentos.Text = "Excluir";
            buttonExcluirPagamentos.UseVisualStyleBackColor = false;
            buttonExcluirPagamentos.Click += buttonExcluirPagamentos_Click;
            // 
            // buttonEditarPagamentos
            // 
            buttonEditarPagamentos.BackColor = Color.FromArgb(192, 192, 255);
            buttonEditarPagamentos.Cursor = Cursors.Hand;
            buttonEditarPagamentos.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonEditarPagamentos.Image = Properties.Resources.icons8_editar_48;
            buttonEditarPagamentos.ImageAlign = ContentAlignment.MiddleLeft;
            buttonEditarPagamentos.Location = new Point(752, 23);
            buttonEditarPagamentos.Name = "buttonEditarPagamentos";
            buttonEditarPagamentos.Size = new Size(232, 86);
            buttonEditarPagamentos.TabIndex = 29;
            buttonEditarPagamentos.Text = "Editar";
            buttonEditarPagamentos.UseVisualStyleBackColor = false;
            buttonEditarPagamentos.Click += buttonEditarPagamentos_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(textBoxPesquisarAlunoPg);
            panel2.Location = new Point(556, 102);
            panel2.Name = "panel2";
            panel2.Size = new Size(583, 60);
            panel2.TabIndex = 30;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(7, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(46, 54);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 26;
            pictureBox3.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 10F);
            label3.ForeColor = Color.FromArgb(64, 64, 64);
            label3.Location = new Point(59, 16);
            label3.Name = "label3";
            label3.Size = new Size(119, 23);
            label3.TabIndex = 15;
            label3.Text = "Pesquisar CPF:";
            // 
            // textBoxPesquisarAlunoPg
            // 
            textBoxPesquisarAlunoPg.BackColor = Color.Gainsboro;
            textBoxPesquisarAlunoPg.BorderStyle = BorderStyle.None;
            textBoxPesquisarAlunoPg.Location = new Point(184, 16);
            textBoxPesquisarAlunoPg.Multiline = true;
            textBoxPesquisarAlunoPg.Name = "textBoxPesquisarAlunoPg";
            textBoxPesquisarAlunoPg.Size = new Size(364, 27);
            textBoxPesquisarAlunoPg.TabIndex = 14;
            // 
            // dataGridViewPagamentos
            // 
            dataGridViewPagamentos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewPagamentos.Location = new Point(432, 375);
            dataGridViewPagamentos.Name = "dataGridViewPagamentos";
            dataGridViewPagamentos.RowHeadersWidth = 51;
            dataGridViewPagamentos.Size = new Size(493, 374);
            dataGridViewPagamentos.TabIndex = 31;
            // 
            // dataGridViewPlanos
            // 
            dataGridViewPlanos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewPlanos.Location = new Point(941, 375);
            dataGridViewPlanos.Name = "dataGridViewPlanos";
            dataGridViewPlanos.RowHeadersWidth = 51;
            dataGridViewPlanos.Size = new Size(527, 374);
            dataGridViewPlanos.TabIndex = 32;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Black", 12F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(432, 340);
            label1.Name = "label1";
            label1.Size = new Size(145, 28);
            label1.TabIndex = 26;
            label1.Text = "Pagamentos";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Black", 12F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(946, 340);
            label2.Name = "label2";
            label2.Size = new Size(84, 28);
            label2.TabIndex = 33;
            label2.Text = "Planos";
            // 
            // buttonBuscarPagamentos
            // 
            buttonBuscarPagamentos.BackColor = Color.FromArgb(224, 224, 224);
            buttonBuscarPagamentos.Cursor = Cursors.Hand;
            buttonBuscarPagamentos.Image = Properties.Resources.icons8_pesquisar_48;
            buttonBuscarPagamentos.Location = new Point(1145, 102);
            buttonBuscarPagamentos.Name = "buttonBuscarPagamentos";
            buttonBuscarPagamentos.Size = new Size(112, 60);
            buttonBuscarPagamentos.TabIndex = 35;
            buttonBuscarPagamentos.UseVisualStyleBackColor = false;
            buttonBuscarPagamentos.Click += buttonBuscarPagamentos_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Black;
            panel4.Controls.Add(buttonCadastarPagamentos);
            panel4.Controls.Add(buttonAtualizarPagamentos);
            panel4.Controls.Add(buttonExcluirPagamentos);
            panel4.Controls.Add(buttonEditarPagamentos);
            panel4.Location = new Point(432, 190);
            panel4.Name = "panel4";
            panel4.Size = new Size(1026, 132);
            panel4.TabIndex = 36;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Black;
            panel3.Controls.Add(label4);
            panel3.Location = new Point(382, -15);
            panel3.Name = "panel3";
            panel3.Size = new Size(1076, 72);
            panel3.TabIndex = 37;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Black", 11F);
            label4.ForeColor = Color.White;
            label4.Location = new Point(921, 33);
            label4.Name = "label4";
            label4.Size = new Size(134, 27);
            label4.TabIndex = 26;
            label4.Text = "Bem vindo !";
            // 
            // Pagamentos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1480, 761);
            Controls.Add(panel3);
            Controls.Add(label1);
            Controls.Add(panel4);
            Controls.Add(buttonBuscarPagamentos);
            Controls.Add(dataGridViewPlanos);
            Controls.Add(label2);
            Controls.Add(dataGridViewPagamentos);
            Controls.Add(panel1);
            Controls.Add(panel2);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Pagamentos";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Pagamentos";
            Load += Pagamentos_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPagamentos).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPlanos).EndInit();
            panel4.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label7;
        private PictureBox pictureBox2;
        private Label label6;
        private Button buttonVoltarPagamentos;
        private PictureBox pictureBox1;
        private Button buttonCadastarPagamentos;
        private Button buttonAtualizarPagamentos;
        private Button buttonExcluirPagamentos;
        private Button buttonEditarPagamentos;
        private Panel panel2;
        private PictureBox pictureBox3;
        private Label label3;
        private TextBox textBoxPesquisarAlunoPg;
        private DataGridView dataGridViewPagamentos;
        private DataGridView dataGridViewPlanos;
        private Label label1;
        private Label label2;
        private Button buttonPlanosGerarPDF;
        private Button buttoPagamentosGeraPDF;
        private Button buttonBuscarPagamentos;
        private Panel panel4;
        private Panel panel3;
        private Label label4;
    }
}