﻿namespace AcademiaDEV
{
    partial class Produtos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Produtos));
            buttonLoja = new Button();
            buttonCadastrar = new Button();
            buttonAtualizar = new Button();
            buttonExcluir = new Button();
            dataGridViewProdutos = new DataGridView();
            textBoxPesquisarProduto = new TextBox();
            buttonBuscarProduto = new Button();
            pictureBoxCodigoBarrasObj = new PictureBox();
            panel1 = new Panel();
            buttonProdutoPDF = new Button();
            label7 = new Label();
            pictureBox2 = new PictureBox();
            label6 = new Label();
            buttonVoltarTela = new Button();
            pictureBox1 = new PictureBox();
            panel3 = new Panel();
            label9 = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            panel4 = new Panel();
            ((System.ComponentModel.ISupportInitialize)dataGridViewProdutos).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCodigoBarrasObj).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // buttonLoja
            // 
            buttonLoja.BackColor = Color.FromArgb(192, 192, 255);
            buttonLoja.Cursor = Cursors.Hand;
            buttonLoja.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonLoja.Image = Properties.Resources.icons8_adicionar_o_carrinho_de_compras_50;
            buttonLoja.ImageAlign = ContentAlignment.MiddleLeft;
            buttonLoja.Location = new Point(748, 20);
            buttonLoja.Name = "buttonLoja";
            buttonLoja.Size = new Size(232, 85);
            buttonLoja.TabIndex = 0;
            buttonLoja.Text = "Ajustar\r\nEstoque";
            buttonLoja.UseVisualStyleBackColor = false;
            buttonLoja.Click += buttonLoja_Click;
            // 
            // buttonCadastrar
            // 
            buttonCadastrar.BackColor = Color.FromArgb(192, 255, 192);
            buttonCadastrar.Cursor = Cursors.Hand;
            buttonCadastrar.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonCadastrar.Image = Properties.Resources.icons8_adicionar_usuário_masculino_60;
            buttonCadastrar.ImageAlign = ContentAlignment.MiddleLeft;
            buttonCadastrar.Location = new Point(34, 20);
            buttonCadastrar.Name = "buttonCadastrar";
            buttonCadastrar.Size = new Size(232, 85);
            buttonCadastrar.TabIndex = 18;
            buttonCadastrar.Text = "Cadastrar";
            buttonCadastrar.UseVisualStyleBackColor = false;
            buttonCadastrar.Click += buttonCadastrar_Click;
            // 
            // buttonAtualizar
            // 
            buttonAtualizar.BackColor = Color.FromArgb(255, 224, 192);
            buttonAtualizar.Cursor = Cursors.Hand;
            buttonAtualizar.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonAtualizar.Image = Properties.Resources.icons8_synchronize_52;
            buttonAtualizar.ImageAlign = ContentAlignment.MiddleLeft;
            buttonAtualizar.Location = new Point(272, 20);
            buttonAtualizar.Name = "buttonAtualizar";
            buttonAtualizar.Size = new Size(232, 85);
            buttonAtualizar.TabIndex = 19;
            buttonAtualizar.Text = "Atualizar";
            buttonAtualizar.UseVisualStyleBackColor = false;
            buttonAtualizar.Click += buttonAtualizar_Click;
            // 
            // buttonExcluir
            // 
            buttonExcluir.BackColor = Color.FromArgb(255, 192, 192);
            buttonExcluir.Cursor = Cursors.Hand;
            buttonExcluir.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonExcluir.Image = Properties.Resources.icons8_trash_can_48;
            buttonExcluir.ImageAlign = ContentAlignment.MiddleLeft;
            buttonExcluir.Location = new Point(510, 20);
            buttonExcluir.Name = "buttonExcluir";
            buttonExcluir.Size = new Size(232, 85);
            buttonExcluir.TabIndex = 20;
            buttonExcluir.Text = "Excluir";
            buttonExcluir.UseVisualStyleBackColor = false;
            buttonExcluir.Click += buttonExcluir_Click;
            // 
            // dataGridViewProdutos
            // 
            dataGridViewProdutos.BackgroundColor = SystemColors.AppWorkspace;
            dataGridViewProdutos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewProdutos.GridColor = Color.Gray;
            dataGridViewProdutos.Location = new Point(19, 180);
            dataGridViewProdutos.Name = "dataGridViewProdutos";
            dataGridViewProdutos.RowHeadersWidth = 51;
            dataGridViewProdutos.Size = new Size(995, 340);
            dataGridViewProdutos.TabIndex = 21;
            // 
            // textBoxPesquisarProduto
            // 
            textBoxPesquisarProduto.BackColor = Color.White;
            textBoxPesquisarProduto.BorderStyle = BorderStyle.None;
            textBoxPesquisarProduto.Location = new Point(451, 55);
            textBoxPesquisarProduto.Multiline = true;
            textBoxPesquisarProduto.Name = "textBoxPesquisarProduto";
            textBoxPesquisarProduto.Size = new Size(445, 27);
            textBoxPesquisarProduto.TabIndex = 22;
            // 
            // buttonBuscarProduto
            // 
            buttonBuscarProduto.BackColor = Color.FromArgb(224, 224, 224);
            buttonBuscarProduto.Cursor = Cursors.Hand;
            buttonBuscarProduto.Image = Properties.Resources.icons8_pesquisar_48;
            buttonBuscarProduto.Location = new Point(902, 35);
            buttonBuscarProduto.Name = "buttonBuscarProduto";
            buttonBuscarProduto.Size = new Size(112, 60);
            buttonBuscarProduto.TabIndex = 23;
            buttonBuscarProduto.UseVisualStyleBackColor = false;
            buttonBuscarProduto.Click += buttonBuscarProduto_Click;
            // 
            // pictureBoxCodigoBarrasObj
            // 
            pictureBoxCodigoBarrasObj.Location = new Point(686, 139);
            pictureBoxCodigoBarrasObj.Name = "pictureBoxCodigoBarrasObj";
            pictureBoxCodigoBarrasObj.Size = new Size(595, 66);
            pictureBoxCodigoBarrasObj.TabIndex = 25;
            pictureBoxCodigoBarrasObj.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(buttonProdutoPDF);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(buttonVoltarTela);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(410, 761);
            panel1.TabIndex = 27;
            // 
            // buttonProdutoPDF
            // 
            buttonProdutoPDF.BackColor = Color.FromArgb(255, 192, 128);
            buttonProdutoPDF.Cursor = Cursors.Hand;
            buttonProdutoPDF.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonProdutoPDF.Image = Properties.Resources.icons8_pdf_2_481;
            buttonProdutoPDF.ImageAlign = ContentAlignment.MiddleLeft;
            buttonProdutoPDF.Location = new Point(48, 582);
            buttonProdutoPDF.Name = "buttonProdutoPDF";
            buttonProdutoPDF.Size = new Size(301, 60);
            buttonProdutoPDF.TabIndex = 32;
            buttonProdutoPDF.Text = "PDF Produtos";
            buttonProdutoPDF.UseVisualStyleBackColor = false;
            buttonProdutoPDF.Click += buttonProdutoPDF_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(68, 461);
            label7.Name = "label7";
            label7.Size = new Size(267, 75);
            label7.TabIndex = 24;
            label7.Text = "  Faça o registro de produtos\r\n informando suas informações\r\n               no sistema.";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(148, 31);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(105, 39);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 25;
            pictureBox2.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Black", 18F);
            label6.ForeColor = Color.White;
            label6.Location = new Point(106, 363);
            label6.Name = "label6";
            label6.Size = new Size(174, 42);
            label6.TabIndex = 24;
            label6.Text = " Produtos";
            // 
            // buttonVoltarTela
            // 
            buttonVoltarTela.BackColor = Color.Gainsboro;
            buttonVoltarTela.Cursor = Cursors.Hand;
            buttonVoltarTela.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonVoltarTela.Image = Properties.Resources.icons8_voltar_48;
            buttonVoltarTela.ImageAlign = ContentAlignment.MiddleLeft;
            buttonVoltarTela.Location = new Point(48, 648);
            buttonVoltarTela.Name = "buttonVoltarTela";
            buttonVoltarTela.Size = new Size(301, 50);
            buttonVoltarTela.TabIndex = 13;
            buttonVoltarTela.Text = "Voltar";
            buttonVoltarTela.UseVisualStyleBackColor = false;
            buttonVoltarTela.Click += buttonVoltarTela_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(148, 252);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(105, 108);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Black;
            panel3.Controls.Add(label9);
            panel3.Controls.Add(dataGridViewProdutos);
            panel3.Controls.Add(buttonCadastrar);
            panel3.Controls.Add(buttonAtualizar);
            panel3.Controls.Add(buttonExcluir);
            panel3.Controls.Add(buttonLoja);
            panel3.Location = new Point(432, 211);
            panel3.Name = "panel3";
            panel3.Size = new Size(1036, 538);
            panel3.TabIndex = 31;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(24, 137);
            label9.Name = "label9";
            label9.Size = new Size(218, 23);
            label9.TabIndex = 26;
            label9.Text = "Dados salvo do produto.";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Black", 12F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(476, 156);
            label1.Name = "label1";
            label1.Size = new Size(204, 28);
            label1.TabIndex = 26;
            label1.Text = "Codigo de barras:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Black", 18F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(24, 38);
            label2.Name = "label2";
            label2.Size = new Size(335, 42);
            label2.TabIndex = 26;
            label2.Text = "Cadastrar Produtos";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(451, 19);
            label3.Name = "label3";
            label3.Size = new Size(83, 28);
            label3.TabIndex = 15;
            label3.Text = "Codigo.";
            // 
            // panel4
            // 
            panel4.BackColor = Color.Black;
            panel4.Controls.Add(label2);
            panel4.Controls.Add(label3);
            panel4.Controls.Add(textBoxPesquisarProduto);
            panel4.Controls.Add(buttonBuscarProduto);
            panel4.Location = new Point(432, 12);
            panel4.Name = "panel4";
            panel4.Size = new Size(1036, 121);
            panel4.TabIndex = 29;
            // 
            // Produtos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1480, 761);
            Controls.Add(panel4);
            Controls.Add(label1);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Controls.Add(pictureBoxCodigoBarrasObj);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Produtos";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Produtos";
            Load += Produtos_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewProdutos).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCodigoBarrasObj).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonLoja;
        private Button buttonCadastrar;
        private Button buttonAtualizar;
        private Button buttonExcluir;
        private DataGridView dataGridViewProdutos;
        private TextBox textBoxPesquisarProduto;
        private Button buttonBuscarProduto;
        private PictureBox pictureBoxCodigoBarrasObj;
        private Panel panel1;
        private Label label7;
        private PictureBox pictureBox2;
        private Label label6;
        private Button buttonVoltarTela;
        private PictureBox pictureBox1;
        private Panel panel3;
        private Label label9;
        private Label label1;
        private Label label2;
        private Label label3;
        private Panel panel4;
        private Button buttonProdutoPDF;
    }
}