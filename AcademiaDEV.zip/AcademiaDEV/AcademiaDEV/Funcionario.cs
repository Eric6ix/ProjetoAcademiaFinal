﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iTextSharp.text.pdf;
using iTextSharp.text;
using MySql.Data.MySqlClient;

namespace AcademiaDEV
{
    public partial class Funcionario : Form
    {
        private readonly FuncionarioDAO funcionarioDAO;
        private string usuarioLogado;

        public Funcionario(string usuario)
        {
            InitializeComponent();
            string connectionString = @"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None";
            funcionarioDAO = new FuncionarioDAO(connectionString);
            usuarioLogado = usuario;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void Funcionario_Load(object sender, EventArgs e)
        {
            LoadFuncionarios();

            dataGridView.ReadOnly = true;
            // Desabilita a adição de novas linhas
            dataGridView.AllowUserToAddRows = false;

            // Define o modo de seleção para linha inteira
            dataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Desabilita a edição ao clicar duas vezes
            dataGridView.CellDoubleClick += (s, e) => {
                // Cancela a edição de célula
                dataGridView.CurrentCell = null; // Desmarca a célula atual
                dataGridView.BeginEdit(false); // Impede que a célula entre em modo de edição
            };
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textPesquisa.Text))
            {
                MessageBox.Show("Digite o CPF do funcionário em Pesquisar acima!");
                return;
            }

            try
            {
                string deletefuncionario_cpf = textPesquisa.Text;
                funcionarioDAO.DeleteFuncionario(deletefuncionario_cpf);
                MessageBox.Show("Funcionário excluído com sucesso!");
                LoadFuncionarios();
                textPesquisa.Clear();
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 0)
                {
                    MessageBox.Show("Nenhum funcionário cadastrado com esse CPF.");
                }
                else
                {
                    MessageBox.Show($"Erro ao excluir funcionário: {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao excluir funcionário: {ex.Message}");
            }
        }

        private void buttonBuscar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textPesquisa.Text))
            {
                MessageBox.Show("Digite o CPF do funcionário para buscar.");
                return;
            }

            try
            {
                string cpf_funcionario = textPesquisa.Text;
                var funcionario = funcionarioDAO.GetFuncionarioByCPF(cpf_funcionario);

                if (funcionario != null)
                {
                    MessageBox.Show("Funcionário encontrado.");
                }
                else
                {
                    MessageBox.Show("Nenhum funcionário cadastrado com esse CPF.");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar funcionário: {ex.Message}");
            }
        }

        private void buttonAtualizar_Click(object sender, EventArgs e)
        {
            LoadFuncionarios();
        }

        private void LoadFuncionarios()
        {
            try
            {
                var funcionarios = funcionarioDAO.GetAllFuncionarios();
                dataGridView.DataSource = funcionarios;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar funcionários: {ex.Message}");
            }
        }

        private void buttonVoltar_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<HomeOpçõescs>().Any())
            {
                Application.OpenForms.OfType<HomeOpçõescs>().First().Show();
            }
            else
            {
                HomeOpçõescs voltarHome = new HomeOpçõescs(usuarioLogado, "");
                voltarHome.ShowDialog();
            }
            this.Hide();
        }

        private void buttonCadastrarFuncionarios_Click(object sender, EventArgs e)
        {
            CadastrarFuncionarios cadastrarFuncionarios = new CadastrarFuncionarios();
            cadastrarFuncionarios.ShowDialog();
            LoadFuncionarios(); // Atualiza a lista após cadastro
        }

        private void buttonEditarFuncionario_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textPesquisa.Text))
            {
                MessageBox.Show("Digite o CPF do funcionário para editar.");
                return;
            }

            try
            {
                string cpf_funcionario = textPesquisa.Text;
                var funcionario = funcionarioDAO.GetFuncionarioByCPF(cpf_funcionario);

                if (funcionario != null)
                {
                    // Abre a tela de edição com o funcionário encontrado
                    CadastrarFuncionarios CadastroFuncionarioObj = new CadastrarFuncionarios(funcionario);
                    CadastroFuncionarioObj.ShowDialog();
                    LoadFuncionarios(); // Recarrega a lista após a edição
                }
                else
                {
                    MessageBox.Show("Nenhum funcionário cadastrado com esse CPF.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar funcionário: {ex.Message}");
            }
        }
        private void buttonFuncionarioPDF_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Você tem certeza que deseja gerar PDF Funcionários?", "Confirmar Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                try
                {
                    // Obtendo o caminho da Área de Trabalho (Desktop) do usuário
                    string desktopFolder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                    // Definindo o caminho completo do arquivo PDF na Área de Trabalho
                    string filePath = Path.Combine(desktopFolder, "ListaFuncionários.pdf");

                    // Criando o documento PDF e o escritor
                    Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
                    PdfWriter writer = PdfWriter.GetInstance(pdfDoc, new FileStream(filePath, FileMode.Create));

                    pdfDoc.Open();

                    // Fonte para o texto
                    BaseFont bf = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                    iTextSharp.text.Font font = new iTextSharp.text.Font(bf, 10, iTextSharp.text.Font.NORMAL);

                    // Criando a tabela PDF com o número de colunas do DataGridView de planos
                    PdfPTable pdfTable = new PdfPTable(dataGridView.Columns.Count);
                    pdfTable.WidthPercentage = 100;

                    // Adicionando cabeçalhos do DataGridView ao PDF
                    foreach (DataGridViewColumn column in dataGridView.Columns)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText, font));
                        cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                        pdfTable.AddCell(cell);
                    }

                    // Adicionando as linhas da DataGridView ao PDF
                    foreach (DataGridViewRow row in dataGridView.Rows)
                    {
                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            pdfTable.AddCell(new Phrase(cell.Value?.ToString() ?? string.Empty, font));
                        }
                    }

                    // Adicionando a tabela ao documento PDF
                    pdfDoc.Add(pdfTable);
                    pdfDoc.Close();

                    // Verificando se o arquivo foi criado com sucesso antes de tentar abrir
                    if (File.Exists(filePath))
                    {
                        // Abrir o arquivo PDF gerado
                        Process.Start(new ProcessStartInfo(filePath) { UseShellExecute = true });

                        // Exibe uma mensagem de sucesso
                        MessageBox.Show("PDF de Planos gerado com sucesso na área de trabalho e aberto!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Erro: O arquivo PDF não foi gerado corretamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    // Exibe uma mensagem de erro se algo falhar
                    MessageBox.Show("Erro ao gerar ou abrir PDF: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {
           
        }

        
    }
}
