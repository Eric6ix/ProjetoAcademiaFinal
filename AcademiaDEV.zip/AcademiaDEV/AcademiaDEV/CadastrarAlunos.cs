﻿using System;
using System.Windows.Forms;
using static AlunoDAO;

namespace AcademiaDEV
{
    public partial class CadastrarAlunos : Form
    {
        public static string ConnectionString = @"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None";
        private AlunoDAO alunoDAO;
        private Aluno alunoAtual; // Adiciona um campo para armazenar o aluno atual

        public CadastrarAlunos()
        {
            InitializeComponent();
            alunoDAO = new AlunoDAO(ConnectionString);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        // Construtor para edição
        public CadastrarAlunos(Aluno aluno) : this()
        {
            alunoAtual = aluno;
            PreencherCampos(aluno);
        }

        private void PreencherCampos(Aluno aluno)
        {
            txtNome.Text = aluno.Nome;
            txtCPF.Text = aluno.CPF;
            txtDataNascimento.Text = aluno.DataNascimento.ToString("dd/MM/yyyy");
            txtEndereco.Text = aluno.Endereco;
            txtTelefone.Text = aluno.Telefone;
            txtInformacoesMedicas.Text = aluno.InformacoesMedicas;
            txtDataMatricula.Text = aluno.DataMatricula.ToString("dd/MM/yyyy");
        }

        private void buttonAddAluno_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text) || string.IsNullOrWhiteSpace(txtCPF.Text) ||
                string.IsNullOrWhiteSpace(txtEndereco.Text) || string.IsNullOrWhiteSpace(txtTelefone.Text) ||
                string.IsNullOrWhiteSpace(txtInformacoesMedicas.Text))
            {
                MessageBox.Show("Os espaços de preencher estão vazios, ou algum deles!");
                return;
            }

            try
            {
                if (alunoAtual == null) // Se alunoAtual for null, estamos criando um novo aluno
                {
                    Aluno aluno = new Aluno
                    {
                        Nome = txtNome.Text,
                        CPF = txtCPF.Text,
                        DataNascimento = DateTime.Parse(txtDataNascimento.Text),
                        Endereco = txtEndereco.Text,
                        Telefone = txtTelefone.Text,
                        InformacoesMedicas = txtInformacoesMedicas.Text,
                        DataMatricula = DateTime.Parse(txtDataMatricula.Text)
                    };

                    alunoDAO.AddAluno(aluno);
                    MessageBox.Show("Aluno adicionado com sucesso!");
                }
                else // Caso contrário, estamos editando um aluno existente
                {
                    alunoAtual.Nome = txtNome.Text;
                    alunoAtual.CPF = txtCPF.Text;
                    alunoAtual.DataNascimento = DateTime.Parse(txtDataNascimento.Text);
                    alunoAtual.Endereco = txtEndereco.Text;
                    alunoAtual.Telefone = txtTelefone.Text;
                    alunoAtual.InformacoesMedicas = txtInformacoesMedicas.Text;
                    alunoAtual.DataMatricula = DateTime.Parse(txtDataMatricula.Text);

                    alunoDAO.UpdateAluno(alunoAtual);
                    MessageBox.Show("Aluno atualizado com sucesso!");
                }

                this.Close();
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Formato de data inválido. Certifique-se de usar o formato correto (dd/MM/yyyy).");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro: {ex.Message}");
            }
        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Deseja realmente cancelar?", "Confirmar", MessageBoxButtons.YesNo);
            if (resultado == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void CadastrarAlunos_Load(object sender, EventArgs e)
        {

        }
    }
}
