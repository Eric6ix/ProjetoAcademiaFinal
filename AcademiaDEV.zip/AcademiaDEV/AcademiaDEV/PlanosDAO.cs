﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

public class PlanosDAO
{
    private readonly string connectionString;

    public PlanosDAO(string connectionString)
    {
        this.connectionString = connectionString;
    }

    // Classe interna Plano
    public class Plano
    {
        public int PlanoId { get; set; }
        public string CPFAluno { get; set; }         // Novo campo CPF_aluno
        public string NomePlano { get; set; }
        public int DuracaoMeses { get; set; }
        public decimal Preco { get; set; }
        public string Descricao { get; set; }
    }

    // Método para adicionar um novo plano
    public void AddPlano(Plano plano)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "INSERT INTO Planos (CPF_aluno, nome_plano, duracao_meses, preco, descricao) " +
                           "VALUES (@CPFAluno, @NomePlano, @DuracaoMeses, @Preco, @Descricao)";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CPFAluno", plano.CPFAluno);
                command.Parameters.AddWithValue("@NomePlano", plano.NomePlano);
                command.Parameters.AddWithValue("@DuracaoMeses", plano.DuracaoMeses);
                command.Parameters.AddWithValue("@Preco", plano.Preco);
                command.Parameters.AddWithValue("@Descricao", plano.Descricao ?? (object)DBNull.Value);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    // Método para verificar se existe um plano para o CPF fornecido
    public bool PlanoExiste(string cpfAluno)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT COUNT(1) FROM Planos WHERE CPF_aluno = @CPFAluno";
            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CPFAluno", cpfAluno);
                connection.Open();
                int count = Convert.ToInt32(command.ExecuteScalar());
                return count > 0; // Retorna true se o CPF foi encontrado
            }
        }
    }

    // Método para obter um plano por ID
    public Plano GetPlanoById(int planoId)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT plano_id, CPF_aluno, nome_plano, duracao_meses, preco, descricao " +
                           "FROM Planos WHERE plano_id = @PlanoId";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@PlanoId", planoId);

                connection.Open();
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Plano
                        {
                            PlanoId = reader.GetInt32(0),
                            CPFAluno = reader.GetString(1),
                            NomePlano = reader.GetString(2),
                            DuracaoMeses = reader.GetInt32(3),
                            Preco = reader.GetDecimal(4),
                            Descricao = reader.IsDBNull(5) ? null : reader.GetString(5)
                        };
                    }
                }
            }
        }
        return null;
    }

    // Método para atualizar um plano
    public void UpdatePlano(Plano plano)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "UPDATE Planos SET CPF_aluno = @CPFAluno, nome_plano = @NomePlano, duracao_meses = @DuracaoMeses, " +
                           "preco = @Preco, descricao = @Descricao WHERE plano_id = @PlanoId";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@PlanoId", plano.PlanoId);
                command.Parameters.AddWithValue("@CPFAluno", plano.CPFAluno);
                command.Parameters.AddWithValue("@NomePlano", plano.NomePlano);
                command.Parameters.AddWithValue("@DuracaoMeses", plano.DuracaoMeses);
                command.Parameters.AddWithValue("@Preco", plano.Preco);
                command.Parameters.AddWithValue("@Descricao", plano.Descricao ?? (object)DBNull.Value);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    // Método para excluir um plano
    public void DeletePlano(string cpf_aluno)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "DELETE FROM Planos WHERE CPF_aluno = @CPFAluno";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CPFAluno", cpf_aluno);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    // Método para listar todos os planos
    public List<Plano> GetAllPlanos()
    {
        List<Plano> planos = new List<Plano>();

        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT plano_id, CPF_aluno, nome_plano, duracao_meses, preco, descricao FROM Planos";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                connection.Open();
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        planos.Add(new Plano
                        {
                            PlanoId = reader.GetInt32(0),
                            CPFAluno = reader.GetString(1),
                            NomePlano = reader.GetString(2),
                            DuracaoMeses = reader.GetInt32(3),
                            Preco = reader.GetDecimal(4),
                            Descricao = reader.IsDBNull(5) ? null : reader.GetString(5)
                        });
                    }
                }
            }
        }

        return planos;
    }
}
