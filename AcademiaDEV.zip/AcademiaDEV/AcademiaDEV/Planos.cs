﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace AcademiaDEV
{
    public partial class Planos : Form
    {
        // Defina sua string de conexão com o banco de dados MySQL
        private string connectionString = "Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None;";
        private string usuarioLogado;
      
        public Planos(string usuario)
        {
            InitializeComponent();
            usuarioLogado = usuario;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void buttonAnual_Click(object sender, EventArgs e)
        {
            ConfirmarCadastro("Anual", 12, 600.00M, "Plano anual atual.");
        }

        private void buttonMensal_Click(object sender, EventArgs e)
        {
            ConfirmarCadastro("Mensal", 1, 320.00M, "Plano mensal atual.");
        }

        private void buttonSemanal_Click(object sender, EventArgs e)
        {
            ConfirmarCadastro("Semanal", 1, 120.00M, "Plano semanal atual.");
        }
        private void buttonVoltarTela_Click(object sender, EventArgs e)
        {

            if (Application.OpenForms.OfType<HomeOpçõescs>().Any())
            {
                Application.OpenForms.OfType<HomeOpçõescs>().First().Show();
            }
            else
            {
                HomeOpçõescs voltarHome = new HomeOpçõescs(usuarioLogado, "");
                voltarHome.ShowDialog();
            }

            // Esconde o formulário atual
            this.Hide();
        }

        private void ConfirmarCadastro(string nomePlano, int duracaoMeses, decimal preco, string descricao)
        {
            using (ConfirmarCPFForm cpfForm = new ConfirmarCPFForm())
            {
                if (cpfForm.ShowDialog() == DialogResult.OK)
                {
                    string cpfAluno = cpfForm.CPFAluno;
                    CadastrarPlano(nomePlano, duracaoMeses, preco, descricao, cpfAluno);
                }
            }
        }

        private void CadastrarPlano(string nomePlano, int duracaoMeses, decimal preco, string descricao, string cpfAluno)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                string query = "INSERT INTO Planos (CPF_aluno, nome_plano, duracao_meses, preco, descricao) " +
                               "VALUES (@CPFAluno, @NomePlano, @DuracaoMeses, @Preco, @Descricao)";

                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@CPFAluno", cpfAluno);
                    cmd.Parameters.AddWithValue("@NomePlano", nomePlano);
                    cmd.Parameters.AddWithValue("@DuracaoMeses", duracaoMeses);
                    cmd.Parameters.AddWithValue("@Preco", preco);
                    cmd.Parameters.AddWithValue("@Descricao", descricao ?? (object)DBNull.Value);

                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Plano cadastrado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro ao cadastrar plano: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        private void buttonTabelaDeDados_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Pagamentos>().Any())
            {
                Application.OpenForms.OfType<Pagamentos>().First().Show();
            }
            else
            {
                Pagamentos pagamentos_obj = new Pagamentos(usuarioLogado);
                pagamentos_obj.ShowDialog();
            }

            this.Hide();
           
            


        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
            // Lógica de pintura do painel, se necessário
        }

        private void Planos_Load(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

      
    }
}
