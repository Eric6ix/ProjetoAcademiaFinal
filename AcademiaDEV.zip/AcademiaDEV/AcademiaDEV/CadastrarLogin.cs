﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace AcademiaDEV
{
    public partial class CadastrarLogin : Form
    {
        private static readonly string ConnectionString = @"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None;";

        public CadastrarLogin()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void buttonCadatrarLogin_Click(object sender, EventArgs e)
        {
            // Verifica se os campos estão preenchidos
            if (string.IsNullOrWhiteSpace(textCadastroUsuarioBox.Text) || string.IsNullOrWhiteSpace(textCadastroSenhaBox.Text))
            {
                MessageBox.Show("Por favor, preencha todos os campos.");
                return;
            }

            // Verifica se o usuário já existe
            if (UsuarioExiste(textCadastroUsuarioBox.Text))
            {
                MessageBox.Show("Usuário já cadastrado.");
                return;
            }

            using (MySqlConnection connection = new MySqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();
                    string query = "INSERT INTO UsuariosLogin (Usuario, Senha) VALUES (@Usuario, @Senha)";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Usuario", textCadastroUsuarioBox.Text);
                        command.Parameters.AddWithValue("@Senha", textCadastroSenhaBox.Text); // Armazena a senha diretamente

                        int result = command.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show("Usuário cadastrado com sucesso!");
                        }
                        else
                        {
                            MessageBox.Show("Falha ao cadastrar o usuário.");
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show($"Erro ao conectar ao banco de dados: {ex.Message}");
                }
            }
        }

        private void buttonVoltarTelaLogin_Click(object sender, EventArgs e)
        {

            if (Application.OpenForms.OfType<Formlogin>().Any())
            {
                Application.OpenForms.OfType<Formlogin>().First().Show();
            }
            else
            {
                Formlogin voltarLogin = new Formlogin();
                voltarLogin.Show();
            }
            this.Hide();
        }

        private bool UsuarioExiste(string usuario)
        {
            using (MySqlConnection connection = new MySqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM UsuariosLogin WHERE Usuario = @Usuario";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Usuario", usuario);

                        int count = Convert.ToInt32(command.ExecuteScalar());

                        return count > 0;
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show($"Erro ao conectar ao banco de dados: {ex.Message}");
                    return false;
                }
            }
        }

        private void CadastrarLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
