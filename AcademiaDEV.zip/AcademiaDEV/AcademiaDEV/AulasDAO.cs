﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

public class AulasDAO
{
    private readonly string connectionString;

    public AulasDAO(string connectionString)
    {
        this.connectionString = connectionString;
    }

    public class Aula
    {
        public int AulaId { get; set; }
        public string NomeAula { get; set; }
        public string Descricao { get; set; }
        public string NomeInstrutor { get; set; }
        public string HorarioInicio { get; set; } // Mudei para string
        public string HorarioFim { get; set; }    // Mudei para string
        public DateTime DataAula { get; set; }
        public string Treinos { get; set; }
    }

    public void AddAula(Aula aula)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "INSERT INTO Aulas (nome_aula, descricao, nome_instrutor, horario_inicio, horario_fim, data_aula, treinos) " +
                           "VALUES (@NomeAula, @Descricao, @NomeInstrutor, @HorarioInicio, @HorarioFim, @DataAula, @Treinos)";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@NomeAula", aula.NomeAula);
                command.Parameters.AddWithValue("@Descricao", aula.Descricao ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@NomeInstrutor", aula.NomeInstrutor);
                command.Parameters.AddWithValue("@HorarioInicio", aula.HorarioInicio); 
                command.Parameters.AddWithValue("@HorarioFim", aula.HorarioFim);       
                command.Parameters.AddWithValue("@DataAula", aula.DataAula);
                command.Parameters.AddWithValue("@Treinos", aula.Treinos ?? (object)DBNull.Value);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    public Aula GetAulaByNome(string nomeAula)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT aula_id, nome_aula, descricao, nome_instrutor, horario_inicio, horario_fim, data_aula, treinos " +
                           "FROM Aulas WHERE nome_aula = @NomeAula";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@NomeAula", nomeAula);
                connection.Open();

                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Aula
                        {
                            AulaId = reader.GetInt32(0),
                            NomeAula = reader.GetString(1),
                            Descricao = reader.IsDBNull(2) ? null : reader.GetString(2),
                            NomeInstrutor = reader.IsDBNull(3) ? null : reader.GetString(3),
                            HorarioInicio = reader.GetString(4), // Mudei para string
                            HorarioFim = reader.GetString(5),     // Mudei para string
                            DataAula = reader.GetDateTime(6),
                            Treinos = reader.IsDBNull(7) ? null : reader.GetString(7)
                        };
                    }
                }
            }
        }
        return null;
    }

    public void UpdateAula(Aula aula)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "UPDATE Aulas SET nome_aula = @NomeAula, descricao = @Descricao, nome_instrutor = @NomeInstrutor, " +
                           "horario_inicio = @HorarioInicio, horario_fim = @HorarioFim, data_aula = @DataAula, treinos = @Treinos " +
                           "WHERE aula_id = @AulaId";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@AulaId", aula.AulaId);
                command.Parameters.AddWithValue("@NomeAula", aula.NomeAula);
                command.Parameters.AddWithValue("@Descricao", aula.Descricao ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@NomeInstrutor", aula.NomeInstrutor);
                command.Parameters.AddWithValue("@HorarioInicio", aula.HorarioInicio); 
                command.Parameters.AddWithValue("@HorarioFim", aula.HorarioFim);       
                command.Parameters.AddWithValue("@DataAula", aula.DataAula);
                command.Parameters.AddWithValue("@Treinos", aula.Treinos ?? (object)DBNull.Value);

                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    public void DeleteAula(string nomeAula)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "DELETE FROM Aulas WHERE nome_aula = @NomeAula";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@NomeAula", nomeAula);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }

    public List<Aula> GetAllAulas()
    {
        List<Aula> aulas = new List<Aula>();

        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT aula_id, nome_aula, descricao, nome_instrutor, horario_inicio, horario_fim, data_aula, treinos FROM Aulas";

            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                connection.Open();
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        aulas.Add(new Aula
                        {
                            AulaId = reader.GetInt32(0),
                            NomeAula = reader.GetString(1),
                            Descricao = reader.IsDBNull(2) ? null : reader.GetString(2),
                            NomeInstrutor = reader.IsDBNull(3) ? null : reader.GetString(3),
                            HorarioInicio = reader.GetString(4), 
                            HorarioFim = reader.GetString(5),     
                            DataAula = reader.GetDateTime(6),
                            Treinos = reader.IsDBNull(7) ? null : reader.GetString(7)
                        });
                    }
                }
            }
        }

        return aulas;
    }
}
