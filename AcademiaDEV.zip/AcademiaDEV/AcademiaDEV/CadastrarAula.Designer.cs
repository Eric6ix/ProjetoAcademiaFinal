﻿namespace AcademiaDEV
{
    partial class CadastrarAula
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastrarAula));
            textBoxNomeAula = new TextBox();
            textBoxDescricaoAula = new TextBox();
            textBoxInstrutorAula = new TextBox();
            textBoxHorarioInicio = new TextBox();
            textBoxHorarioFim = new TextBox();
            monthCalendarAula = new MonthCalendar();
            textBoxTreinosAula = new TextBox();
            buttonAddAula = new Button();
            panel1 = new Panel();
            label11 = new Label();
            label10 = new Label();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            label4 = new Label();
            panel3 = new Panel();
            label2 = new Label();
            label1 = new Label();
            panel4 = new Panel();
            label3 = new Label();
            label5 = new Label();
            panel5 = new Panel();
            label6 = new Label();
            buttonCancelarAulas = new Button();
            panel7 = new Panel();
            label9 = new Label();
            label13 = new Label();
            label7 = new Label();
            pictureBox2 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // textBoxNomeAula
            // 
            textBoxNomeAula.Location = new Point(134, 24);
            textBoxNomeAula.Name = "textBoxNomeAula";
            textBoxNomeAula.Size = new Size(706, 27);
            textBoxNomeAula.TabIndex = 0;
            textBoxNomeAula.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxDescricaoAula
            // 
            textBoxDescricaoAula.Location = new Point(197, 21);
            textBoxDescricaoAula.Name = "textBoxDescricaoAula";
            textBoxDescricaoAula.Size = new Size(369, 27);
            textBoxDescricaoAula.TabIndex = 1;
            textBoxDescricaoAula.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxInstrutorAula
            // 
            textBoxInstrutorAula.Location = new Point(532, 25);
            textBoxInstrutorAula.Name = "textBoxInstrutorAula";
            textBoxInstrutorAula.Size = new Size(308, 27);
            textBoxInstrutorAula.TabIndex = 2;
            textBoxInstrutorAula.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxHorarioInicio
            // 
            textBoxHorarioInicio.Location = new Point(118, 24);
            textBoxHorarioInicio.Name = "textBoxHorarioInicio";
            textBoxHorarioInicio.Size = new Size(178, 27);
            textBoxHorarioInicio.TabIndex = 3;
            textBoxHorarioInicio.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxHorarioFim
            // 
            textBoxHorarioFim.Location = new Point(390, 23);
            textBoxHorarioFim.Name = "textBoxHorarioFim";
            textBoxHorarioFim.Size = new Size(176, 27);
            textBoxHorarioFim.TabIndex = 4;
            textBoxHorarioFim.TextAlign = HorizontalAlignment.Center;
            // 
            // monthCalendarAula
            // 
            monthCalendarAula.BackColor = Color.FromArgb(224, 224, 224);
            monthCalendarAula.ForeColor = Color.Black;
            monthCalendarAula.Location = new Point(956, 255);
            monthCalendarAula.Name = "monthCalendarAula";
            monthCalendarAula.TabIndex = 5;
            monthCalendarAula.TitleBackColor = Color.Blue;
            // 
            // textBoxTreinosAula
            // 
            textBoxTreinosAula.Location = new Point(96, 25);
            textBoxTreinosAula.Name = "textBoxTreinosAula";
            textBoxTreinosAula.Size = new Size(335, 27);
            textBoxTreinosAula.TabIndex = 6;
            textBoxTreinosAula.TextAlign = HorizontalAlignment.Center;
            // 
            // buttonAddAula
            // 
            buttonAddAula.BackColor = Color.Black;
            buttonAddAula.Cursor = Cursors.Hand;
            buttonAddAula.FlatAppearance.BorderSize = 3;
            buttonAddAula.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonAddAula.ForeColor = Color.White;
            buttonAddAula.Location = new Point(896, 651);
            buttonAddAula.Name = "buttonAddAula";
            buttonAddAula.Size = new Size(255, 44);
            buttonAddAula.TabIndex = 13;
            buttonAddAula.Text = "Adicionar";
            buttonAddAula.UseVisualStyleBackColor = false;
            buttonAddAula.Click += buttonAddAula_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(317, 732);
            panel1.TabIndex = 24;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Arial Black", 18F);
            label11.ForeColor = Color.White;
            label11.Location = new Point(32, 345);
            label11.Name = "label11";
            label11.Size = new Size(251, 42);
            label11.TabIndex = 33;
            label11.Text = "Area Cadastro";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Segoe UI", 11F);
            label10.ForeColor = Color.White;
            label10.Location = new Point(53, 402);
            label10.Name = "label10";
            label10.Size = new Size(195, 100);
            label10.TabIndex = 31;
            label10.Text = "  Area de cadastro de \r\n        informações\r\n     de aulas da sua \r\n          academia!";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.branco_AULAS;
            pictureBox1.Location = new Point(105, 234);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(105, 108);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(label4);
            panel2.Controls.Add(textBoxNomeAula);
            panel2.Location = new Point(364, 179);
            panel2.Name = "panel2";
            panel2.Size = new Size(861, 64);
            panel2.TabIndex = 26;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label4.Location = new Point(10, 20);
            label4.Name = "label4";
            label4.Size = new Size(118, 28);
            label4.TabIndex = 18;
            label4.Text = "Nome Aula";
            // 
            // panel3
            // 
            panel3.BackColor = Color.Gainsboro;
            panel3.Controls.Add(label2);
            panel3.Controls.Add(label1);
            panel3.Controls.Add(textBoxHorarioFim);
            panel3.Controls.Add(textBoxHorarioInicio);
            panel3.Location = new Point(364, 278);
            panel3.Name = "panel3";
            panel3.Size = new Size(580, 64);
            panel3.TabIndex = 27;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label2.Location = new Point(302, 24);
            label2.Name = "label2";
            label2.Size = new Size(82, 28);
            label2.TabIndex = 19;
            label2.Text = "Hrs fim";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label1.Location = new Point(10, 20);
            label1.Name = "label1";
            label1.Size = new Size(102, 28);
            label1.TabIndex = 18;
            label1.Text = "Hrs Inicio";
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gainsboro;
            panel4.Controls.Add(label3);
            panel4.Controls.Add(label5);
            panel4.Controls.Add(textBoxTreinosAula);
            panel4.Controls.Add(textBoxInstrutorAula);
            panel4.Location = new Point(364, 474);
            panel4.Name = "panel4";
            panel4.Size = new Size(861, 64);
            panel4.TabIndex = 28;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label3.Location = new Point(437, 21);
            label3.Name = "label3";
            label3.Size = new Size(95, 28);
            label3.TabIndex = 19;
            label3.Text = "Instrutor";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label5.Location = new Point(10, 20);
            label5.Name = "label5";
            label5.Size = new Size(80, 28);
            label5.TabIndex = 18;
            label5.Text = "Treinos";
            // 
            // panel5
            // 
            panel5.BackColor = Color.Gainsboro;
            panel5.Controls.Add(label6);
            panel5.Controls.Add(textBoxDescricaoAula);
            panel5.Location = new Point(364, 374);
            panel5.Name = "panel5";
            panel5.Size = new Size(580, 64);
            panel5.TabIndex = 27;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label6.Location = new Point(0, 20);
            label6.Name = "label6";
            label6.Size = new Size(191, 28);
            label6.TabIndex = 18;
            label6.Text = "Descrição de Aulas";
            // 
            // buttonCancelarAulas
            // 
            buttonCancelarAulas.BackColor = Color.FromArgb(64, 64, 64);
            buttonCancelarAulas.Cursor = Cursors.Hand;
            buttonCancelarAulas.FlatAppearance.BorderSize = 3;
            buttonCancelarAulas.FlatStyle = FlatStyle.Flat;
            buttonCancelarAulas.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonCancelarAulas.ForeColor = Color.White;
            buttonCancelarAulas.Location = new Point(482, 651);
            buttonCancelarAulas.Name = "buttonCancelarAulas";
            buttonCancelarAulas.Size = new Size(255, 44);
            buttonCancelarAulas.TabIndex = 29;
            buttonCancelarAulas.Text = "Cancelar";
            buttonCancelarAulas.UseVisualStyleBackColor = false;
            buttonCancelarAulas.Click += buttonCancelarAulas_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.DarkGray;
            panel7.Location = new Point(336, 153);
            panel7.Name = "panel7";
            panel7.Size = new Size(922, 5);
            panel7.TabIndex = 30;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(336, 127);
            label9.Name = "label9";
            label9.Size = new Size(307, 23);
            label9.TabIndex = 31;
            label9.Text = "Informe os dados de sua aula aqui!";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Arial Black", 18F);
            label13.ForeColor = Color.White;
            label13.Location = new Point(336, 42);
            label13.Name = "label13";
            label13.Size = new Size(316, 42);
            label13.TabIndex = 35;
            label13.Text = "Cadastro de Aulas\r\n";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial Black", 11F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(1124, 123);
            label7.Name = "label7";
            label7.Size = new Size(134, 27);
            label7.TabIndex = 36;
            label7.Text = "Bem vindo !";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.branco_AULAS1;
            pictureBox2.Location = new Point(1135, 62);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(105, 58);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 37;
            pictureBox2.TabStop = false;
            // 
            // CadastrarAula
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1270, 732);
            Controls.Add(pictureBox2);
            Controls.Add(label7);
            Controls.Add(label13);
            Controls.Add(label9);
            Controls.Add(panel7);
            Controls.Add(buttonCancelarAulas);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(buttonAddAula);
            Controls.Add(monthCalendarAula);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "CadastrarAula";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CadastrarAula";
            Load += CadastrarAula_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxNomeAula;
        private TextBox textBoxDescricaoAula;
        private TextBox textBoxInstrutorAula;
        private TextBox textBoxHorarioInicio;
        private TextBox textBoxHorarioFim;
        private MonthCalendar monthCalendarAula;
        private TextBox textBoxTreinosAula;
        private Button buttonAddAula;
        private Panel panel1;
        private Label label11;
        private Label label10;
        private PictureBox pictureBox1;
        private Panel panel2;
        private Label label4;
        private Panel panel3;
        private Label label2;
        private Label label1;
        private Panel panel4;
        private Label label3;
        private Label label5;
        private Panel panel5;
        private Label label6;
        private Button buttonCancelarAulas;
        private Panel panel7;
        private Label label9;
        private Label label13;
        private Label label7;
        private PictureBox pictureBox2;
    }
}