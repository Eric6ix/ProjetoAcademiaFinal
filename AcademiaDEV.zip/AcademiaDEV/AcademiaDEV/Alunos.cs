﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iTextSharp.text.pdf;
using iTextSharp.text;
using MySql.Data.MySqlClient;
using static AlunoDAO;

namespace AcademiaDEV
{
    public partial class Alunos : Form
    {
        private string usuarioLogado;
        public static string ConnectionString = @"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None";

        private AlunoDAO alunoDAO;

        public Alunos(string usuario)
        {
            InitializeComponent();
            usuarioLogado = usuario;
            alunoDAO = new AlunoDAO(ConnectionString);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void Alunos_Load(object sender, EventArgs e)
        {
            LoadAlunos();


            dataGridViewAlunos.ReadOnly = true;


            // Desabilita a adição de novas linhas
            dataGridViewAlunos.AllowUserToAddRows = false;

            // Define o modo de seleção para linha inteira
            dataGridViewAlunos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Desabilita a edição ao clicar duas vezes
            dataGridViewAlunos.CellDoubleClick += (s, e) => {
                // Cancela a edição de célula
                dataGridViewAlunos.CurrentCell = null; // Desmarca a célula atual
                dataGridViewAlunos.BeginEdit(false); // Impede que a célula entre em modo de edição
            };

          
        }

        private void buttonExcluir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxPesquisarAluno.Text))
            {
                MessageBox.Show("Digite o CPF do Aluno em Pesquisar acima!");
                return;
            }

            try
            {
                string cpfAluno = textBoxPesquisarAluno.Text;
                alunoDAO.DeleteAluno(cpfAluno);
                MessageBox.Show("Aluno excluído com sucesso!");
                LoadAlunos(); // Atualiza a lista após exclusão
                textBoxPesquisarAluno.Clear();
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 0)
                {
                    MessageBox.Show("Nenhum aluno cadastrado com esse CPF.");
                }
                else
                {
                    MessageBox.Show($"Erro ao excluir aluno: {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao excluir aluno: {ex.Message}");
            }
        }

        private void buttonCadastarAluno_Click(object sender, EventArgs e)
        {
            CadastrarAlunos cadastrarAlunos = new CadastrarAlunos();
            cadastrarAlunos.ShowDialog();
            LoadAlunos(); // Atualiza a lista após cadastro
        }

        private void buttonBuscarAlunos_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxPesquisarAluno.Text))
            {
                MessageBox.Show("Digite o CPF do aluno para buscar.");
                return;
            }

            try
            {
                string cpf_aluno = textBoxPesquisarAluno.Text;
                var aluno = alunoDAO.GetAlunoByCPF(cpf_aluno);

                if (aluno != null)
                {
                    MessageBox.Show("Aluno encontrado. Você pode editar agora.");
                    // Preenche os campos com os dados do aluno encontrado, se necessário
                }
                else
                {
                    MessageBox.Show("Nenhum aluno cadastrado com esse CPF.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar aluno: {ex.Message}");
            }
        }

        private void buttonEditar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxPesquisarAluno.Text))
            {
                MessageBox.Show("Digite o CPF do aluno para editar.");
                return;
            }

            try
            {
                string cpf_aluno = textBoxPesquisarAluno.Text;
                var aluno = alunoDAO.GetAlunoByCPF(cpf_aluno);

                if (aluno != null)
                {
                    CadastrarAlunos cadastrarAlunos = new CadastrarAlunos(aluno);
                    cadastrarAlunos.ShowDialog();
                    LoadAlunos();
                }
                else
                {
                    MessageBox.Show("Nenhum aluno cadastrado com esse CPF.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar aluno: {ex.Message}");
            }
        }

        private void buttonAtualizarAluno_Click(object sender, EventArgs e)
        {
            LoadAlunos();
        }

        private void LoadAlunos()
        {
            try
            {
                var alunos = alunoDAO.GetAllAlunos();
                dataGridViewAlunos.DataSource = alunos;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar alunos: {ex.Message}");
            }
        }

        private void buttonVoltarAlunos_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<HomeOpçõescs>().Any())
            {
                Application.OpenForms.OfType<HomeOpçõescs>().First().Show();
            }
            else
            {
                HomeOpçõescs voltarHome = new HomeOpçõescs(usuarioLogado, "");
                voltarHome.ShowDialog();
            }

            this.Hide();
        }
        private void buttonAlunoPDF_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Você tem certeza que deseja gerar PDF Alunos?", "Confirmar Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                try
                {
                    // Obtendo o caminho da Área de Trabalho (Desktop) do usuário
                    string desktopFolder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                    // Definindo o caminho completo do arquivo PDF na Área de Trabalho
                    string filePath = Path.Combine(desktopFolder, "ListaAlunos.pdf");

                    // Criando o documento PDF e o escritor
                    Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
                    PdfWriter writer = PdfWriter.GetInstance(pdfDoc, new FileStream(filePath, FileMode.Create));

                    pdfDoc.Open();

                    // Fonte para o texto
                    BaseFont bf = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                    iTextSharp.text.Font font = new iTextSharp.text.Font(bf, 10, iTextSharp.text.Font.NORMAL);

                    // Criando a tabela PDF com o número de colunas do DataGridView de planos
                    PdfPTable pdfTable = new PdfPTable(dataGridViewAlunos.Columns.Count);
                    pdfTable.WidthPercentage = 100;

                    // Adicionando cabeçalhos do DataGridView ao PDF
                    foreach (DataGridViewColumn column in dataGridViewAlunos.Columns)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText, font));
                        cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                        pdfTable.AddCell(cell);
                    }

                    // Adicionando as linhas da DataGridView ao PDF
                    foreach (DataGridViewRow row in dataGridViewAlunos.Rows)
                    {
                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            pdfTable.AddCell(new Phrase(cell.Value?.ToString() ?? string.Empty, font));
                        }
                    }

                    // Adicionando a tabela ao documento PDF
                    pdfDoc.Add(pdfTable);
                    pdfDoc.Close();

                    // Verificando se o arquivo foi criado com sucesso antes de tentar abrir
                    if (File.Exists(filePath))
                    {
                        // Abrir o arquivo PDF gerado
                        Process.Start(new ProcessStartInfo(filePath) { UseShellExecute = true });

                        // Exibe uma mensagem de sucesso
                        MessageBox.Show("PDF de Planos gerado com sucesso na área de trabalho e aberto!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Erro: O arquivo PDF não foi gerado corretamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    // Exibe uma mensagem de erro se algo falhar
                    MessageBox.Show("Erro ao gerar ou abrir PDF: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }






        private void label1_Click(object sender, EventArgs e) { }

        
    }
}
