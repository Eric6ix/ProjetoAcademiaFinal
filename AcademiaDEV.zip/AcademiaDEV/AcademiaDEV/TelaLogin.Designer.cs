﻿namespace AcademiaDEV
{
    partial class Formlogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Formlogin));
            label1 = new Label();
            buttonLogin = new Button();
            textBoxUsuario = new TextBox();
            pictureBox2 = new PictureBox();
            label2 = new Label();
            textBoxSenha = new TextBox();
            pictureBox3 = new PictureBox();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            label4 = new Label();
            panel1 = new Panel();
            label8 = new Label();
            buttonCadastrarUser = new Button();
            pictureBox4 = new PictureBox();
            panel4 = new Panel();
            panel2 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            panel4.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 10F);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(75, 24);
            label1.Name = "label1";
            label1.Size = new Size(72, 23);
            label1.TabIndex = 5;
            label1.Text = "Usuario:";
            // 
            // buttonLogin
            // 
            buttonLogin.BackColor = Color.Black;
            buttonLogin.Cursor = Cursors.Hand;
            buttonLogin.FlatAppearance.BorderSize = 0;
            buttonLogin.FlatStyle = FlatStyle.Flat;
            buttonLogin.Font = new Font("Segoe UI", 13F);
            buttonLogin.ForeColor = Color.White;
            buttonLogin.ImageAlign = ContentAlignment.MiddleLeft;
            buttonLogin.Location = new Point(792, 541);
            buttonLogin.Name = "buttonLogin";
            buttonLogin.Size = new Size(303, 53);
            buttonLogin.TabIndex = 2;
            buttonLogin.Text = "Entrar";
            buttonLogin.UseVisualStyleBackColor = false;
            buttonLogin.Click += buttonLogin_Click_1;
            // 
            // textBoxUsuario
            // 
            textBoxUsuario.AccessibleName = "";
            textBoxUsuario.BackColor = Color.Gainsboro;
            textBoxUsuario.BorderStyle = BorderStyle.None;
            textBoxUsuario.Font = new Font("Segoe UI", 9F);
            textBoxUsuario.Location = new Point(145, 27);
            textBoxUsuario.Multiline = true;
            textBoxUsuario.Name = "textBoxUsuario";
            textBoxUsuario.Size = new Size(408, 20);
            textBoxUsuario.TabIndex = 0;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.user;
            pictureBox2.Location = new Point(3, 18);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(66, 31);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 7;
            pictureBox2.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 10F);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(75, 24);
            label2.Name = "label2";
            label2.Size = new Size(61, 23);
            label2.TabIndex = 6;
            label2.Text = "Senha:";
            // 
            // textBoxSenha
            // 
            textBoxSenha.BackColor = Color.Gainsboro;
            textBoxSenha.BorderStyle = BorderStyle.None;
            textBoxSenha.Location = new Point(142, 26);
            textBoxSenha.Multiline = true;
            textBoxSenha.Name = "textBoxSenha";
            textBoxSenha.PasswordChar = '*';
            textBoxSenha.Size = new Size(408, 21);
            textBoxSenha.TabIndex = 1;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(0, 15);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(69, 32);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 6;
            pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = Properties.Resources.icons8_usuário_90;
            pictureBox1.Location = new Point(736, 114);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(90, 84);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI Black", 19.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(832, 114);
            label3.Name = "label3";
            label3.Size = new Size(203, 45);
            label3.TabIndex = 4;
            label3.Text = "Conecte-se!";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI", 10F);
            label4.ForeColor = Color.White;
            label4.Location = new Point(832, 175);
            label4.Name = "label4";
            label4.Size = new Size(295, 23);
            label4.TabIndex = 5;
            label4.Text = "Preencha suas credênciais para login!";
            label4.Click += label4_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(label8);
            panel1.Controls.Add(buttonCadastrarUser);
            panel1.Controls.Add(pictureBox4);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(485, 708);
            panel1.TabIndex = 10;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Bauhaus 93", 33F);
            label8.ForeColor = Color.White;
            label8.Location = new Point(114, 29);
            label8.Name = "label8";
            label8.Size = new Size(276, 124);
            label8.TabIndex = 13;
            label8.Text = "Academia\r\n DEV";
            // 
            // buttonCadastrarUser
            // 
            buttonCadastrarUser.BackColor = Color.Black;
            buttonCadastrarUser.Cursor = Cursors.Hand;
            buttonCadastrarUser.FlatAppearance.BorderSize = 10;
            buttonCadastrarUser.Font = new Font("Arial Black", 12F);
            buttonCadastrarUser.ForeColor = Color.White;
            buttonCadastrarUser.Location = new Point(92, 606);
            buttonCadastrarUser.Name = "buttonCadastrarUser";
            buttonCadastrarUser.Size = new Size(298, 53);
            buttonCadastrarUser.TabIndex = 5;
            buttonCadastrarUser.Text = "Cadastre-se";
            buttonCadastrarUser.UseVisualStyleBackColor = false;
            buttonCadastrarUser.Click += buttonCadastrarUser_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.Design_sem_nome__1_;
            pictureBox4.Location = new Point(-10, 29);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(581, 667);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 6;
            pictureBox4.TabStop = false;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gainsboro;
            panel4.Controls.Add(textBoxUsuario);
            panel4.Controls.Add(pictureBox2);
            panel4.Controls.Add(label1);
            panel4.Location = new Point(647, 283);
            panel4.Name = "panel4";
            panel4.Size = new Size(571, 64);
            panel4.TabIndex = 11;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(textBoxSenha);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(pictureBox3);
            panel2.Location = new Point(647, 381);
            panel2.Name = "panel2";
            panel2.Size = new Size(571, 64);
            panel2.TabIndex = 12;
            // 
            // Formlogin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1312, 708);
            Controls.Add(panel2);
            Controls.Add(panel4);
            Controls.Add(panel1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(pictureBox1);
            Controls.Add(buttonLogin);
            ForeColor = Color.Black;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MdiChildrenMinimizedAnchorBottom = false;
            MinimizeBox = false;
            Name = "Formlogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox textBoxUsuario;
        private Button buttonLogin;
        private Button buttonLogin_Click;
        private Label label1;
        private Label label2;
        private TextBox textBoxSenha;
        private PictureBox pictureBox1;
        private Label label3;
        private Label label4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private Panel panel1;
        private Panel panel4;
        private Panel panel2;
        private Button buttonCadastrarUser;
        private PictureBox pictureBox4;
        private Label label8;
    }
}
