﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Forms;
using iTextSharp.text.pdf;
using iTextSharp.text;
using MySql.Data.MySqlClient;

namespace AcademiaDEV
{
    public partial class Aulas : Form
    {
        private string usuarioLogado;
        public static string ConnectionString = @"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None";
        private AulasDAO aulasDAO;

        public Aulas(string usuario)
        {
            InitializeComponent();
            usuarioLogado = usuario;
            aulasDAO = new AulasDAO(ConnectionString);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void Aulas_Load(object sender, EventArgs e)
        {
            LoadAulas();


            dataGridViewAulas.ReadOnly = true;
            // Desabilita a adição de novas linhas
            dataGridViewAulas.AllowUserToAddRows = false;

            // Define o modo de seleção para linha inteira
            dataGridViewAulas.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Desabilita a edição ao clicar duas vezes
            dataGridViewAulas.CellDoubleClick += (s, e) =>
            {
                // Cancela a edição de célula
                dataGridViewAulas.CurrentCell = null; // Desmarca a célula atual
                dataGridViewAulas.BeginEdit(false); // Impede que a célula entre em modo de edição
            };
        }

        private void buttonCadastarAula_Click(object sender, EventArgs e)
        {
            CadastrarAula cadastrarAula = new CadastrarAula();
            cadastrarAula.ShowDialog();
            LoadAulas();
        }

        private void buttonAtualizarAula_Click(object sender, EventArgs e)
        {
            LoadAulas();
        }

        private void buttonEditarAula_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxPesquisarNomeAula.Text))
            {
                MessageBox.Show("Digite o Nome da Aula para editar.");
                return;
            }

            try
            {
                string nome_aula = textBoxPesquisarNomeAula.Text;
                var obj_aula = aulasDAO.GetAulaByNome(nome_aula);

                if (obj_aula != null)
                {
                    CadastrarAula cadastrarAula = new CadastrarAula(obj_aula);
                    cadastrarAula.ShowDialog();
                    LoadAulas();
                }
                else
                {
                    MessageBox.Show("Nenhuma aula cadastrada com esse nome.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar aula: {ex.Message}");
            }
        }

        private void buttonExcluirAula_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxPesquisarNomeAula.Text))
            {
                MessageBox.Show("Digite o nome da Aula em Pesquisar acima!");
                return;
            }

            try
            {
                string nome_aula = textBoxPesquisarNomeAula.Text;
                aulasDAO.DeleteAula(nome_aula);
                MessageBox.Show("Aula excluída com sucesso!");
                LoadAulas();
                textBoxPesquisarNomeAula.Clear();
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 0)
                {
                    MessageBox.Show("Nenhuma aula cadastrada com esse nome.");
                }
                else
                {
                    MessageBox.Show($"Erro ao excluir aula: {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao excluir aula: {ex.Message}");
            }
        }

        private void LoadAulas()
        {
            try
            {
                var carregar_aulas = aulasDAO.GetAllAulas();
                dataGridViewAulas.DataSource = carregar_aulas;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar aulas: {ex.Message}");
            }
        }

        private void buttonBuscarAulas_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(textBoxPesquisarNomeAula.Text))
            {
                MessageBox.Show("Digite o Nome da aula para buscar.");
                return;
            }

            try
            {
                string nome_aula = textBoxPesquisarNomeAula.Text;
                var aluno = aulasDAO.GetAulaByNome(nome_aula);

                if (aluno != null)
                {
                    MessageBox.Show("Aula encontrada com sucesso!");
                    // Preenche os campos com os dados do aluno encontrado, se necessário
                }
                else
                {
                    MessageBox.Show("Nenhuma aula cadastrada com esse Nome.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar Aula: {ex.Message}");
            }
        }

        private void buttonVoltarAulas_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<HomeOpçõescs>().Any())
            {
                Application.OpenForms.OfType<HomeOpçõescs>().First().Show();
            }
            else
            {
                HomeOpçõescs voltarAulasHome = new HomeOpçõescs(usuarioLogado, "");
                voltarAulasHome.ShowDialog();
            }

            this.Hide();
        }

        private void buttonAulasPDF_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Você tem certeza que deseja gerar PDF Aulas?", "Confirmar Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                try
                {
                    // Obtendo o caminho da Área de Trabalho (Desktop) do usuário
                    string desktopFolder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                    // Definindo o caminho completo do arquivo PDF na Área de Trabalho
                    string filePath = Path.Combine(desktopFolder, "ListaAulas.pdf");

                    // Criando o documento PDF e o escritor
                    Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
                    PdfWriter writer = PdfWriter.GetInstance(pdfDoc, new FileStream(filePath, FileMode.Create));

                    pdfDoc.Open();

                    // Fonte para o texto
                    BaseFont bf = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                    iTextSharp.text.Font font = new iTextSharp.text.Font(bf, 10, iTextSharp.text.Font.NORMAL);

                    // Criando a tabela PDF com o número de colunas do DataGridView de planos
                    PdfPTable pdfTable = new PdfPTable(dataGridViewAulas.Columns.Count);
                    pdfTable.WidthPercentage = 100;

                    // Adicionando cabeçalhos do DataGridView ao PDF
                    foreach (DataGridViewColumn column in dataGridViewAulas.Columns)
                    {
                        PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText, font));
                        cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                        pdfTable.AddCell(cell);
                    }

                    // Adicionando as linhas da DataGridView ao PDF
                    foreach (DataGridViewRow row in dataGridViewAulas.Rows)
                    {
                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            pdfTable.AddCell(new Phrase(cell.Value?.ToString() ?? string.Empty, font));
                        }
                    }

                    // Adicionando a tabela ao documento PDF
                    pdfDoc.Add(pdfTable);
                    pdfDoc.Close();

                    // Verificando se o arquivo foi criado com sucesso antes de tentar abrir
                    if (File.Exists(filePath))
                    {
                        // Abrir o arquivo PDF gerado
                        Process.Start(new ProcessStartInfo(filePath) { UseShellExecute = true });

                        // Exibe uma mensagem de sucesso
                        MessageBox.Show("PDF de Aulas gerado com sucesso na área de trabalho e aberto!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Erro: O arquivo PDF não foi gerado corretamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    // Exibe uma mensagem de erro se algo falhar
                    MessageBox.Show("Erro ao gerar ou abrir PDF: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
