﻿namespace AcademiaDEV
{
    partial class CadastrarFuncionarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastrarFuncionarios));
            txtCargo = new TextBox();
            buttonAddFuncionario = new Button();
            buttonCancelar = new Button();
            label2 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            panel1 = new Panel();
            label10 = new Label();
            label11 = new Label();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label9 = new Label();
            label3 = new Label();
            panel4 = new Panel();
            txtNome = new TextBox();
            txtHorarioTrabalho = new TextBox();
            panel2 = new Panel();
            txtCPF = new TextBox();
            panel6 = new Panel();
            txtSalario = new TextBox();
            panel3 = new Panel();
            panel5 = new Panel();
            txtEspecializacao = new TextBox();
            panel7 = new Panel();
            txtEmail = new TextBox();
            panel8 = new Panel();
            pictureBox2 = new PictureBox();
            label12 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel4.SuspendLayout();
            panel2.SuspendLayout();
            panel6.SuspendLayout();
            panel3.SuspendLayout();
            panel5.SuspendLayout();
            panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // txtCargo
            // 
            txtCargo.BackColor = Color.White;
            txtCargo.ForeColor = Color.Black;
            txtCargo.Location = new Point(72, 22);
            txtCargo.Multiline = true;
            txtCargo.Name = "txtCargo";
            txtCargo.Size = new Size(399, 27);
            txtCargo.TabIndex = 9;
            txtCargo.TextAlign = HorizontalAlignment.Center;
            // 
            // buttonAddFuncionario
            // 
            buttonAddFuncionario.BackColor = Color.Black;
            buttonAddFuncionario.Cursor = Cursors.Hand;
            buttonAddFuncionario.FlatAppearance.BorderSize = 3;
            buttonAddFuncionario.FlatStyle = FlatStyle.Flat;
            buttonAddFuncionario.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonAddFuncionario.ForeColor = Color.White;
            buttonAddFuncionario.Location = new Point(857, 641);
            buttonAddFuncionario.Name = "buttonAddFuncionario";
            buttonAddFuncionario.Size = new Size(255, 44);
            buttonAddFuncionario.TabIndex = 12;
            buttonAddFuncionario.Text = "Adicionar";
            buttonAddFuncionario.UseVisualStyleBackColor = false;
            buttonAddFuncionario.Click += buttonAddFuncionario_Click;
            // 
            // buttonCancelar
            // 
            buttonCancelar.BackColor = Color.FromArgb(64, 64, 64);
            buttonCancelar.Cursor = Cursors.Hand;
            buttonCancelar.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonCancelar.ForeColor = Color.White;
            buttonCancelar.Location = new Point(508, 641);
            buttonCancelar.Name = "buttonCancelar";
            buttonCancelar.Size = new Size(255, 44);
            buttonCancelar.TabIndex = 13;
            buttonCancelar.Text = "Cancelar";
            buttonCancelar.UseVisualStyleBackColor = false;
            buttonCancelar.Click += buttonCancelar_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(13, 23);
            label2.Name = "label2";
            label2.Size = new Size(69, 28);
            label2.TabIndex = 14;
            label2.Text = "Nome";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(11, 21);
            label4.Name = "label4";
            label4.Size = new Size(46, 28);
            label4.TabIndex = 17;
            label4.Text = "CPF";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(15, 19);
            label5.Name = "label5";
            label5.Size = new Size(77, 28);
            label5.TabIndex = 18;
            label5.Text = "Salário";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(3, 21);
            label6.Name = "label6";
            label6.Size = new Size(67, 28);
            label6.TabIndex = 19;
            label6.Text = "Cargo";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label7.ForeColor = Color.Black;
            label7.Location = new Point(15, 26);
            label7.Name = "label7";
            label7.Size = new Size(64, 28);
            label7.TabIndex = 20;
            label7.Text = "Email";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(15, 22);
            label8.Name = "label8";
            label8.Size = new Size(140, 28);
            label8.TabIndex = 21;
            label8.Text = "Especialidade";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(label10);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(317, 732);
            panel1.TabIndex = 22;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Segoe UI", 11F);
            label10.ForeColor = Color.White;
            label10.Location = new Point(49, 389);
            label10.Name = "label10";
            label10.Size = new Size(195, 100);
            label10.TabIndex = 35;
            label10.Text = "  Area de cadastro de \r\n         informações\r\n    de funciónarios da \r\n        sua academia!";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Arial Black", 18F);
            label11.ForeColor = Color.White;
            label11.Location = new Point(35, 345);
            label11.Name = "label11";
            label11.Size = new Size(251, 42);
            label11.TabIndex = 34;
            label11.Text = "Area Cadastro";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.icons8_contrato_de_trabalho_100;
            pictureBox1.Location = new Point(100, 234);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(125, 108);
            pictureBox1.TabIndex = 33;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Black", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(331, 26);
            label1.Name = "label1";
            label1.Size = new Size(324, 35);
            label1.TabIndex = 5;
            label1.Text = "Cadastro de funcionários";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(331, 76);
            label9.Name = "label9";
            label9.Size = new Size(360, 23);
            label9.TabIndex = 24;
            label9.Text = "Informe os dados de seu funionario aqui!";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(509, 20);
            label3.Name = "label3";
            label3.Size = new Size(172, 28);
            label3.TabIndex = 16;
            label3.Text = "Horario Trabalho";
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gainsboro;
            panel4.Controls.Add(txtNome);
            panel4.Controls.Add(label2);
            panel4.Controls.Add(txtHorarioTrabalho);
            panel4.Controls.Add(label3);
            panel4.Location = new Point(333, 143);
            panel4.Name = "panel4";
            panel4.Size = new Size(901, 64);
            panel4.TabIndex = 28;
            // 
            // txtNome
            // 
            txtNome.AccessibleName = "";
            txtNome.BackColor = Color.White;
            txtNome.ForeColor = Color.Black;
            txtNome.Location = new Point(88, 24);
            txtNome.Multiline = true;
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(399, 27);
            txtNome.TabIndex = 2;
            txtNome.TextAlign = HorizontalAlignment.Center;
            // 
            // txtHorarioTrabalho
            // 
            txtHorarioTrabalho.BackColor = Color.White;
            txtHorarioTrabalho.ForeColor = Color.Black;
            txtHorarioTrabalho.Location = new Point(687, 23);
            txtHorarioTrabalho.Multiline = true;
            txtHorarioTrabalho.Name = "txtHorarioTrabalho";
            txtHorarioTrabalho.Size = new Size(198, 27);
            txtHorarioTrabalho.TabIndex = 6;
            txtHorarioTrabalho.TextAlign = HorizontalAlignment.Center;
            txtHorarioTrabalho.TextChanged += txtHorarioTrabalho_TextChanged;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(txtCPF);
            panel2.Controls.Add(label4);
            panel2.Location = new Point(331, 246);
            panel2.Name = "panel2";
            panel2.Size = new Size(489, 64);
            panel2.TabIndex = 26;
            // 
            // txtCPF
            // 
            txtCPF.BackColor = Color.White;
            txtCPF.Font = new Font("Segoe UI", 9F);
            txtCPF.ForeColor = Color.Black;
            txtCPF.Location = new Point(63, 21);
            txtCPF.Multiline = true;
            txtCPF.Name = "txtCPF";
            txtCPF.Size = new Size(407, 27);
            txtCPF.TabIndex = 7;
            txtCPF.TextAlign = HorizontalAlignment.Center;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Gainsboro;
            panel6.Controls.Add(txtSalario);
            panel6.Controls.Add(label5);
            panel6.Location = new Point(857, 297);
            panel6.Name = "panel6";
            panel6.Size = new Size(379, 64);
            panel6.TabIndex = 29;
            // 
            // txtSalario
            // 
            txtSalario.BackColor = Color.White;
            txtSalario.ForeColor = Color.Black;
            txtSalario.Location = new Point(98, 23);
            txtSalario.Multiline = true;
            txtSalario.Name = "txtSalario";
            txtSalario.Size = new Size(261, 27);
            txtSalario.TabIndex = 8;
            txtSalario.TextAlign = HorizontalAlignment.Center;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Gainsboro;
            panel3.Controls.Add(txtCargo);
            panel3.Controls.Add(label6);
            panel3.Location = new Point(335, 334);
            panel3.Name = "panel3";
            panel3.Size = new Size(489, 64);
            panel3.TabIndex = 27;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Gainsboro;
            panel5.Controls.Add(txtEspecializacao);
            panel5.Controls.Add(label8);
            panel5.Location = new Point(423, 425);
            panel5.Name = "panel5";
            panel5.Size = new Size(800, 64);
            panel5.TabIndex = 30;
            // 
            // txtEspecializacao
            // 
            txtEspecializacao.BackColor = Color.White;
            txtEspecializacao.ForeColor = Color.Black;
            txtEspecializacao.Location = new Point(161, 22);
            txtEspecializacao.Multiline = true;
            txtEspecializacao.Name = "txtEspecializacao";
            txtEspecializacao.Size = new Size(620, 27);
            txtEspecializacao.TabIndex = 11;
            txtEspecializacao.TextAlign = HorizontalAlignment.Center;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Gainsboro;
            panel7.Controls.Add(txtEmail);
            panel7.Controls.Add(label7);
            panel7.Location = new Point(423, 521);
            panel7.Name = "panel7";
            panel7.Size = new Size(800, 64);
            panel7.TabIndex = 31;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = Color.White;
            txtEmail.ForeColor = Color.Black;
            txtEmail.Location = new Point(85, 26);
            txtEmail.Multiline = true;
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(696, 27);
            txtEmail.TabIndex = 10;
            txtEmail.TextAlign = HorizontalAlignment.Center;
            // 
            // panel8
            // 
            panel8.BackColor = Color.DarkGray;
            panel8.Location = new Point(323, 112);
            panel8.Name = "panel8";
            panel8.Size = new Size(922, 5);
            panel8.TabIndex = 32;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.icons8_contrato_de_trabalho_100;
            pictureBox2.Location = new Point(1131, 21);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(105, 58);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 36;
            pictureBox2.TabStop = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Arial Black", 11F);
            label12.ForeColor = Color.White;
            label12.Location = new Point(1124, 82);
            label12.Name = "label12";
            label12.Size = new Size(134, 27);
            label12.TabIndex = 37;
            label12.Text = "Bem vindo !";
            // 
            // CadastrarFuncionarios
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1270, 732);
            Controls.Add(label12);
            Controls.Add(pictureBox2);
            Controls.Add(label9);
            Controls.Add(panel8);
            Controls.Add(label1);
            Controls.Add(panel7);
            Controls.Add(panel5);
            Controls.Add(panel3);
            Controls.Add(panel6);
            Controls.Add(panel2);
            Controls.Add(panel4);
            Controls.Add(buttonCancelar);
            Controls.Add(buttonAddFuncionario);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "CadastrarFuncionarios";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CadastrarFuncionarios";
            Load += CadastrarFuncionarios_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtCargo;
        private Button buttonAddFuncionario;
        private Button buttonCancelar;
        private Label label2;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Panel panel1;
        private Label label1;
        private Label label9;
        private Label label3;
        private Panel panel4;
        private Panel panel2;
        private Panel panel6;
        private Panel panel3;
        private Panel panel5;
        private Panel panel7;
        private Panel panel8;
        private PictureBox pictureBox1;
        private Label label11;
        private Label label10;
        private PictureBox pictureBox2;
        private Label label12;
        private TextBox txtNome;
        private TextBox txtEmail;
        private TextBox txtEspecializacao;
        private TextBox txtSalario;
        private TextBox txtCPF;
        private TextBox txtHorarioTrabalho;
    }
}