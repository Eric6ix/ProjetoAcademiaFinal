﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace AcademiaDEV
{
    public partial class EditarUsuario : Form
    {
        private string usuarioLogado;
        private string senhaLogada;

        private static readonly string ConnectionString = @"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None;";

        public EditarUsuario(string usuario, string senha)
        {
            InitializeComponent();
            usuarioLogado = usuario;
            senhaLogada = senha;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void EditarUsuario_Load(object sender, EventArgs e)
        {
            // Preenche os campos com os dados do usuário
            textBoxUsuarioEditar.Text = usuarioLogado;
            textBoxSenhaEditar.Text = senhaLogada;
        }

        private void buttonSalvarEdicao_Click(object sender, EventArgs e)
        {
            string novoUsuario = textBoxUsuarioEditar.Text;
            string novaSenha = textBoxSenhaEditar.Text;

            if (string.IsNullOrWhiteSpace(novoUsuario) || string.IsNullOrWhiteSpace(novaSenha))
            {
                MessageBox.Show("Por favor, preencha todos os campos.");
                return;
            }

            // Atualiza os dados no banco de dados
            using (MySqlConnection connection = new MySqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();
                    string query = "UPDATE UsuariosLogin SET Usuario = @NovoUsuario, Senha = @NovaSenha WHERE Usuario = @UsuarioAntigo";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@NovoUsuario", novoUsuario);
                        command.Parameters.AddWithValue("@NovaSenha", novaSenha);
                        command.Parameters.AddWithValue("@UsuarioAntigo", usuarioLogado);

                        int result = command.ExecuteNonQuery();

                        if (result > 0)
                        {
                            MessageBox.Show("Credenciais atualizadas com sucesso!");
                            // Atualiza as credenciais locais
                            usuarioLogado = novoUsuario;
                            senhaLogada = novaSenha;
                            this.DialogResult = DialogResult.OK; // Define o resultado do diálogo como OK
                            this.Close(); // Fecha o formulário após a atualização
                        }
                        else
                        {
                            MessageBox.Show("Falha ao atualizar as credenciais.");
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show($"Erro ao conectar ao banco de dados: {ex.Message}");
                }
            }
        }

        // Propriedades para acessar as novas credenciais
        public string NovoUsuario => textBoxUsuarioEditar.Text;
        public string NovaSenha => textBoxSenhaEditar.Text;
    }
}
