﻿namespace AcademiaDEV
{
    partial class CadastrarLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastrarLogin));
            textCadastroUsuarioBox = new TextBox();
            textCadastroSenhaBox = new TextBox();
            buttonCadatrarLogin = new Button();
            panel4 = new Panel();
            buttonVoltarTelaLogin = new Button();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            pictureBox1 = new PictureBox();
            label8 = new Label();
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            label3 = new Label();
            panel2 = new Panel();
            label9 = new Label();
            pictureBox3 = new PictureBox();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // textCadastroUsuarioBox
            // 
            textCadastroUsuarioBox.BackColor = Color.Gainsboro;
            textCadastroUsuarioBox.BorderStyle = BorderStyle.None;
            textCadastroUsuarioBox.Location = new Point(204, 29);
            textCadastroUsuarioBox.Multiline = true;
            textCadastroUsuarioBox.Name = "textCadastroUsuarioBox";
            textCadastroUsuarioBox.Size = new Size(348, 20);
            textCadastroUsuarioBox.TabIndex = 0;
            // 
            // textCadastroSenhaBox
            // 
            textCadastroSenhaBox.BackColor = Color.Gainsboro;
            textCadastroSenhaBox.BorderStyle = BorderStyle.None;
            textCadastroSenhaBox.Location = new Point(204, 26);
            textCadastroSenhaBox.Multiline = true;
            textCadastroSenhaBox.Name = "textCadastroSenhaBox";
            textCadastroSenhaBox.Size = new Size(364, 21);
            textCadastroSenhaBox.TabIndex = 1;
            // 
            // buttonCadatrarLogin
            // 
            buttonCadatrarLogin.BackColor = Color.Black;
            buttonCadatrarLogin.FlatAppearance.BorderSize = 0;
            buttonCadatrarLogin.FlatStyle = FlatStyle.Flat;
            buttonCadatrarLogin.Font = new Font("Segoe UI", 13F);
            buttonCadatrarLogin.ForeColor = Color.White;
            buttonCadatrarLogin.Location = new Point(774, 522);
            buttonCadatrarLogin.Name = "buttonCadatrarLogin";
            buttonCadatrarLogin.Size = new Size(303, 53);
            buttonCadatrarLogin.TabIndex = 2;
            buttonCadatrarLogin.Text = "cadastrar";
            buttonCadatrarLogin.UseVisualStyleBackColor = false;
            buttonCadatrarLogin.Click += buttonCadatrarLogin_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Black;
            panel4.Controls.Add(buttonVoltarTelaLogin);
            panel4.Controls.Add(label7);
            panel4.Controls.Add(label6);
            panel4.Controls.Add(label5);
            panel4.Dock = DockStyle.Left;
            panel4.ForeColor = Color.White;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(485, 687);
            panel4.TabIndex = 11;
            // 
            // buttonVoltarTelaLogin
            // 
            buttonVoltarTelaLogin.BackColor = Color.Black;
            buttonVoltarTelaLogin.FlatAppearance.BorderSize = 10;
            buttonVoltarTelaLogin.Font = new Font("Arial Black", 12F);
            buttonVoltarTelaLogin.ForeColor = Color.White;
            buttonVoltarTelaLogin.Location = new Point(85, 541);
            buttonVoltarTelaLogin.Name = "buttonVoltarTelaLogin";
            buttonVoltarTelaLogin.Size = new Size(298, 53);
            buttonVoltarTelaLogin.TabIndex = 5;
            buttonVoltarTelaLogin.Text = "Cancelar";
            buttonVoltarTelaLogin.UseVisualStyleBackColor = false;
            buttonVoltarTelaLogin.Click += buttonVoltarTelaLogin_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(120, 344);
            label7.Name = "label7";
            label7.Size = new Size(193, 50);
            label7.TabIndex = 4;
            label7.Text = "Siga as instruções de \r\ncadastro de login";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Black", 15F);
            label6.ForeColor = Color.White;
            label6.Location = new Point(118, 260);
            label6.Name = "label6";
            label6.Size = new Size(219, 72);
            label6.TabIndex = 3;
            label6.Text = "Faça seu novo \r\ncadastro aqui!";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Bauhaus 93", 33F);
            label5.ForeColor = Color.White;
            label5.Location = new Point(96, 52);
            label5.Name = "label5";
            label5.Size = new Size(276, 124);
            label5.TabIndex = 2;
            label5.Text = "Academia\r\n DEV";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = Properties.Resources.Uusario;
            pictureBox1.Location = new Point(745, 123);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(89, 73);
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI Black", 19.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(825, 131);
            label8.Name = "label8";
            label8.Size = new Size(252, 45);
            label8.TabIndex = 13;
            label8.Text = "Crie sua conta!";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gainsboro;
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(textCadastroUsuarioBox);
            panel1.Location = new Point(652, 268);
            panel1.Name = "panel1";
            panel1.Size = new Size(571, 64);
            panel1.TabIndex = 14;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.user;
            pictureBox2.Location = new Point(3, 18);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(54, 31);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 7;
            pictureBox2.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 10F);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(63, 26);
            label3.Name = "label3";
            label3.Size = new Size(135, 23);
            label3.TabIndex = 5;
            label3.Text = "Crie um usuario:";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(label9);
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(textCadastroSenhaBox);
            panel2.Location = new Point(652, 360);
            panel2.Name = "panel2";
            panel2.Size = new Size(571, 64);
            panel2.TabIndex = 13;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI", 10F);
            label9.ForeColor = Color.Black;
            label9.Location = new Point(75, 24);
            label9.Name = "label9";
            label9.Size = new Size(133, 23);
            label9.TabIndex = 6;
            label9.Text = "Crie uma senha:";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(0, 15);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(69, 32);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 6;
            pictureBox3.TabStop = false;
            // 
            // CadastrarLogin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1312, 687);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(label8);
            Controls.Add(pictureBox1);
            Controls.Add(panel4);
            Controls.Add(buttonCadatrarLogin);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "CadastrarLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CadastrarLogin";
            Load += CadastrarLogin_Load;
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textCadastroUsuarioBox;
        private TextBox textCadastroSenhaBox;
        private Button buttonCadatrarLogin;
        private Panel panel4;
        private Button buttonVoltarTelaLogin;
        private Label label7;
        private Label label6;
        private Label label5;
        private PictureBox pictureBox1;
        private Label label8;
        private Panel panel1;
        private PictureBox pictureBox2;
        private Label label3;
        private Panel panel2;
        private Label label9;
        private PictureBox pictureBox3;
    }
}