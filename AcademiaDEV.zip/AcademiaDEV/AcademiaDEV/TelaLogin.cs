using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace AcademiaDEV
{
    public partial class Formlogin : Form
    {
        private static readonly string ConnectionString = @"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None;";
        public Formlogin()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click_1(object sender, EventArgs e)
        {
            // Verifica se os campos est�o preenchidos
            if (string.IsNullOrWhiteSpace(textBoxUsuario.Text) || string.IsNullOrWhiteSpace(textBoxSenha.Text))
            {
                MessageBox.Show("Por favor, preencha todos os campos.");
                return;
            }

            // Verifica se as credenciais est�o corretas
            (string usuarioLogado, string senhaLogada) = VerificarLogin(textBoxUsuario.Text, textBoxSenha.Text);

            if (!string.IsNullOrEmpty(usuarioLogado))
            {
                // Limpa os campos ap�s login bem-sucedido
                textBoxUsuario.Clear();
                textBoxSenha.Clear();
                MessageBox.Show("Login bem-sucedido!");

                // Passa o nome do usu�rio e a senha para HomeOp��escs
                HomeOp��escs homeOpcoes = new HomeOp��escs(usuarioLogado, senhaLogada);
                homeOpcoes.ShowDialog();
                this.Close(); // Fecha a tela de login
            }
            else
            {
                // Limpa os campos em caso de falha
                textBoxUsuario.Clear();
                textBoxSenha.Clear();
                MessageBox.Show("Algo est� errado! Verifique suas credenciais ou fa�a um cadastro de login.");
            }
        }

        private (string, string) VerificarLogin(string usuario, string senha)
        {
            using (MySqlConnection connection = new MySqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT Usuario, Senha FROM UsuariosLogin WHERE Usuario = @Usuario AND Senha = @Senha";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Usuario", usuario);
                        command.Parameters.AddWithValue("@Senha", senha);

                        using (MySqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string usuarioRetornado = reader["Usuario"].ToString();
                                string senhaRetornada = reader["Senha"].ToString();
                                return (usuarioRetornado, senhaRetornada); // Retorna o nome do usu�rio e a senha
                            }
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show($"Erro ao conectar ao banco de dados: {ex.Message}");
                }
            }
            return (null, null); // Retorna nulo se n�o encontrar
        }

        private void buttonCadastroLogin_Click(object sender, EventArgs e)
        {
            // Limpa os campos antes de abrir a tela de cadastro
            textBoxUsuario.Clear();
            textBoxSenha.Clear();
            CadastrarLogin cadastrarLogin = new CadastrarLogin();
            cadastrarLogin.ShowDialog();
        }

        private void buttonCadastrarUser_Click(object sender, EventArgs e)
        {
            // Apenas abre a tela de cadastro
            CadastrarLogin cadastrarUser = new CadastrarLogin();
            cadastrarUser.ShowDialog();
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            // C�digo para a imagem (se necess�rio)
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // C�digo de inicializa��o, se necess�rio
        }

        private void label4_Click(object sender, EventArgs e)
        {
            // C�digo para o label, se necess�rio
        }
    }
}
