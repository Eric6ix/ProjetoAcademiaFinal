﻿namespace AcademiaDEV
{
    partial class ConfirmarCPFForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConfirmarCPFForm));
            textBoxCPF = new TextBox();
            buttonConfirmar = new Button();
            panel1 = new Panel();
            label7 = new Label();
            pictureBox2 = new PictureBox();
            panel2 = new Panel();
            pictureBox3 = new PictureBox();
            label1 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // textBoxCPF
            // 
            textBoxCPF.BorderStyle = BorderStyle.FixedSingle;
            textBoxCPF.Location = new Point(55, 16);
            textBoxCPF.Multiline = true;
            textBoxCPF.Name = "textBoxCPF";
            textBoxCPF.Size = new Size(323, 27);
            textBoxCPF.TabIndex = 0;
            textBoxCPF.TextAlign = HorizontalAlignment.Center;
            // 
            // buttonConfirmar
            // 
            buttonConfirmar.BackColor = Color.FromArgb(192, 255, 192);
            buttonConfirmar.Cursor = Cursors.Hand;
            buttonConfirmar.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            buttonConfirmar.Image = Properties.Resources.icons8_pesquisar_48;
            buttonConfirmar.ImageAlign = ContentAlignment.MiddleLeft;
            buttonConfirmar.Location = new Point(57, 270);
            buttonConfirmar.Name = "buttonConfirmar";
            buttonConfirmar.Size = new Size(314, 49);
            buttonConfirmar.TabIndex = 1;
            buttonConfirmar.Text = "Confirmar";
            buttonConfirmar.UseVisualStyleBackColor = false;
            buttonConfirmar.Click += buttonConfirmar_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DimGray;
            panel1.Controls.Add(label7);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(buttonConfirmar);
            panel1.Location = new Point(128, 31);
            panel1.Name = "panel1";
            panel1.Size = new Size(424, 383);
            panel1.TabIndex = 2;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(18, 77);
            label7.Name = "label7";
            label7.Size = new Size(318, 25);
            label7.TabIndex = 35;
            label7.Text = "Informe o CPF válido para cadastrar!";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(319, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(105, 58);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 34;
            pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(textBoxCPF);
            panel2.Location = new Point(18, 143);
            panel2.Name = "panel2";
            panel2.Size = new Size(391, 57);
            panel2.TabIndex = 9;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(3, 0);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(46, 54);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 27;
            pictureBox3.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Black", 15F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(21, 22);
            label1.Name = "label1";
            label1.Size = new Size(175, 36);
            label1.TabIndex = 8;
            label1.Text = "CPF ALUNO";
            // 
            // ConfirmarCPFForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(692, 450);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "ConfirmarCPFForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ConfirmarCPFForm";
            Load += ConfirmarCPFForm_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TextBox textBoxCPF;
        private Button buttonConfirmar;
        private Panel panel1;
        private Panel panel2;
        private Label label1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private Label label7;
    }
}