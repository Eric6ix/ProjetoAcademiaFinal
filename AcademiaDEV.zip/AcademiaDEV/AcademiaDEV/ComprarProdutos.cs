﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace AcademiaDEV
{
    public partial class ComprarProdutos : Form
    {
        public ComprarProdutos()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void buttonCompraCreatina_Click(object sender, EventArgs e)
        {
            // Pergunta se o usuário deseja confirmar a retirada
            DialogResult resultado = MessageBox.Show("Você deseja confirmar a retirada deste produto?",
                                                    "Confirmar Retirada",
                                                    MessageBoxButtons.YesNo,
                                                    MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                // Obtém o código do produto digitado no TextBox
                string codigoProduto = textBoxCodigoProduto.Text;

                // Obtém a quantidade a ser retirada usando o NumericUpDown
                int quantidadeParaRetirar = (int)numericUpDownQuantidade.Value;

                // Cria uma instância de ProdutoDAO com a string de conexão apropriada
                ProdutoDAO produtoDAO = new ProdutoDAO(@"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None;");

                // Busca o produto pelo código informado
                ProdutoDAO.Produto produto = produtoDAO.GetProdutoByCodigo(codigoProduto);

                if (produto != null) // Verifica se o produto foi encontrado
                {
                    // Verifica se há quantidade suficiente para a retirada
                    if (produto.Quantidade >= quantidadeParaRetirar)
                    {
                        // Reduz a quantidade do produto no estoque
                        produtoDAO.ReduceQuantity(produto.ProdutoId, quantidadeParaRetirar);
                        MessageBox.Show("Compra realizada com sucesso!");
                        textBoxCodigoProduto.Clear();
                    }
                    else
                    {
                        MessageBox.Show("Quantidade insuficiente em estoque para a retirada.");
                    }
                }
                else
                {
                    MessageBox.Show("Produto não encontrado. Verifique o código e tente novamente.");
                }
            }
            else
            {
                MessageBox.Show("Ação cancelada."); // Mensagem de ação cancelada
            }
        }

        private void buttonAdcionar_Click(object sender, EventArgs e)
        {
            // Pergunta se o usuário deseja confirmar a adição
            DialogResult resultado = MessageBox.Show("Você deseja adicionar esta quantidade ao estoque?",
                                                    "Confirmar Adição",
                                                    MessageBoxButtons.YesNo,
                                                    MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                // Obtém o código do produto digitado no TextBox
                string codigoProduto = textBoxCodigoProduto.Text;

                // Obtém a quantidade a ser adicionada usando o NumericUpDown
                int quantidadeParaAdicionar = (int)numericUpDownQuantidade.Value;

                // Cria uma instância de ProdutoDAO com a string de conexão apropriada
                ProdutoDAO produtoDAO = new ProdutoDAO(@"Server=localhost;Port=3306;Database=sistemaDev;User ID=root;Password=vsistema123;SslMode=None;");

                // Busca o produto pelo código informado
                ProdutoDAO.Produto produto = produtoDAO.GetProdutoByCodigo(codigoProduto);

                if (produto != null) // Verifica se o produto foi encontrado
                {
                    // Aumenta a quantidade do produto no estoque
                    produtoDAO.IncreaseQuantity(codigoProduto, quantidadeParaAdicionar);
                    MessageBox.Show("Quantidade adicionada ao estoque com sucesso!");
                    textBoxCodigoProduto.Clear();
                }
                else
                {
                    MessageBox.Show("Produto não encontrado. Verifique o código e tente novamente.");
                }
            }
            else
            {
                MessageBox.Show("Ação cancelada."); // Mensagem de ação cancelada
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Evento do label, sem implementação específica
        }

        private void ComprarProdutos_Load(object sender, EventArgs e)
        {
            // Evento de carregamento do formulário, sem implementação específica
        }
    }
}
